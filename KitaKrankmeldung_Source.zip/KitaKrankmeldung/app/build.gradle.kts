plugins {
    id("com.android.application")
}

android {
    namespace = "de.kita.krankmeldung"
    compileSdk = 35

    defaultConfig {
        applicationId = "de.kita.krankmeldung"
        minSdk = 29
        targetSdk = 35
        versionCode = 8
        versionName = "0.3.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
