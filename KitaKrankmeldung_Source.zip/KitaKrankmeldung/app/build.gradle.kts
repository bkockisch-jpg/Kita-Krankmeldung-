plugins {
    id("com.android.application")
}

android {
    namespace = "de.kita.krankmeldung"
    compileSdk = 35

    defaultConfig {
        applicationId = "de.kita.krankmeldung"
        minSdk = 29
        targetSdk = 35
        versionCode = 5
        versionName = "0.2.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
