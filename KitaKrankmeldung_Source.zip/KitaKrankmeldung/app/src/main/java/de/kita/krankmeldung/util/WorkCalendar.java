package de.kita.krankmeldung.util;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.LinkedHashMap;
import java.util.Map;

/** Arbeitstagslogik für Hessen. Gesetzliche Feiertage werden algorithmisch berechnet. */
public final class WorkCalendar {
    private WorkCalendar() {}

    public static boolean isBusinessDay(LocalDate date) {
        DayOfWeek dow = date.getDayOfWeek();
        return dow != DayOfWeek.SATURDAY && dow != DayOfWeek.SUNDAY && !isHessePublicHoliday(date);
    }

    public static LocalDate nextBusinessDay(LocalDate from) {
        LocalDate d = from.plusDays(1);
        while (!isBusinessDay(d)) d = d.plusDays(1);
        return d;
    }

    public static LocalDate nextOrSameBusinessDay(LocalDate from) {
        LocalDate d = from;
        while (!isBusinessDay(d)) d = d.plusDays(1);
        return d;
    }

    public static boolean isHessePublicHoliday(LocalDate d) {
        return holidayName(d) != null;
    }

    public static String holidayName(LocalDate d) {
        Map<LocalDate, String> holidays = holidaysForYear(d.getYear());
        return holidays.get(d);
    }

    public static Map<LocalDate, String> holidaysForYear(int year) {
        Map<LocalDate, String> out = new LinkedHashMap<>();
        LocalDate easter = easterSunday(year);
        out.put(LocalDate.of(year, Month.JANUARY, 1), "Neujahr");
        out.put(easter.minusDays(2), "Karfreitag");
        out.put(easter.plusDays(1), "Ostermontag");
        out.put(LocalDate.of(year, Month.MAY, 1), "Tag der Arbeit");
        out.put(easter.plusDays(39), "Christi Himmelfahrt");
        out.put(easter.plusDays(50), "Pfingstmontag");
        out.put(easter.plusDays(60), "Fronleichnam");
        out.put(LocalDate.of(year, Month.OCTOBER, 3), "Tag der Deutschen Einheit");
        out.put(LocalDate.of(year, Month.DECEMBER, 25), "1. Weihnachtsfeiertag");
        out.put(LocalDate.of(year, Month.DECEMBER, 26), "2. Weihnachtsfeiertag");
        return out;
    }

    // Gregorianischer Osteralgorithmus nach Meeus/Jones/Butcher.
    private static LocalDate easterSunday(int year) {
        int a = year % 19;
        int b = year / 100;
        int c = year % 100;
        int d = b / 4;
        int e = b % 4;
        int f = (b + 8) / 25;
        int g = (b - f + 1) / 3;
        int h = (19 * a + b - d - g + 15) % 30;
        int i = c / 4;
        int k = c % 4;
        int l = (32 + 2 * e + 2 * i - h - k) % 7;
        int m = (a + 11 * h + 22 * l) / 451;
        int month = (h + l - 7 * m + 114) / 31;
        int day = ((h + l - 7 * m + 114) % 31) + 1;
        return LocalDate.of(year, month, day);
    }
}
