package de.kita.krankmeldung.sms;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.provider.Telephony;

import de.kita.krankmeldung.data.AppDb;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Zugriffsschicht auf Androids SMS-Provider. Schreibzugriff hat die App als Standard-SMS-App. */
public class SmsStore {
    private final Context context;

    public SmsStore(Context context) { this.context = context.getApplicationContext(); }

    public void insertIncoming(String address, String body, long date) {
        try {
            ContentValues v = new ContentValues();
            v.put(Telephony.Sms.ADDRESS, address);
            v.put(Telephony.Sms.BODY, body);
            v.put(Telephony.Sms.DATE, date);
            v.put(Telephony.Sms.READ, 0);
            v.put(Telephony.Sms.SEEN, 0);
            context.getContentResolver().insert(Telephony.Sms.Inbox.CONTENT_URI, v);
        } catch (Exception ignored) {}
    }

    public void insertSent(String address, String body, long date) {
        try {
            ContentValues v = new ContentValues();
            v.put(Telephony.Sms.ADDRESS, address);
            v.put(Telephony.Sms.BODY, body);
            v.put(Telephony.Sms.DATE, date);
            v.put(Telephony.Sms.READ, 1);
            v.put(Telephony.Sms.SEEN, 1);
            context.getContentResolver().insert(Telephony.Sms.Sent.CONTENT_URI, v);
        } catch (Exception ignored) {}
    }

    public List<SmsItem> recentMessages(int limit) {
        List<SmsItem> out = new ArrayList<>();
        String[] projection = {"_id", "address", "body", "date", "type", "read"};
        try (Cursor c = context.getContentResolver().query(Telephony.Sms.CONTENT_URI, projection, null, null, "date DESC")) {
            if (c != null) {
                int count = 0;
                while (c.moveToNext() && count < Math.max(1, limit)) {
                    out.add(itemFrom(c));
                    count++;
                }
            }
        } catch (Exception ignored) {}
        return out;
    }

    public List<ThreadItem> recentThreads(int scanLimit, int threadLimit) {
        List<SmsItem> all = recentMessages(scanLimit);
        Map<String, ThreadItem> map = new LinkedHashMap<>();
        for (SmsItem item : all) {
            String key = AppDb.normalizePhone(item.address);
            ThreadItem t = map.get(key);
            if (t == null) {
                t = new ThreadItem(item.address, item.body, item.date, item.incoming(), 0);
                map.put(key, t);
            }
            if (item.incoming() && !item.read) t.unreadCount++;
        }
        List<ThreadItem> out = new ArrayList<>();
        for (ThreadItem t : map.values()) {
            out.add(t);
            if (out.size() >= threadLimit) break;
        }
        return out;
    }

    public List<SmsItem> search(String query, int scanLimit, int resultLimit) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.GERMANY);
        if (q.isEmpty()) return new ArrayList<>();
        AppDb db = new AppDb(context);
        List<SmsItem> out = new ArrayList<>();
        for (SmsItem item : recentMessages(scanLimit)) {
            AppDb.Employee e = db.findEmployeeByPhone(item.address);
            String name = e == null ? "" : e.name.toLowerCase(Locale.GERMANY);
            String address = item.address == null ? "" : item.address.toLowerCase(Locale.GERMANY);
            String body = item.body == null ? "" : item.body.toLowerCase(Locale.GERMANY);
            if (name.contains(q) || address.contains(q) || body.contains(q)) {
                out.add(item);
                if (out.size() >= resultLimit) break;
            }
        }
        return out;
    }

    public List<SmsItem> conversation(String address, int limit) {
        List<SmsItem> out = new ArrayList<>();
        String target = AppDb.normalizePhone(address);
        for (SmsItem item : recentMessages(Math.max(1000, limit * 8))) {
            if (AppDb.normalizePhone(item.address).equals(target)) {
                out.add(0, item);
                if (out.size() >= Math.max(1, limit)) break;
            }
        }
        return out;
    }

    public void markConversationRead(String address) {
        try {
            ContentValues v = new ContentValues();
            v.put(Telephony.Sms.READ, 1);
            v.put(Telephony.Sms.SEEN, 1);
            String n = AppDb.normalizePhone(address);
            if (n.startsWith("+49") && n.length() > 3) {
                String local = "0" + n.substring(3);
                String intl00 = "0049" + n.substring(3);
                context.getContentResolver().update(Telephony.Sms.Inbox.CONTENT_URI, v, "address IN (?,?,?) AND read=0", new String[]{n, local, intl00});
            } else {
                context.getContentResolver().update(Telephony.Sms.Inbox.CONTENT_URI, v, "address=? AND read=0", new String[]{address});
            }
        } catch (Exception ignored) {}
    }

    private SmsItem itemFrom(Cursor c) {
        return new SmsItem(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), c.getInt(4), c.getInt(5) == 1);
    }

    public static class ThreadItem {
        public final String address;
        public final String lastBody;
        public final long lastDate;
        public final boolean lastIncoming;
        public int unreadCount;
        public ThreadItem(String address, String lastBody, long lastDate, boolean lastIncoming, int unreadCount) {
            this.address=address==null?"":address; this.lastBody=lastBody==null?"":lastBody; this.lastDate=lastDate; this.lastIncoming=lastIncoming; this.unreadCount=unreadCount;
        }
    }

    public static class SmsItem {
        public final long id;
        public final String address;
        public final String body;
        public final long date;
        public final int type;
        public final boolean read;

        public SmsItem(long id, String address, String body, long date, int type, boolean read) {
            this.id = id;
            this.address = address == null ? "" : address;
            this.body = body == null ? "" : body;
            this.date = date;
            this.type = type;
            this.read = read;
        }

        public boolean incoming() { return type == Telephony.Sms.MESSAGE_TYPE_INBOX; }
    }
}
