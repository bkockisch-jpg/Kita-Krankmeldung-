package de.kita.krankmeldung.sms;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class WapPushReceiver extends BroadcastReceiver { @Override public void onReceive(Context context, Intent intent) { /* MMS is outside this app's scope. Component exists so Android can grant the SMS role. */ } }
