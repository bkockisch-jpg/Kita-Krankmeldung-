package de.kita.krankmeldung.sms;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Die Komponente ist für die Android-SMS-Rolle erforderlich. MMS-Auswertung folgt später. */
public class WapPushReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        try {
            String id = "mms_notice";
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(id, "MMS", NotificationManager.IMPORTANCE_DEFAULT));
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(context, id) : new android.app.Notification.Builder(context);
            b.setSmallIcon(android.R.drawable.stat_notify_more)
                    .setContentTitle("MMS empfangen")
                    .setContentText("MMS wird in dieser Testversion noch nicht angezeigt.")
                    .setAutoCancel(true);
            nm.notify(2002, b.build());
        } catch (Exception ignored) {}
    }
}
