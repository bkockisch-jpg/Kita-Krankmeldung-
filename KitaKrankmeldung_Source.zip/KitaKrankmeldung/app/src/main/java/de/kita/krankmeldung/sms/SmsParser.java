package de.kita.krankmeldung.sms;

import de.kita.krankmeldung.util.WorkCalendar;

import java.text.Normalizer;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Regelbasierter Parser für natürliche deutschsprachige Rückmeldungen.
 * Er trifft nur bei hoher Sicherheit automatische Entscheidungen. Unsichere Texte
 * werden mit einem Vorschlag versehen und landen im Prüfbereich.
 */
public class SmsParser {
    public enum Type { ABSENT, RETURN, UNKNOWN }

    public static class Result {
        public final Type type;
        public final LocalDate start;
        public final LocalDate until;
        public final double confidence;
        public final String summary;

        public Result(Type type, LocalDate start, LocalDate until, double confidence, String summary) {
            this.type = type;
            this.start = start;
            this.until = until;
            this.confidence = confidence;
            this.summary = summary == null ? "" : summary;
        }

        public boolean canAutoApply() { return type != Type.UNKNOWN && confidence >= 0.82; }
        public boolean hasSuggestion() { return type != Type.UNKNOWN && confidence >= 0.45; }
    }

    public Result parse(String raw, LocalDate referenceDate) {
        if (raw == null || raw.trim().isEmpty()) return unknown();
        String s = normalize(raw);
        boolean uncertain = containsAny(s, "vielleicht", "eventuell", "vermutlich", "wahrscheinlich", "hoffentlich", "mal sehen", "weis noch nicht", "weiß noch nicht", "denke ich", "sollte eigentlich");

        LocalDate nextWorkday = WorkCalendar.nextBusinessDay(referenceDate);

        // Explizite Rückkehr für heute.
        if (containsAny(s, "heute wieder da", "bin heute wieder da", "heute bin ich wieder da", "bin heute im dienst", "heute wieder im dienst", "ab heute wieder da", "jetzt wieder da")) {
            return new Result(Type.RETURN, referenceDate, null, uncertain ? 0.64 : 0.96,
                    "Heute wieder im Dienst (" + formatGerman(referenceDate) + ")");
        }

        // Klare Rückkehrmeldungen zuerst, damit "nicht mehr krank" nicht als krank erkannt wird.
        if (containsAny(s,
                "morgen wieder da", "morgen bin ich wieder da", "morgen komme ich wieder", "morgen wieder im dienst",
                "ab morgen wieder da", "ab morgen wieder im dienst", "nachstes mal wieder da", "nachsten arbeitstag wieder da", "nächsten arbeitstag wieder da",
                "bin morgen ganz normal da", "morgen ganz normal da", "bin dann ganz normal da", "morgen bin ich ganz normal da", "wieder da")) {
            double confidence = uncertain ? 0.64 : 0.95;
            return new Result(Type.RETURN, nextWorkday, null, confidence,
                    "Rückkehr zum nächsten Arbeitstag (" + formatGerman(nextWorkday) + ")");
        }
        if (s.contains("nicht mehr krank") && containsAny(s, "morgen", "wieder", "dienst")) {
            return new Result(Type.RETURN, nextWorkday, null, uncertain ? 0.62 : 0.90,
                    "Rückkehr zum nächsten Arbeitstag (" + formatGerman(nextWorkday) + ")");
        }

        LocalDate explicitUntil = extractDateOrWeekday(s, referenceDate);
        boolean explicitNotAbsent = containsAny(s, "bin nicht krank", "nicht krank", "bin gesund", "wieder gesund")
                && !containsAny(s, "kind krank", "kind ist krank", "mein kind", "komme nicht", "kann nicht kommen", "falle aus", "fallt aus", "bin nicht da")
                && !(s.contains("komme") && s.contains("nicht"));
        if (explicitNotAbsent) return unknown();

        boolean absenceSignal = containsAny(s,
                "krank", "krankgeschrieben", "arbeitsunfahig", "arbeitsunfähig", "au bis", "falle aus", "fall aus", "fallt aus",
                "komme nicht", "kann nicht kommen", "bin nicht da", "bleibe zuhause", "bleib zuhause",
                "muss zuhause bleiben", "kind krank", "kindkrank", "melde mich krank", "mich krankmelden",
                "schaffe es heute nicht", "schaff es heute nicht", "geht mir nicht gut", "mir gehts nicht gut", "mir geht s nicht gut", "mir geht es nicht gut",
                "rausgenommen", "bin raus", "arbeitsunfahigkeitsbescheinigung")
                || (s.contains("komme") && s.contains("nicht"))
                || (s.contains("kommen") && s.contains("nicht"))
                || (s.contains("zuhause") && (s.contains("bleibe") || s.contains("bleib") || s.contains("bleiben")))
                || (s.contains("arzt") && s.contains("bis"));

        if (absenceSignal && explicitUntil != null) {
            LocalDate start = inferStartDate(s, referenceDate, nextWorkday);
            if (explicitUntil.isBefore(start)) explicitUntil = start;
            double confidence = uncertain ? 0.64 : 0.94;
            return new Result(Type.ABSENT, start, explicitUntil, confidence,
                    "Abwesend " + describeRange(start, explicitUntil));
        }

        LocalDate relativeUntil = extractRelativeDuration(s, referenceDate);
        if (absenceSignal && relativeUntil != null) {
            LocalDate start = inferStartDate(s, referenceDate, nextWorkday);
            double confidence = uncertain ? 0.60 : 0.88;
            return new Result(Type.ABSENT, start, relativeUntil, confidence,
                    "Abwesend " + describeRange(start, relativeUntil));
        }

        if (containsAny(s, "morgen noch krank", "morgen auch krank", "morgen falle ich auch aus", "morgen fall ich auch aus", "morgen komme ich nicht", "morgen bin ich nicht da")) {
            return new Result(Type.ABSENT, nextWorkday, nextWorkday, uncertain ? 0.62 : 0.92,
                    "Am nächsten Arbeitstag abwesend (" + formatGerman(nextWorkday) + ")");
        }

        if (absenceSignal) {
            LocalDate start = inferStartDate(s, referenceDate, nextWorkday);
            double confidence = uncertain ? 0.58 : 0.86;
            String summary = start.equals(referenceDate)
                    ? "Heute abwesend, Dauer noch offen"
                    : "Am nächsten Arbeitstag abwesend (" + formatGerman(start) + ")";
            return new Result(Type.ABSENT, start, null, confidence, summary);
        }

        // Etwas weichere Rückkehrformulierungen werden als Vorschlag, nicht automatisch, erkannt.
        if (containsAny(s, "morgen sollte es wieder gehen", "denke morgen bin ich wieder da", "morgen wahrscheinlich wieder da")) {
            return new Result(Type.RETURN, nextWorkday, null, 0.60,
                    "Vermutlich Rückkehr zum nächsten Arbeitstag (" + formatGerman(nextWorkday) + ")");
        }

        return unknown();
    }

    private LocalDate inferStartDate(String s, LocalDate today, LocalDate nextWorkday) {
        if (containsAny(s, "morgen", "nachsten arbeitstag", "nächsten arbeitstag", "ab montag", "ab dienstag", "ab mittwoch", "ab donnerstag", "ab freitag")) {
            LocalDate explicit = extractStartWeekday(s, today);
            return explicit == null ? nextWorkday : explicit;
        }
        return today;
    }

    private LocalDate extractStartWeekday(String s, LocalDate today) {
        String[] names = {"montag","dienstag","mittwoch","donnerstag","freitag","samstag","sonntag"};
        for (int i=0;i<names.length;i++) {
            if (s.contains("ab " + names[i])) return onOrNextWeekday(today, DayOfWeek.of(i+1));
        }
        return null;
    }

    public LocalDate extractDateOrWeekday(String s, LocalDate referenceDate) {
        Matcher iso = Pattern.compile("\\b(20\\d{2})-(\\d{1,2})-(\\d{1,2})\\b").matcher(s);
        if (iso.find()) {
            try { return LocalDate.of(Integer.parseInt(iso.group(1)), Integer.parseInt(iso.group(2)), Integer.parseInt(iso.group(3))); } catch (Exception ignored) {}
        }

        Matcher full = Pattern.compile("\\b(\\d{1,2})[.](\\d{1,2})[.](\\d{2,4})\\b").matcher(s);
        if (full.find()) {
            int year = Integer.parseInt(full.group(3)); if (year < 100) year += 2000;
            try { return LocalDate.of(year, Integer.parseInt(full.group(2)), Integer.parseInt(full.group(1))); } catch (Exception ignored) {}
        }

        Matcher shortD = Pattern.compile("\\b(\\d{1,2})[.](\\d{1,2})[.]?\\b").matcher(s);
        if (shortD.find()) {
            int day = Integer.parseInt(shortD.group(1)), month = Integer.parseInt(shortD.group(2));
            try {
                LocalDate d = LocalDate.of(referenceDate.getYear(), month, day);
                if (d.isBefore(referenceDate.minusDays(1))) d = d.plusYears(1);
                return d;
            } catch (Exception ignored) {}
        }

        String[] names = {"montag","dienstag","mittwoch","donnerstag","freitag","samstag","sonntag"};
        for (int i=0;i<names.length;i++) if (s.contains(names[i])) return onOrNextWeekday(referenceDate, DayOfWeek.of(i+1));
        if (s.contains("ende der woche")) return onOrNextWeekday(referenceDate, DayOfWeek.FRIDAY);
        return null;
    }

    private LocalDate extractRelativeDuration(String s, LocalDate referenceDate) {
        Matcher m = Pattern.compile("(?:noch|fur|für)\\s+(\\d{1,2})\\s+(tag|tage|tagen)").matcher(s);
        if (m.find()) {
            int days = Integer.parseInt(m.group(1));
            if (days >= 1 && days <= 31) return referenceDate.plusDays(days);
        }
        if (containsAny(s, "noch einen tag", "noch 1 tag")) return referenceDate.plusDays(1);
        if (containsAny(s, "noch zwei tage", "noch 2 tage")) return referenceDate.plusDays(2);
        if (containsAny(s, "noch drei tage", "noch 3 tage")) return referenceDate.plusDays(3);
        return null;
    }

    private LocalDate onOrNextWeekday(LocalDate from, DayOfWeek target) {
        LocalDate d = from;
        while (d.getDayOfWeek() != target) d = d.plusDays(1);
        return d;
    }

    private boolean containsAny(String s, String... needles) {
        for (String n : needles) if (s.contains(n)) return true;
        return false;
    }

    private String normalize(String raw) {
        String s = raw.toLowerCase(Locale.GERMANY).replace('ß', 's');
        s = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return s.replaceAll("[^a-z0-9äöü. +]", " ").replaceAll("\\s+", " ").trim();
    }

    private String describeRange(LocalDate start, LocalDate end) {
        if (end == null) return "ab " + formatGerman(start) + " (offen)";
        if (start.equals(end)) return "am " + formatGerman(start);
        return "von " + formatGerman(start) + " bis einschließlich " + formatGerman(end);
    }

    private Result unknown() { return new Result(Type.UNKNOWN, null, null, 0.0, "Nicht sicher erkannt"); }

    public static String formatGerman(LocalDate d) { return d.format(DateTimeFormatter.ofPattern("dd.MM.yyyy")); }
}
