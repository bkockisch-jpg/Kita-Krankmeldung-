package de.kita.krankmeldung.sms;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmsParser {
    public enum Type { SICK, RETURN_TOMORROW, SICK_UNTIL, UNKNOWN }
    public static class Result { public final Type type; public final LocalDate until; public Result(Type type, LocalDate until){this.type=type;this.until=until;} }

    public Result parse(String raw, LocalDate today) {
        if (raw == null) return new Result(Type.UNKNOWN, null);
        String s = raw.trim().toLowerCase(Locale.GERMANY).replaceAll("\\s+", " ");

        if (s.equals("morgen da") || s.contains("morgen wieder da") || s.contains("morgen wieder im dienst") || s.equals("wieder da"))
            return new Result(Type.RETURN_TOMORROW, null);

        if (s.startsWith("krank bis") || s.startsWith("verlängert bis") || s.startsWith("verlaengert bis") || s.contains("noch krank bis") || s.contains("falle") && s.contains("bis")) {
            LocalDate d = extractDateOrWeekday(s, today);
            if (d != null && !d.isBefore(today)) return new Result(Type.SICK_UNTIL, d);
        }

        if (s.equals("krank") || s.startsWith("krank ") || s.equals("heute krank") || s.contains("bin heute krank") || s.contains("komme heute nicht"))
            return new Result(Type.SICK, null);

        return new Result(Type.UNKNOWN, null);
    }

    private LocalDate extractDateOrWeekday(String s, LocalDate today) {
        Matcher full = Pattern.compile("(\\d{1,2})\\.(\\d{1,2})\\.(\\d{2,4})").matcher(s);
        if (full.find()) {
            int year = Integer.parseInt(full.group(3)); if (year < 100) year += 2000;
            try { return LocalDate.of(year, Integer.parseInt(full.group(2)), Integer.parseInt(full.group(1))); } catch (Exception ignored) {}
        }
        Matcher shortD = Pattern.compile("(\\d{1,2})\\.(\\d{1,2})\\.?").matcher(s);
        if (shortD.find()) {
            int day = Integer.parseInt(shortD.group(1)), month = Integer.parseInt(shortD.group(2));
            try {
                LocalDate d = LocalDate.of(today.getYear(), month, day);
                if (d.isBefore(today.minusDays(1))) d = d.plusYears(1);
                return d;
            } catch (Exception ignored) {}
        }
        String[] names = {"montag","dienstag","mittwoch","donnerstag","freitag","samstag","sonntag"};
        for (int i=0;i<names.length;i++) if (s.contains(names[i])) {
            DayOfWeek target = DayOfWeek.of(i+1);
            LocalDate d=today; while (d.getDayOfWeek()!=target) d=d.plusDays(1); return d;
        }
        if (s.contains("morgen")) return today.plusDays(1);
        return null;
    }

    public static String formatGerman(LocalDate d) { return d.format(DateTimeFormatter.ofPattern("dd.MM.yyyy")); }
}
