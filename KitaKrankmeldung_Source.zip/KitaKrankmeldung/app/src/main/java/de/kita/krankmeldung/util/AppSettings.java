package de.kita.krankmeldung.util;

import android.content.Context;
import android.content.SharedPreferences;

public class AppSettings {
    private static final String PREFS = "settings";
    private static final String KEY_TEST_MODE = "test_mode";
    private static final String KEY_TEST_NUMBER = "test_number";
    private static final String KEY_AUTO_ADDENDUM = "auto_addendum";

    private final SharedPreferences prefs;

    public AppSettings(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean isTestMode() { return prefs.getBoolean(KEY_TEST_MODE, false); }
    public void setTestMode(boolean enabled) { prefs.edit().putBoolean(KEY_TEST_MODE, enabled).apply(); }

    public String getTestNumber() { return prefs.getString(KEY_TEST_NUMBER, "").trim(); }
    public void setTestNumber(String number) { prefs.edit().putString(KEY_TEST_NUMBER, number == null ? "" : number.trim()).apply(); }

    public boolean isAutoAddendumEnabled() { return prefs.getBoolean(KEY_AUTO_ADDENDUM, true); }
    public void setAutoAddendumEnabled(boolean enabled) { prefs.edit().putBoolean(KEY_AUTO_ADDENDUM, enabled).apply(); }
}
