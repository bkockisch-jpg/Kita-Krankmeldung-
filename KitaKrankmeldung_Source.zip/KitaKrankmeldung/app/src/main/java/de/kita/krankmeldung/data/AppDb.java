package de.kita.krankmeldung.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.Normalizer;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AppDb extends SQLiteOpenHelper {
    private static final String DB_NAME = "kita_krankmeldung.db";
    private static final int DB_VERSION = 4;

    public AppDb(Context context) { super(context.getApplicationContext(), DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE employees (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1, leader INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE absences (id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, start_date TEXT NOT NULL, end_date TEXT, source TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, FOREIGN KEY(employee_id) REFERENCES employees(id))");
        db.execSQL("CREATE TABLE inbound (id INTEGER PRIMARY KEY AUTOINCREMENT, fingerprint TEXT NOT NULL UNIQUE, employee_id INTEGER, phone TEXT NOT NULL, body TEXT NOT NULL, received_at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'RECEIVED', interpretation TEXT, confidence REAL NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE send_log (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, employee_id INTEGER, day TEXT NOT NULL, sent_at INTEGER NOT NULL, UNIQUE(kind, employee_id, day))");
        db.execSQL("CREATE TABLE send_attempts (id INTEGER PRIMARY KEY AUTOINCREMENT, original_recipient TEXT NOT NULL, actual_recipient TEXT NOT NULL, body TEXT NOT NULL, kind TEXT NOT NULL, employee_id INTEGER, automatic INTEGER NOT NULL DEFAULT 0, test_routed INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, status TEXT NOT NULL, error_code INTEGER, retry_of INTEGER)");
        db.execSQL("CREATE TABLE audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, event_type TEXT NOT NULL, employee_id INTEGER, details TEXT, source TEXT, created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE remote_sessions (phone TEXT PRIMARY KEY, leader_id INTEGER NOT NULL, action TEXT NOT NULL, employee_id INTEGER, payload TEXT, expires_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE day_status (employee_id INTEGER NOT NULL, day TEXT NOT NULL, status TEXT NOT NULL, source TEXT, updated_at INTEGER NOT NULL, PRIMARY KEY(employee_id,day))");
        db.execSQL("CREATE INDEX idx_absences_dates ON absences(start_date,end_date)");
        db.execSQL("CREATE INDEX idx_inbound_status ON inbound(status,received_at)");
        db.execSQL("CREATE INDEX idx_send_attempts_status ON send_attempts(status,created_at)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            tryExec(db, "ALTER TABLE inbound ADD COLUMN interpretation TEXT");
            tryExec(db, "ALTER TABLE inbound ADD COLUMN confidence REAL NOT NULL DEFAULT 0");
            tryExec(db, "CREATE TABLE send_attempts (id INTEGER PRIMARY KEY AUTOINCREMENT, original_recipient TEXT NOT NULL, actual_recipient TEXT NOT NULL, body TEXT NOT NULL, kind TEXT NOT NULL, employee_id INTEGER, automatic INTEGER NOT NULL DEFAULT 0, test_routed INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, status TEXT NOT NULL, error_code INTEGER, retry_of INTEGER)");
            tryExec(db, "CREATE TABLE audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, event_type TEXT NOT NULL, employee_id INTEGER, details TEXT, source TEXT, created_at INTEGER NOT NULL)");
        }
        if (oldVersion < 3) {
            tryExec(db, "CREATE TABLE remote_sessions (phone TEXT PRIMARY KEY, leader_id INTEGER NOT NULL, action TEXT NOT NULL, employee_id INTEGER, payload TEXT, expires_at INTEGER NOT NULL)");
            tryExec(db, "CREATE INDEX idx_absences_dates ON absences(start_date,end_date)");
            tryExec(db, "CREATE INDEX idx_inbound_status ON inbound(status,received_at)");
            tryExec(db, "CREATE INDEX idx_send_attempts_status ON send_attempts(status,created_at)");
        }
        if (oldVersion < 4) {
            tryExec(db, "CREATE TABLE day_status (employee_id INTEGER NOT NULL, day TEXT NOT NULL, status TEXT NOT NULL, source TEXT, updated_at INTEGER NOT NULL, PRIMARY KEY(employee_id,day))");
        }
    }

    private void tryExec(SQLiteDatabase db, String sql) { try { db.execSQL(sql); } catch (Exception ignored) {} }

    public long upsertEmployee(Long id, String name, String phone, boolean leader, boolean active) {
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        v.put("phone", normalizePhone(phone));
        v.put("leader", leader ? 1 : 0);
        v.put("active", active ? 1 : 0);
        if (id == null) return getWritableDatabase().insertOrThrow("employees", null, v);
        getWritableDatabase().update("employees", v, "id=?", new String[]{String.valueOf(id)});
        return id;
    }

    public void updateEmployeePhone(long id, String phone) {
        ContentValues v = new ContentValues();
        v.put("phone", normalizePhone(phone));
        getWritableDatabase().update("employees", v, "id=?", new String[]{String.valueOf(id)});
    }

    public void deleteEmployee(long id) { getWritableDatabase().delete("employees", "id=?", new String[]{String.valueOf(id)}); }

    public Employee findEmployeeByPhone(String rawPhone) {
        String phone = normalizePhone(rawPhone);
        try (Cursor c = getReadableDatabase().query("employees", null, "phone=?", new String[]{phone}, null, null, null)) {
            if (c.moveToFirst()) return employeeFrom(c);
        }
        String digits = phone.replaceAll("\\D", "");
        if (digits.length() >= 8) {
            String tail = digits.substring(digits.length() - 8);
            for (Employee e : allEmployees(false)) {
                String ed = normalizePhone(e.phone).replaceAll("\\D", "");
                if (ed.endsWith(tail)) return e;
            }
        }
        return null;
    }

    public Employee findEmployeeByNameLoose(String raw) {
        String needle = simplify(raw);
        if (needle.isEmpty()) return null;
        Employee partial = null;
        int partialCount = 0;
        for (Employee e : allEmployees(true)) {
            String n = simplify(e.name);
            if (n.equals(needle)) return e;
            if (n.startsWith(needle) || needle.startsWith(n)) { partial = e; partialCount++; }
        }
        return partialCount == 1 ? partial : null;
    }

    public Employee getEmployee(long id) {
        try (Cursor c = getReadableDatabase().query("employees", null, "id=?", new String[]{String.valueOf(id)}, null, null, null)) {
            if (c.moveToFirst()) return employeeFrom(c);
        }
        return null;
    }

    public List<Employee> allEmployees(boolean onlyActive) {
        List<Employee> out = new ArrayList<>();
        String where = onlyActive ? "active=1" : null;
        try (Cursor c = getReadableDatabase().query("employees", null, where, null, null, null, "name COLLATE NOCASE")) {
            while (c.moveToNext()) out.add(employeeFrom(c));
        }
        return out;
    }

    public List<Employee> leaders() {
        List<Employee> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query("employees", null, "active=1 AND leader=1", null, null, null, "name COLLATE NOCASE")) {
            while (c.moveToNext()) out.add(employeeFrom(c));
        }
        return out;
    }

    public long markAbsent(long employeeId, LocalDate start, LocalDate end, String source) {
        Absence current = latestOpenAbsence(employeeId, start);
        long now = System.currentTimeMillis();
        clearPresentStatuses(employeeId, start, end == null ? start : end);
        // Eine alte offene Ein-Tages-Meldung darf eine neue ausdrückliche Meldung am Folgetag
        // nicht verschlucken. Historie schließen und für den neuen Tag einen neuen Datensatz anlegen.
        if (current != null && current.endDate == null && current.startDate.isBefore(start)) {
            setAbsenceEnd(current.id, start.minusDays(1), "carried-unresolved");
            current = null;
        }
        if (current != null) {
            ContentValues v = new ContentValues();
            if (end != null) v.put("end_date", end.toString()); else v.putNull("end_date");
            v.put("updated_at", now);
            v.put("source", source);
            getWritableDatabase().update("absences", v, "id=?", new String[]{String.valueOf(current.id)});
            audit("ABSENCE_UPDATED", employeeId, start + " bis " + (end == null ? "offen" : end), source);
            return current.id;
        }
        ContentValues v = new ContentValues();
        v.put("employee_id", employeeId);
        v.put("start_date", start.toString());
        if (end != null) v.put("end_date", end.toString());
        v.put("source", source);
        v.put("created_at", now);
        v.put("updated_at", now);
        long id = getWritableDatabase().insertOrThrow("absences", null, v);
        audit("ABSENCE_CREATED", employeeId, start + " bis " + (end == null ? "offen" : end), source);
        return id;
    }

    public void setAbsenceEnd(long absenceId, LocalDate end, String source) {
        Absence existing = getAbsence(absenceId);
        if (existing != null && end != null) clearPresentStatuses(existing.employeeId, existing.startDate, end);
        ContentValues v = new ContentValues();
        if (end == null) v.putNull("end_date"); else v.put("end_date", end.toString());
        v.put("updated_at", System.currentTimeMillis());
        v.put("source", source);
        getWritableDatabase().update("absences", v, "id=?", new String[]{String.valueOf(absenceId)});
    }

    public Absence getAbsence(long absenceId) {
        try (Cursor c = getReadableDatabase().query("absences", null, "id=?", new String[]{String.valueOf(absenceId)}, null, null, null)) {
            if (c.moveToFirst()) return absenceFrom(c);
        }
        return null;
    }

    public boolean setReturnDate(long employeeId, LocalDate returnDate) {
        Absence a = latestOpenAbsence(employeeId, returnDate);
        if (a == null) a = latestAbsence(employeeId);
        if (a == null) return false;
        LocalDate end = returnDate.minusDays(1);
        // Eine Rückkehrbestätigung darf eine laufende/längere Abwesenheit verkürzen.
        // Endet die Abwesenheit ohnehin früher, bleibt ihr historisches Enddatum unverändert.
        if (a.endDate == null || a.endDate.isAfter(end)) {
            if (end.isBefore(a.startDate)) {
                getWritableDatabase().delete("absences", "id=?", new String[]{String.valueOf(a.id)});
            } else {
                setAbsenceEnd(a.id, end, "return-confirmed");
            }
        }
        setDayPresent(employeeId, returnDate, "return-confirmed");
        audit("RETURN_CONFIRMED", employeeId, "Rückkehr am " + returnDate, "sms");
        return true;
    }

    public boolean setReturnTomorrow(long employeeId, LocalDate today) {
        return setReturnDate(employeeId, today.plusDays(1));
    }

    public boolean extendUntil(long employeeId, LocalDate until, LocalDate today) {
        Absence a = latestOpenAbsence(employeeId, today);
        if (a == null) { markAbsent(employeeId, today, until, "sms-update"); return true; }
        setAbsenceEnd(a.id, until, "sms-update");
        audit("ABSENCE_EXTENDED", employeeId, "bis " + until, "sms");
        return true;
    }

    public Absence latestOpenAbsence(long employeeId, LocalDate onDate) {
        String sql = "SELECT * FROM absences WHERE employee_id=? AND start_date<=? AND (end_date IS NULL OR end_date>=?) ORDER BY start_date DESC,id DESC LIMIT 1";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{String.valueOf(employeeId), onDate.toString(), onDate.toString()})) {
            if (c.moveToFirst()) return absenceFrom(c);
        }
        return null;
    }

    public Absence latestAbsence(long employeeId) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT * FROM absences WHERE employee_id=? ORDER BY start_date DESC,id DESC LIMIT 1", new String[]{String.valueOf(employeeId)})) {
            if (c.moveToFirst()) return absenceFrom(c);
        }
        return null;
    }

    public List<AbsenceWithEmployee> absencesOn(LocalDate day) {
        List<AbsenceWithEmployee> out = new ArrayList<>();
        String sql = "SELECT a.id aid,a.employee_id,a.start_date,a.end_date,a.source,a.created_at,a.updated_at,e.name,e.phone,e.active,e.leader " +
                "FROM absences a JOIN employees e ON e.id=a.employee_id WHERE e.active=1 AND a.start_date<=? " +
                "AND ((a.end_date IS NULL AND a.start_date=?) OR (a.end_date IS NOT NULL AND a.end_date>=?)) ORDER BY e.name COLLATE NOCASE";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{day.toString(), day.toString(), day.toString()})) {
            while (c.moveToNext()) {
                Absence a = new Absence(c.getLong(0), c.getLong(1), LocalDate.parse(c.getString(2)), c.isNull(3) ? null : LocalDate.parse(c.getString(3)));
                Employee e = new Employee(c.getLong(1), c.getString(7), c.getString(8), c.getInt(9)==1, c.getInt(10)==1);
                out.add(new AbsenceWithEmployee(a, e));
            }
        }
        return out;
    }

    public List<AbsenceWithEmployee> unresolvedBefore(LocalDate day) {
        List<AbsenceWithEmployee> out = new ArrayList<>();
        String sql = "SELECT a.id aid,a.employee_id,a.start_date,a.end_date,a.source,a.created_at,a.updated_at,e.name,e.phone,e.active,e.leader " +
                "FROM absences a JOIN employees e ON e.id=a.employee_id WHERE e.active=1 AND a.end_date IS NULL AND a.start_date<? ORDER BY e.name COLLATE NOCASE";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{day.toString()})) {
            while (c.moveToNext()) {
                Absence a = new Absence(c.getLong(0), c.getLong(1), LocalDate.parse(c.getString(2)), null);
                Employee e = new Employee(c.getLong(1), c.getString(7), c.getString(8), c.getInt(9)==1, c.getInt(10)==1);
                out.add(new AbsenceWithEmployee(a, e));
            }
        }
        return out;
    }

    public List<AbsenceWithEmployee> needingFollowup(LocalDate today, LocalDate targetWorkday) {
        List<AbsenceWithEmployee> out = new ArrayList<>();
        java.util.HashSet<Long> seen = new java.util.HashSet<>();
        for (AbsenceWithEmployee awe : absencesOn(today)) {
            if (!isPresent(awe.employee.id, targetWorkday) && (awe.absence.endDate == null || awe.absence.endDate.isBefore(targetWorkday)) && seen.add(awe.employee.id)) out.add(awe);
        }
        for (AbsenceWithEmployee awe : unresolvedBefore(today)) {
            if (!isPresent(awe.employee.id, targetWorkday) && seen.add(awe.employee.id)) out.add(awe);
        }
        return out;
    }

    public void setDayPresent(long employeeId, LocalDate day, String source) {
        ContentValues v = new ContentValues();
        v.put("employee_id", employeeId); v.put("day", day.toString()); v.put("status", "PRESENT"); v.put("source", source); v.put("updated_at", System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("day_status", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public boolean isPresent(long employeeId, LocalDate day) {
        try (Cursor c = getReadableDatabase().query("day_status", new String[]{"status"}, "employee_id=? AND day=?", new String[]{String.valueOf(employeeId), day.toString()}, null, null, null)) {
            return c.moveToFirst() && "PRESENT".equals(c.getString(0));
        }
    }

    public List<Employee> presentOn(LocalDate day) {
        List<Employee> out = new ArrayList<>();
        String sql = "SELECT e.* FROM day_status d JOIN employees e ON e.id=d.employee_id WHERE d.day=? AND d.status='PRESENT' AND e.active=1 ORDER BY e.name COLLATE NOCASE";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{day.toString()})) {
            while (c.moveToNext()) out.add(employeeFrom(c));
        }
        return out;
    }

    private void clearPresentStatuses(long employeeId, LocalDate start, LocalDate end) {
        getWritableDatabase().delete("day_status", "employee_id=? AND status='PRESENT' AND day>=? AND day<=?", new String[]{String.valueOf(employeeId), start.toString(), end.toString()});
    }

    public boolean rememberInbound(String fingerprint, Long employeeId, String phone, String body, long receivedAt) {
        ContentValues v = new ContentValues();
        v.put("fingerprint", fingerprint);
        if (employeeId != null) v.put("employee_id", employeeId);
        v.put("phone", normalizePhone(phone));
        v.put("body", body);
        v.put("received_at", receivedAt);
        try { return getWritableDatabase().insertOrThrow("inbound", null, v) != -1; }
        catch (Exception duplicate) { return false; }
    }

    public void updateInbound(String fingerprint, String status, String interpretation, double confidence) {
        ContentValues v = new ContentValues();
        v.put("status", status);
        v.put("interpretation", interpretation);
        v.put("confidence", confidence);
        getWritableDatabase().update("inbound", v, "fingerprint=?", new String[]{fingerprint});
    }

    public void updateInboundById(long id, String status) {
        ContentValues v = new ContentValues(); v.put("status", status);
        getWritableDatabase().update("inbound", v, "id=?", new String[]{String.valueOf(id)});
    }

    public void assignInboundToEmployee(long id, long employeeId) {
        ContentValues v = new ContentValues(); v.put("employee_id", employeeId);
        getWritableDatabase().update("inbound", v, "id=?", new String[]{String.valueOf(id)});
    }

    public InboundMessage getInbound(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,employee_id,phone,body,received_at,status,interpretation,confidence FROM inbound WHERE id=?", new String[]{String.valueOf(id)})) {
            if (c.moveToFirst()) return inboundFrom(c);
        }
        return null;
    }

    public List<InboundMessage> recentInbound(int limit) {
        List<InboundMessage> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,employee_id,phone,body,received_at,status,interpretation,confidence FROM inbound ORDER BY received_at DESC LIMIT ?", new String[]{String.valueOf(limit)})) {
            while (c.moveToNext()) out.add(inboundFrom(c));
        }
        return out;
    }

    public List<InboundMessage> reviewInbound(int limit) {
        List<InboundMessage> out = new ArrayList<>();
        String sql = "SELECT id,employee_id,phone,body,received_at,status,interpretation,confidence FROM inbound WHERE status IN ('NEEDS_REVIEW','UNKNOWN_SENDER','REMOTE_NEEDS_REVIEW') ORDER BY received_at DESC LIMIT ?";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{String.valueOf(limit)})) {
            while (c.moveToNext()) out.add(inboundFrom(c));
        }
        return out;
    }

    public boolean hasSent(String kind, Long employeeId, LocalDate day) {
        String employeeClause = employeeId == null ? "employee_id IS NULL" : "employee_id=?";
        String[] args = employeeId == null ? new String[]{kind, day.toString()} : new String[]{kind, String.valueOf(employeeId), day.toString()};
        try (Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM send_log WHERE kind=? AND " + employeeClause + " AND day=? LIMIT 1", args)) { return c.moveToFirst(); }
    }

    public void logSent(String kind, Long employeeId, LocalDate day) {
        ContentValues v = new ContentValues();
        v.put("kind", kind); if (employeeId != null) v.put("employee_id", employeeId); v.put("day", day.toString()); v.put("sent_at", System.currentTimeMillis());
        try { getWritableDatabase().insertOrThrow("send_log", null, v); } catch (Exception ignored) {}
    }

    public void clearTodayAbsence(long employeeId, LocalDate day) {
        Absence a = latestOpenAbsence(employeeId, day);
        if (a == null) return;
        if (a.startDate.isBefore(day)) {
            setAbsenceEnd(a.id, day.minusDays(1), "manual-correction");
        } else {
            getWritableDatabase().delete("absences", "id=?", new String[]{String.valueOf(a.id)});
        }
        setDayPresent(employeeId, day, "manual-correction");
        audit("ABSENCE_CORRECTED_PRESENT", employeeId, "anwesend am " + day, "manual");
    }

    public long createSendAttempt(String originalRecipient, String actualRecipient, String body, String kind, Long employeeId, boolean automatic, boolean testRouted, Long retryOf) {
        long now = System.currentTimeMillis();
        ContentValues v = new ContentValues();
        v.put("original_recipient", normalizePhone(originalRecipient));
        v.put("actual_recipient", normalizePhone(actualRecipient));
        v.put("body", body);
        v.put("kind", kind == null ? "sms" : kind);
        if (employeeId != null) v.put("employee_id", employeeId);
        v.put("automatic", automatic ? 1 : 0);
        v.put("test_routed", testRouted ? 1 : 0);
        v.put("created_at", now); v.put("updated_at", now); v.put("status", "QUEUED");
        if (retryOf != null) v.put("retry_of", retryOf);
        return getWritableDatabase().insertOrThrow("send_attempts", null, v);
    }

    public void updateSendStatus(long id, String status, Integer errorCode) {
        ContentValues v = new ContentValues();
        v.put("status", status); v.put("updated_at", System.currentTimeMillis());
        if (errorCode == null) v.putNull("error_code"); else v.put("error_code", errorCode);
        getWritableDatabase().update("send_attempts", v, "id=?", new String[]{String.valueOf(id)});
    }

    public SendAttempt getSendAttempt(long id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,original_recipient,actual_recipient,body,kind,employee_id,automatic,test_routed,created_at,updated_at,status,error_code,retry_of FROM send_attempts WHERE id=?", new String[]{String.valueOf(id)})) {
            if (c.moveToFirst()) return sendAttemptFrom(c);
        }
        return null;
    }

    public List<SendAttempt> recentSendAttempts(int limit) {
        List<SendAttempt> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,original_recipient,actual_recipient,body,kind,employee_id,automatic,test_routed,created_at,updated_at,status,error_code,retry_of FROM send_attempts ORDER BY created_at DESC LIMIT ?", new String[]{String.valueOf(limit)})) {
            while (c.moveToNext()) out.add(sendAttemptFrom(c));
        }
        return out;
    }

    public List<SendAttempt> failedSendAttempts(int limit) {
        List<SendAttempt> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,original_recipient,actual_recipient,body,kind,employee_id,automatic,test_routed,created_at,updated_at,status,error_code,retry_of FROM send_attempts WHERE status='FAILED' ORDER BY created_at DESC LIMIT ?", new String[]{String.valueOf(limit)})) {
            while (c.moveToNext()) out.add(sendAttemptFrom(c));
        }
        return out;
    }

    public void audit(String eventType, Long employeeId, String details, String source) {
        ContentValues v = new ContentValues();
        v.put("event_type", eventType);
        if (employeeId != null) v.put("employee_id", employeeId);
        v.put("details", details == null ? "" : details);
        v.put("source", source == null ? "" : source);
        v.put("created_at", System.currentTimeMillis());
        getWritableDatabase().insert("audit_log", null, v);
    }

    public void saveRemoteSession(String phone, long leaderId, String action, Long employeeId, String payload, long expiresAt) {
        ContentValues v = new ContentValues();
        v.put("phone", normalizePhone(phone)); v.put("leader_id", leaderId); v.put("action", action);
        if (employeeId != null) v.put("employee_id", employeeId); else v.putNull("employee_id");
        v.put("payload", payload == null ? "" : payload); v.put("expires_at", expiresAt);
        getWritableDatabase().insertWithOnConflict("remote_sessions", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public RemoteSession getRemoteSession(String phone) {
        String p = normalizePhone(phone);
        try (Cursor c = getReadableDatabase().query("remote_sessions", null, "phone=?", new String[]{p}, null, null, null)) {
            if (c.moveToFirst()) {
                RemoteSession s = new RemoteSession(c.getString(c.getColumnIndexOrThrow("phone")), c.getLong(c.getColumnIndexOrThrow("leader_id")), c.getString(c.getColumnIndexOrThrow("action")), c.isNull(c.getColumnIndexOrThrow("employee_id")) ? null : c.getLong(c.getColumnIndexOrThrow("employee_id")), c.getString(c.getColumnIndexOrThrow("payload")), c.getLong(c.getColumnIndexOrThrow("expires_at")));
                if (s.expiresAt >= System.currentTimeMillis()) return s;
            }
        }
        clearRemoteSession(phone);
        return null;
    }

    public void clearRemoteSession(String phone) { getWritableDatabase().delete("remote_sessions", "phone=?", new String[]{normalizePhone(phone)}); }

    private Employee employeeFrom(Cursor c) {
        return new Employee(c.getLong(c.getColumnIndexOrThrow("id")), c.getString(c.getColumnIndexOrThrow("name")), c.getString(c.getColumnIndexOrThrow("phone")), c.getInt(c.getColumnIndexOrThrow("active"))==1, c.getInt(c.getColumnIndexOrThrow("leader"))==1);
    }
    private Absence absenceFrom(Cursor c) {
        return new Absence(c.getLong(c.getColumnIndexOrThrow("id")), c.getLong(c.getColumnIndexOrThrow("employee_id")), LocalDate.parse(c.getString(c.getColumnIndexOrThrow("start_date"))), c.isNull(c.getColumnIndexOrThrow("end_date")) ? null : LocalDate.parse(c.getString(c.getColumnIndexOrThrow("end_date"))));
    }
    private InboundMessage inboundFrom(Cursor c) {
        return new InboundMessage(c.getLong(0), c.isNull(1) ? null : c.getLong(1), c.getString(2), c.getString(3), c.getLong(4), c.getString(5), c.getString(6), c.getDouble(7));
    }
    private SendAttempt sendAttemptFrom(Cursor c) {
        return new SendAttempt(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.isNull(5) ? null : c.getLong(5), c.getInt(6)==1, c.getInt(7)==1, c.getLong(8), c.getLong(9), c.getString(10), c.isNull(11) ? null : c.getInt(11), c.isNull(12) ? null : c.getLong(12));
    }

    public static String normalizePhone(String s) {
        if (s == null) return "";
        String x = s.trim().replaceAll("[\\s()/-]", "");
        if (x.startsWith("00")) x = "+" + x.substring(2);
        if (x.startsWith("0") && !x.startsWith("00")) x = "+49" + x.substring(1);
        return x;
    }

    private static String simplify(String s) {
        if (s == null) return "";
        String x = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase(Locale.GERMANY);
        return x.replaceAll("[^a-z0-9]", "");
    }

    public static class Employee {
        public final long id; public final String name; public final String phone; public final boolean active; public final boolean leader;
        public Employee(long id, String name, String phone, boolean active, boolean leader) { this.id=id;this.name=name;this.phone=phone;this.active=active;this.leader=leader; }
    }
    public static class Absence {
        public final long id; public final long employeeId; public final LocalDate startDate; public final LocalDate endDate;
        public Absence(long id,long employeeId,LocalDate startDate,LocalDate endDate){this.id=id;this.employeeId=employeeId;this.startDate=startDate;this.endDate=endDate;}
    }
    public static class AbsenceWithEmployee {
        public final Absence absence; public final Employee employee;
        public AbsenceWithEmployee(Absence absence,Employee employee){this.absence=absence;this.employee=employee;}
    }
    public static class InboundMessage {
        public final long id; public final Long employeeId; public final String phone; public final String body; public final long receivedAt; public final String status; public final String interpretation; public final double confidence;
        public InboundMessage(long id,Long employeeId,String phone,String body,long receivedAt,String status,String interpretation,double confidence){this.id=id;this.employeeId=employeeId;this.phone=phone;this.body=body;this.receivedAt=receivedAt;this.status=status;this.interpretation=interpretation;this.confidence=confidence;}
    }
    public static class SendAttempt {
        public final long id; public final String originalRecipient; public final String actualRecipient; public final String body; public final String kind; public final Long employeeId; public final boolean automatic; public final boolean testRouted; public final long createdAt; public final long updatedAt; public final String status; public final Integer errorCode; public final Long retryOf;
        public SendAttempt(long id,String originalRecipient,String actualRecipient,String body,String kind,Long employeeId,boolean automatic,boolean testRouted,long createdAt,long updatedAt,String status,Integer errorCode,Long retryOf){this.id=id;this.originalRecipient=originalRecipient;this.actualRecipient=actualRecipient;this.body=body;this.kind=kind;this.employeeId=employeeId;this.automatic=automatic;this.testRouted=testRouted;this.createdAt=createdAt;this.updatedAt=updatedAt;this.status=status;this.errorCode=errorCode;this.retryOf=retryOf;}
    }
    public static class RemoteSession {
        public final String phone; public final long leaderId; public final String action; public final Long employeeId; public final String payload; public final long expiresAt;
        public RemoteSession(String phone,long leaderId,String action,Long employeeId,String payload,long expiresAt){this.phone=phone;this.leaderId=leaderId;this.action=action;this.employeeId=employeeId;this.payload=payload;this.expiresAt=expiresAt;}
    }
}
