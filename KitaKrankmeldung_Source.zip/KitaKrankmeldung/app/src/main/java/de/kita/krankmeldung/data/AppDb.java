package de.kita.krankmeldung.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AppDb extends SQLiteOpenHelper {
    private static final String DB_NAME = "kita_krankmeldung.db";
    private static final int DB_VERSION = 1;

    public AppDb(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE employees (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1, leader INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE absences (id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, start_date TEXT NOT NULL, end_date TEXT, source TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, FOREIGN KEY(employee_id) REFERENCES employees(id))");
        db.execSQL("CREATE TABLE inbound (id INTEGER PRIMARY KEY AUTOINCREMENT, fingerprint TEXT NOT NULL UNIQUE, employee_id INTEGER, phone TEXT NOT NULL, body TEXT NOT NULL, received_at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'RECEIVED')");
        db.execSQL("CREATE TABLE send_log (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, employee_id INTEGER, day TEXT NOT NULL, sent_at INTEGER NOT NULL, UNIQUE(kind, employee_id, day))");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public long upsertEmployee(Long id, String name, String phone, boolean leader, boolean active) {
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        v.put("phone", normalizePhone(phone));
        v.put("leader", leader ? 1 : 0);
        v.put("active", active ? 1 : 0);
        if (id == null) return getWritableDatabase().insertOrThrow("employees", null, v);
        getWritableDatabase().update("employees", v, "id=?", new String[]{String.valueOf(id)});
        return id;
    }

    public void deleteEmployee(long id) { getWritableDatabase().delete("employees", "id=?", new String[]{String.valueOf(id)}); }

    public Employee findEmployeeByPhone(String rawPhone) {
        String phone = normalizePhone(rawPhone);
        try (Cursor c = getReadableDatabase().query("employees", null, "phone=?", new String[]{phone}, null, null, null)) {
            if (c.moveToFirst()) return employeeFrom(c);
        }
        // fallback for German numbers saved in a different international/local notation: compare last 8 digits
        String digits = phone.replaceAll("\\D", "");
        if (digits.length() >= 8) {
            String tail = digits.substring(digits.length() - 8);
            try (Cursor c = getReadableDatabase().rawQuery("SELECT * FROM employees WHERE REPLACE(REPLACE(REPLACE(REPLACE(phone,'+',''),' ',''),'-',''),'(', '') LIKE ?", new String[]{"%" + tail})) {
                if (c.moveToFirst()) return employeeFrom(c);
            }
        }
        return null;
    }

    public Employee getEmployee(long id) {
        try (Cursor c = getReadableDatabase().query("employees", null, "id=?", new String[]{String.valueOf(id)}, null, null, null)) {
            if (c.moveToFirst()) return employeeFrom(c);
        }
        return null;
    }

    public List<Employee> allEmployees(boolean onlyActive) {
        List<Employee> out = new ArrayList<>();
        String where = onlyActive ? "active=1" : null;
        try (Cursor c = getReadableDatabase().query("employees", null, where, null, null, null, "name COLLATE NOCASE")) {
            while (c.moveToNext()) out.add(employeeFrom(c));
        }
        return out;
    }

    public List<Employee> leaders() {
        List<Employee> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query("employees", null, "active=1 AND leader=1", null, null, null, "name COLLATE NOCASE")) {
            while (c.moveToNext()) out.add(employeeFrom(c));
        }
        return out;
    }

    public long markAbsent(long employeeId, LocalDate start, LocalDate end, String source) {
        Absence current = latestOpenAbsence(employeeId, start);
        long now = System.currentTimeMillis();
        if (current != null) {
            ContentValues v = new ContentValues();
            if (end != null) v.put("end_date", end.toString());
            else v.putNull("end_date");
            v.put("updated_at", now);
            v.put("source", source);
            getWritableDatabase().update("absences", v, "id=?", new String[]{String.valueOf(current.id)});
            return current.id;
        }
        ContentValues v = new ContentValues();
        v.put("employee_id", employeeId);
        v.put("start_date", start.toString());
        if (end != null) v.put("end_date", end.toString());
        v.put("source", source);
        v.put("created_at", now);
        v.put("updated_at", now);
        return getWritableDatabase().insertOrThrow("absences", null, v);
    }

    public boolean setReturnTomorrow(long employeeId, LocalDate today) {
        Absence a = latestOpenAbsence(employeeId, today);
        if (a == null) return false;
        ContentValues v = new ContentValues();
        v.put("end_date", today.toString());
        v.put("updated_at", System.currentTimeMillis());
        getWritableDatabase().update("absences", v, "id=?", new String[]{String.valueOf(a.id)});
        return true;
    }

    public boolean extendUntil(long employeeId, LocalDate until, LocalDate today) {
        Absence a = latestOpenAbsence(employeeId, today);
        if (a == null) {
            markAbsent(employeeId, today, until, "sms-update");
            return true;
        }
        ContentValues v = new ContentValues();
        v.put("end_date", until.toString());
        v.put("updated_at", System.currentTimeMillis());
        getWritableDatabase().update("absences", v, "id=?", new String[]{String.valueOf(a.id)});
        return true;
    }

    public Absence latestOpenAbsence(long employeeId, LocalDate onDate) {
        String sql = "SELECT * FROM absences WHERE employee_id=? AND start_date<=? AND (end_date IS NULL OR end_date>=?) ORDER BY start_date DESC,id DESC LIMIT 1";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{String.valueOf(employeeId), onDate.toString(), onDate.toString()})) {
            if (c.moveToFirst()) return absenceFrom(c);
        }
        return null;
    }

    public List<AbsenceWithEmployee> absencesOn(LocalDate day) {
        List<AbsenceWithEmployee> out = new ArrayList<>();
        String sql = "SELECT a.id aid,a.employee_id,a.start_date,a.end_date,a.source,a.created_at,a.updated_at,e.name,e.phone,e.active,e.leader " +
                "FROM absences a JOIN employees e ON e.id=a.employee_id WHERE e.active=1 AND a.start_date<=? AND (a.end_date IS NULL OR a.end_date>=?) ORDER BY e.name COLLATE NOCASE";
        try (Cursor c = getReadableDatabase().rawQuery(sql, new String[]{day.toString(), day.toString()})) {
            while (c.moveToNext()) {
                Absence a = new Absence(c.getLong(0), c.getLong(1), LocalDate.parse(c.getString(2)), c.isNull(3) ? null : LocalDate.parse(c.getString(3)));
                Employee e = new Employee(c.getLong(1), c.getString(7), c.getString(8), c.getInt(9)==1, c.getInt(10)==1);
                out.add(new AbsenceWithEmployee(a, e));
            }
        }
        return out;
    }

    public List<AbsenceWithEmployee> needingNoonFollowup(LocalDate today) {
        List<AbsenceWithEmployee> all = absencesOn(today);
        List<AbsenceWithEmployee> out = new ArrayList<>();
        for (AbsenceWithEmployee awe : all) {
            if (awe.absence.endDate == null || !awe.absence.endDate.isAfter(today)) out.add(awe);
        }
        return out;
    }

    public boolean rememberInbound(String fingerprint, Long employeeId, String phone, String body, long receivedAt) {
        ContentValues v = new ContentValues();
        v.put("fingerprint", fingerprint);
        if (employeeId != null) v.put("employee_id", employeeId);
        v.put("phone", normalizePhone(phone));
        v.put("body", body);
        v.put("received_at", receivedAt);
        try { return getWritableDatabase().insertOrThrow("inbound", null, v) != -1; }
        catch (Exception duplicate) { return false; }
    }

    public void setInboundStatus(String fingerprint, String status) {
        ContentValues v = new ContentValues(); v.put("status", status);
        getWritableDatabase().update("inbound", v, "fingerprint=?", new String[]{fingerprint});
    }

    public boolean hasSent(String kind, Long employeeId, LocalDate day) {
        String employeeClause = employeeId == null ? "employee_id IS NULL" : "employee_id=?";
        String[] args = employeeId == null ? new String[]{kind, day.toString()} : new String[]{kind, String.valueOf(employeeId), day.toString()};
        try (Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM send_log WHERE kind=? AND " + employeeClause + " AND day=? LIMIT 1", args)) { return c.moveToFirst(); }
    }

    public void logSent(String kind, Long employeeId, LocalDate day) {
        ContentValues v = new ContentValues();
        v.put("kind", kind); if (employeeId != null) v.put("employee_id", employeeId); v.put("day", day.toString()); v.put("sent_at", System.currentTimeMillis());
        try { getWritableDatabase().insertOrThrow("send_log", null, v); } catch (Exception ignored) {}
    }

    public void clearTodayAbsence(long employeeId, LocalDate day) {
        Absence a = latestOpenAbsence(employeeId, day);
        if (a == null) return;
        if (a.startDate.isBefore(day)) {
            ContentValues v = new ContentValues(); v.put("end_date", day.minusDays(1).toString()); v.put("updated_at", System.currentTimeMillis());
            getWritableDatabase().update("absences", v, "id=?", new String[]{String.valueOf(a.id)});
        } else {
            getWritableDatabase().delete("absences", "id=?", new String[]{String.valueOf(a.id)});
        }
    }


    public List<InboundMessage> recentInbound(int limit) {
        List<InboundMessage> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id,phone,body,received_at,status FROM inbound ORDER BY received_at DESC LIMIT ?", new String[]{String.valueOf(limit)})) {
            while (c.moveToNext()) out.add(new InboundMessage(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), c.getString(4)));
        }
        return out;
    }

    private Employee employeeFrom(Cursor c) {
        return new Employee(c.getLong(c.getColumnIndexOrThrow("id")), c.getString(c.getColumnIndexOrThrow("name")), c.getString(c.getColumnIndexOrThrow("phone")), c.getInt(c.getColumnIndexOrThrow("active"))==1, c.getInt(c.getColumnIndexOrThrow("leader"))==1);
    }
    private Absence absenceFrom(Cursor c) {
        return new Absence(c.getLong(c.getColumnIndexOrThrow("id")), c.getLong(c.getColumnIndexOrThrow("employee_id")), LocalDate.parse(c.getString(c.getColumnIndexOrThrow("start_date"))), c.isNull(c.getColumnIndexOrThrow("end_date")) ? null : LocalDate.parse(c.getString(c.getColumnIndexOrThrow("end_date"))));
    }

    public static String normalizePhone(String s) {
        if (s == null) return "";
        String x = s.trim().replaceAll("[\\s()/-]", "");
        if (x.startsWith("00")) x = "+" + x.substring(2);
        if (x.startsWith("0") && !x.startsWith("00")) x = "+49" + x.substring(1);
        return x;
    }

    public static class Employee {
        public final long id; public final String name; public final String phone; public final boolean active; public final boolean leader;
        public Employee(long id, String name, String phone, boolean active, boolean leader) { this.id=id;this.name=name;this.phone=phone;this.active=active;this.leader=leader; }
    }
    public static class Absence {
        public final long id; public final long employeeId; public final LocalDate startDate; public final LocalDate endDate;
        public Absence(long id,long employeeId,LocalDate startDate,LocalDate endDate){this.id=id;this.employeeId=employeeId;this.startDate=startDate;this.endDate=endDate;}
    }
    public static class AbsenceWithEmployee {
        public final Absence absence; public final Employee employee;
        public AbsenceWithEmployee(Absence absence,Employee employee){this.absence=absence;this.employee=employee;}
    }
    public static class InboundMessage {
        public final long id; public final String phone; public final String body; public final long receivedAt; public final String status;
        public InboundMessage(long id,String phone,String body,long receivedAt,String status){this.id=id;this.phone=phone;this.body=body;this.receivedAt=receivedAt;this.status=status;}
    }
}
