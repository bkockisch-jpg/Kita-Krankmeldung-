package de.kita.krankmeldung.schedule;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.time.LocalDateTime;
import java.time.ZoneId;

public class AlarmScheduler {
    public static final String ACTION_MORNING = "de.kita.krankmeldung.MORNING";
    public static final String ACTION_NOON = "de.kita.krankmeldung.NOON";
    public static final String PREFS = "settings";

    public static void scheduleAll(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        schedule(context, ACTION_MORNING, 1001, p.getInt("morning_hour",7), p.getInt("morning_minute",45));
        schedule(context, ACTION_NOON, 1002, p.getInt("noon_hour",12), p.getInt("noon_minute",0));
    }

    private static void schedule(Context context, String action, int requestCode, int hour, int minute) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime next = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0);
        if (!next.isAfter(now)) next = next.plusDays(1);
        long trigger = next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(context, AlarmReceiver.class).setAction(action);
        PendingIntent pi = PendingIntent.getBroadcast(context, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (android.os.Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
        else
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
    }
}
