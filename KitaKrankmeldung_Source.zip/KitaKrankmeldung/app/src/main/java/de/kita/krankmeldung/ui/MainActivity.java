package de.kita.krankmeldung.ui;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlarmManager;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import de.kita.krankmeldung.data.AppDb;
import de.kita.krankmeldung.schedule.AlarmScheduler;
import de.kita.krankmeldung.schedule.DailyActions;
import de.kita.krankmeldung.security.PinSecurity;
import de.kita.krankmeldung.security.SessionState;
import de.kita.krankmeldung.sms.ComposeSmsActivity;
import de.kita.krankmeldung.sms.SmsProcessor;
import de.kita.krankmeldung.sms.SmsSender;
import de.kita.krankmeldung.sms.SmsStatusReceiver;
import de.kita.krankmeldung.sms.SmsStore;
import de.kita.krankmeldung.util.AppSettings;
import de.kita.krankmeldung.util.WorkCalendar;

import java.text.DateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String TAB_SMS = "SMS";
    private static final String TAB_SICK = "KRANK";

    private static final int C_BG = Color.rgb(246, 248, 250);
    private static final int C_CARD = Color.WHITE;
    private static final int C_TEXT = Color.rgb(29, 41, 57);
    private static final int C_MUTED = Color.rgb(102, 112, 133);
    private static final int C_BORDER = Color.rgb(228, 231, 236);
    private static final int C_GREEN = Color.rgb(31, 107, 69);
    private static final int C_GREEN_SOFT = Color.rgb(236, 253, 243);
    private static final int C_BLUE = Color.rgb(37, 99, 235);
    private static final int C_BLUE_SOFT = Color.rgb(239, 246, 255);
    private static final int C_AMBER = Color.rgb(181, 71, 8);
    private static final int C_AMBER_SOFT = Color.rgb(255, 250, 235);
    private static final int C_RED = Color.rgb(180, 35, 24);
    private static final int C_RED_SOFT = Color.rgb(254, 243, 242);

    private AppDb db;
    private SmsStore smsStore;
    private PinSecurity pinSecurity;
    private AppSettings settings;

    private LinearLayout content;
    private LinearLayout tabsRow;
    private TextView smsTabLabel, sickTabLabel;
    private View smsUnderline, sickUnderline;

    private String activeTab = TAB_SICK;
    private String sickPage = "overview";

    private final Handler autoLockHandler = new Handler(Looper.getMainLooper());
    private final Runnable autoLockRunnable = () -> {
        if (SessionState.isUnlocked()) lockApp();
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new AppDb(this);
        smsStore = new SmsStore(this);
        pinSecurity = new PinSecurity(this);
        settings = new AppSettings(this);
        AlarmScheduler.scheduleAll(this);

        if (savedInstanceState != null) {
            activeTab = savedInstanceState.getString("active_tab", TAB_SICK);
            sickPage = savedInstanceState.getString("sick_page", "overview");
        }
        if (getIntent() != null && TAB_SMS.equals(getIntent().getStringExtra("open_tab"))) activeTab = TAB_SMS;

        buildShell();
        routeInitialScreen();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && TAB_SMS.equals(intent.getStringExtra("open_tab"))) {
            activeTab = TAB_SMS;
            if (SessionState.isUnlocked()) renderActiveTab();
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        outState.putString("active_tab", activeTab);
        outState.putString("sick_page", sickPage);
        super.onSaveInstanceState(outState);
    }

    @Override protected void onResume() {
        super.onResume();
        if (!holdsSmsRole()) {
            SessionState.lock();
            showSmsRoleGate();
            return;
        }
        if (SessionState.isUnlocked()) {
            int minutes = pinSecurity.getAutoLockMinutes();
            long timeout = minutes <= 0 ? Long.MAX_VALUE : minutes * 60_000L;
            if (minutes > 0 && SessionState.inactiveForMs() >= timeout) lockApp();
            else {
                renderActiveTab();
                scheduleAutoLock();
            }
        }
    }

    @Override protected void onPause() {
        super.onPause();
        autoLockHandler.removeCallbacks(autoLockRunnable);
    }

    @Override public boolean dispatchTouchEvent(MotionEvent ev) {
        if (SessionState.isUnlocked() && (ev.getAction() == MotionEvent.ACTION_DOWN || ev.getAction() == MotionEvent.ACTION_UP)) {
            SessionState.touch();
            scheduleAutoLock();
        }
        return super.dispatchTouchEvent(ev);
    }

    private void routeInitialScreen() {
        if (!holdsSmsRole()) showSmsRoleGate();
        else if (!pinSecurity.hasPin()) showPinSetupDialog();
        else if (!SessionState.isUnlocked()) showUnlockDialog();
        else {
            requestSmsPermissions();
            renderActiveTab();
        }
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(C_BG);
        root.setPadding(dp(16), dp(14), dp(16), dp(10));

        TextView brand = text("Kita Krankmeldung", 25, C_TEXT, true);
        root.addView(brand);
        TextView subtitle = text("SMS-Zentrale für das Diensthandy", 13, C_MUTED, false);
        subtitle.setPadding(0, dp(2), 0, dp(14));
        root.addView(subtitle);

        tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        tabsRow.setBackground(roundRect(C_CARD, C_BORDER, 12));
        tabsRow.setPadding(dp(4), dp(4), dp(4), 0);

        LinearLayout smsTab = tabCell("SMS", true);
        smsTabLabel = (TextView) smsTab.getChildAt(0);
        smsUnderline = smsTab.getChildAt(1);
        LinearLayout sickTab = tabCell("Krankmeldungen", false);
        sickTabLabel = (TextView) sickTab.getChildAt(0);
        sickUnderline = sickTab.getChildAt(1);
        tabsRow.addView(smsTab, new LinearLayout.LayoutParams(0, dp(50), 1));
        tabsRow.addView(sickTab, new LinearLayout.LayoutParams(0, dp(50), 1));
        smsTab.setOnClickListener(v -> { activeTab = TAB_SMS; renderActiveTab(); });
        sickTab.setOnClickListener(v -> { activeTab = TAB_SICK; renderActiveTab(); });
        root.addView(tabsRow);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(12), 0, dp(28));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private LinearLayout tabCell(String label, boolean sms) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView t = text(label, 15, C_MUTED, true);
        t.setGravity(Gravity.CENTER);
        cell.addView(t, new LinearLayout.LayoutParams(-1, 0, 1));
        View line = new View(this);
        line.setBackgroundColor(C_GREEN);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(72), dp(3));
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        cell.addView(line, lp);
        return cell;
    }

    private void updateTabs() {
        boolean sms = TAB_SMS.equals(activeTab);
        smsTabLabel.setTextColor(sms ? C_TEXT : C_MUTED);
        sickTabLabel.setTextColor(sms ? C_MUTED : C_TEXT);
        smsUnderline.setVisibility(sms ? View.VISIBLE : View.INVISIBLE);
        sickUnderline.setVisibility(sms ? View.INVISIBLE : View.VISIBLE);
    }

    private void renderActiveTab() {
        if (!SessionState.isUnlocked()) return;
        tabsRow.setVisibility(View.VISIBLE);
        updateTabs();
        content.removeAllViews();
        if (TAB_SMS.equals(activeTab)) renderSmsTab(); else renderSickTab();
    }

    // ---------------- SMS ----------------

    private void renderSmsTab() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView h = text("Nachrichten", 22, C_TEXT, true);
        header.addView(h, new LinearLayout.LayoutParams(0, -2, 1));
        Button compose = compactButton("Neue SMS", C_BLUE, Color.WHITE);
        compose.setOnClickListener(v -> startActivity(new Intent(this, ComposeSmsActivity.class)));
        header.addView(compose);
        content.addView(header);

        EditText search = new EditText(this);
        search.setHint("SMS nach Name, Nummer oder Text durchsuchen …");
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setPadding(dp(14), dp(10), dp(14), dp(10));
        search.setBackground(roundRect(C_CARD, C_BORDER, 12));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.setMargins(0, dp(12), 0, dp(10));
        content.addView(search, slp);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        content.addView(list);
        renderThreads(list);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().isEmpty()) renderThreads(list); else renderSearchResults(list, s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void renderThreads(LinearLayout holder) {
        holder.removeAllViews();
        List<SmsStore.ThreadItem> threads = smsStore.recentThreads(1200, 80);
        if (threads.isEmpty()) {
            holder.addView(emptyState("Noch keine SMS", "Eingehende und gesendete Nachrichten erscheinen hier."));
            return;
        }
        AppDb localDb = db;
        for (SmsStore.ThreadItem t : threads) {
            AppDb.Employee e = localDb.findEmployeeByPhone(t.address);
            String name = e == null ? t.address : e.name;
            String meta = formatDateTime(t.lastDate) + (t.unreadCount > 0 ? "  ·  " + t.unreadCount + " ungelesen" : "");
            LinearLayout card = messageCard(name, meta, t.lastBody, t.unreadCount > 0);
            card.setOnClickListener(v -> openConversation(t.address));
            holder.addView(card);
        }
    }

    private void renderSearchResults(LinearLayout holder, String query) {
        holder.removeAllViews();
        List<SmsStore.SmsItem> results = smsStore.search(query, 1500, 100);
        if (results.isEmpty()) {
            holder.addView(emptyState("Keine Treffer", "Für „" + query.trim() + "“ wurde nichts gefunden."));
            return;
        }
        for (SmsStore.SmsItem m : results) {
            AppDb.Employee e = db.findEmployeeByPhone(m.address);
            String name = e == null ? m.address : e.name;
            LinearLayout card = messageCard(name, formatDateTime(m.date), m.body, m.incoming() && !m.read);
            card.setOnClickListener(v -> openConversation(m.address));
            holder.addView(card);
        }
    }

    private LinearLayout messageCard(String name, String meta, String body, boolean unread) {
        LinearLayout c = card();
        TextView n = text(name, 16, C_TEXT, unread);
        c.addView(n);
        TextView m = text(meta, 12, C_MUTED, false);
        m.setPadding(0, dp(2), 0, dp(5));
        c.addView(m);
        String preview = body == null ? "" : body.replaceAll("\\s+", " ").trim();
        if (preview.length() > 140) preview = preview.substring(0, 137) + "…";
        c.addView(text(preview, 14, C_MUTED, false));
        return c;
    }

    private void openConversation(String address) {
        Intent i = new Intent(this, ConversationActivity.class);
        i.putExtra("address", address);
        startActivity(i);
    }

    // ---------------- Krankmeldungen ----------------

    private void renderSickTab() {
        if (settings.isTestMode()) {
            String number = settings.getTestNumber().trim().isEmpty() ? "keine Testnummer" : AppDb.normalizePhone(settings.getTestNumber());
            content.addView(coloredNotice("TESTMODUS AKTIV", "Automatische SMS werden ausschließlich an " + number + " umgeleitet.", C_AMBER_SOFT, C_AMBER));
        }
        renderSickSubnav();
        switch (sickPage) {
            case "team": renderTeam(); break;
            case "review": renderReview(); break;
            case "settings": renderSettings(); break;
            default: renderOverview(); break;
        }
    }

    private void renderSickSubnav() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        int reviewCount = db.reviewInbound(100).size();
        row.addView(subnavButton("Übersicht", "overview"));
        row.addView(subnavButton("Team", "team"));
        row.addView(subnavButton(reviewCount > 0 ? "Prüfen (" + reviewCount + ")" : "Prüfen", "review"));
        row.addView(subnavButton("Einstellungen", "settings"));
        hsv.addView(row);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(14));
        content.addView(hsv, lp);
    }

    private Button subnavButton(String label, String page) {
        boolean active = page.equals(sickPage);
        Button b = compactButton(label, active ? C_GREEN_SOFT : C_CARD, active ? C_GREEN : C_MUTED);
        b.setBackground(roundRect(active ? C_GREEN_SOFT : C_CARD, active ? C_GREEN : C_BORDER, 20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(40));
        lp.setMargins(0, 0, dp(8), 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> { sickPage = page; renderActiveTab(); });
        return b;
    }

    private void renderOverview() {
        LocalDate today = LocalDate.now();
        LocalDate next = WorkCalendar.nextBusinessDay(today);
        List<AppDb.AbsenceWithEmployee> todayAbsent = db.absencesOn(today);
        List<AppDb.AbsenceWithEmployee> unresolvedToday = db.unresolvedBefore(today);
        List<AppDb.AbsenceWithEmployee> nextAbsent = db.absencesOn(next);
        List<AppDb.AbsenceWithEmployee> pending = db.needingFollowup(today, next);
        List<AppDb.Employee> confirmedPresent = db.presentOn(next);
        List<AppDb.Employee> all = db.allEmployees(true);

        TextView title = text("Krankmeldungen", 22, C_TEXT, true);
        content.addView(title);
        TextView date = text("Heute: " + dateLong(today) + "  ·  Nächster Arbeitstag: " + dateLong(next), 13, C_MUTED, false);
        date.setPadding(0, dp(3), 0, dp(12));
        content.addView(date);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(statCard(String.valueOf(todayAbsent.size()), "heute abwesend", C_RED_SOFT, C_RED), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams mid = new LinearLayout.LayoutParams(0, -2, 1); mid.setMargins(dp(8), 0, dp(8), 0);
        stats.addView(statCard(String.valueOf(pending.size()), "Rückmeldung offen", C_AMBER_SOFT, C_AMBER), mid);
        stats.addView(statCard(String.valueOf(nextAbsent.size()), "nächster Tag abwesend", C_BLUE_SOFT, C_BLUE), new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(stats);

        List<AppDb.SendAttempt> failures = db.failedSendAttempts(20);
        if (!failures.isEmpty()) renderFailures(failures);
        if (!unresolvedToday.isEmpty()) {
            content.addView(coloredNotice("STATUS HEUTE UNGEKLÄRT", joinNames(unresolvedToday) + " hat/haben seit der letzten offenen Abwesenheit noch keine eindeutige Rückmeldung für heute.", C_AMBER_SOFT, C_AMBER));
        }

        content.addView(section("Heute abwesend"));
        if (todayAbsent.isEmpty()) content.addView(infoCard("Niemand ist für heute als abwesend eingetragen."));
        else {
            for (AppDb.AbsenceWithEmployee a : todayAbsent) {
                LinearLayout c = card();
                LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL);
                top.addView(text(a.employee.name, 16, C_TEXT, true), new LinearLayout.LayoutParams(0, -2, 1));
                Button fix = compactButton("Korrigieren", C_CARD, C_GREEN);
                fix.setBackground(roundRect(C_CARD, C_GREEN, 10));
                fix.setOnClickListener(v -> correctionDialog(a));
                top.addView(fix);
                c.addView(top);
                String until = a.absence.endDate == null ? "Dauer noch offen" : "Bis einschließlich " + germanDate(a.absence.endDate);
                c.addView(text(until, 13, C_MUTED, false));
                content.addView(c);
            }
        }

        content.addView(section("Nächster Arbeitstag"));
        Set<Long> absentIds = new HashSet<>(); for (AppDb.AbsenceWithEmployee x : nextAbsent) absentIds.add(x.employee.id);
        Set<Long> pendingIds = new HashSet<>(); for (AppDb.AbsenceWithEmployee x : pending) pendingIds.add(x.employee.id);
        Set<Long> presentIds = new HashSet<>(); for (AppDb.Employee x : confirmedPresent) presentIds.add(x.id);
        int expected = 0; for (AppDb.Employee e : all) if (!absentIds.contains(e.id) && !pendingIds.contains(e.id) && !presentIds.contains(e.id)) expected++;
        LinearLayout nextCard = card();
        nextCard.addView(statusLine("Abwesend", nextAbsent.isEmpty() ? "—" : joinNames(nextAbsent), C_RED));
        nextCard.addView(statusLine("Rückkehr bestätigt", confirmedPresent.isEmpty() ? "—" : joinEmployeeNames(confirmedPresent), C_GREEN));
        nextCard.addView(statusLine("Rückmeldung offen", pending.isEmpty() ? "—" : joinNames(pending), C_AMBER));
        nextCard.addView(statusLine("Regulär eingeplant", String.valueOf(expected) + " Person(en)", C_MUTED));
        content.addView(nextCard);

        content.addView(section("Schnellaktionen"));
        Button manual = primaryButton("Abwesenheit eintragen / korrigieren");
        manual.setOnClickListener(v -> manualAbsenceDialog());
        content.addView(manual);
        Button morning = secondaryButton("Morgenmeldung jetzt senden");
        morning.setOnClickListener(v -> { boolean ok = DailyActions.sendMorningDigest(this, true); toast(ok ? "Morgenmeldung wurde angestoßen" : "Keine Abwesenheiten für heute vorhanden"); renderActiveTab(); });
        content.addView(morning);
        Button noon = secondaryButton("Rückfragen jetzt senden");
        noon.setOnClickListener(v -> { int n = DailyActions.sendNoonReminders(this, true); toast(n + " Rückfrage(n) angestoßen"); renderActiveTab(); });
        content.addView(noon);
        Button addendum = secondaryButton("Nachtrag jetzt senden");
        addendum.setOnClickListener(v -> { boolean ok = DailyActions.sendLateAddendum(this); toast(ok ? "Nachtrag wurde angestoßen" : "Kein neuer Nachtrag vorhanden"); renderActiveTab(); });
        content.addView(addendum);
    }

    private void renderFailures(List<AppDb.SendAttempt> failures) {
        content.addView(section("Versandprobleme"));
        content.addView(coloredNotice("SMS FEHLGESCHLAGEN", failures.size() + " Nachricht(en) benötigen Aufmerksamkeit.", C_RED_SOFT, C_RED));
        for (AppDb.SendAttempt a : failures) {
            LinearLayout c = card();
            AppDb.Employee e = db.findEmployeeByPhone(a.originalRecipient);
            String who = e == null ? a.originalRecipient : e.name;
            c.addView(text(who + " · " + friendlyKind(a.kind), 15, C_TEXT, true));
            c.addView(text(SmsStatusReceiver.describeError(a.errorCode), 13, C_RED, false));
            TextView preview = text(trimPreview(a.body, 110), 13, C_MUTED, false);
            preview.setPadding(0, dp(5), 0, dp(6)); c.addView(preview);
            Button retry = compactButton("Erneut senden", C_RED_SOFT, C_RED);
            retry.setOnClickListener(v -> { boolean ok = new SmsSender(this).retry(a.id); toast(ok ? "Erneuter Versand angestoßen" : "Versand konnte nicht gestartet werden"); renderActiveTab(); });
            c.addView(retry);
            content.addView(c);
        }
    }

    private void renderTeam() {
        LinearLayout head = new LinearLayout(this); head.setOrientation(LinearLayout.HORIZONTAL); head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(text("Team", 22, C_TEXT, true), new LinearLayout.LayoutParams(0, -2, 1));
        Button add = compactButton("Hinzufügen", C_GREEN, Color.WHITE); add.setOnClickListener(v -> employeeDialog(null)); head.addView(add);
        content.addView(head);
        TextView hint = text("Leitungsrollen dürfen die App von ihrer hinterlegten Nummer per SMS fernsteuern.", 13, C_MUTED, false);
        hint.setPadding(0, dp(4), 0, dp(10)); content.addView(hint);

        List<AppDb.Employee> list = db.allEmployees(false);
        if (list.isEmpty()) { content.addView(emptyState("Noch kein Team", "Lege zuerst Mitarbeitende mit Mobilnummer an.")); return; }
        for (AppDb.Employee e : list) {
            LinearLayout c = card();
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
            info.addView(text(e.name + (e.leader ? "  ·  Leitung" : ""), 16, e.active ? C_TEXT : C_MUTED, true));
            info.addView(text(e.phone + (e.active ? "" : "  ·  inaktiv"), 13, C_MUTED, false));
            row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
            Button edit = compactButton("Bearbeiten", C_CARD, C_GREEN); edit.setBackground(roundRect(C_CARD, C_GREEN, 10)); edit.setOnClickListener(v -> employeeDialog(e)); row.addView(edit);
            c.addView(row); content.addView(c);
        }
    }

    private void renderReview() {
        content.addView(text("Bitte prüfen", 22, C_TEXT, true));
        TextView hint = text("Unsichere Formulierungen werden bewusst nicht automatisch übernommen. Originaltext und Vorschlag bleiben sichtbar.", 13, C_MUTED, false);
        hint.setPadding(0, dp(4), 0, dp(10)); content.addView(hint);

        List<AppDb.InboundMessage> items = db.reviewInbound(80);
        if (items.isEmpty()) { content.addView(emptyState("Alles erledigt", "Aktuell wartet keine Nachricht auf eine Entscheidung.")); return; }
        for (AppDb.InboundMessage m : items) {
            AppDb.Employee e = m.employeeId == null ? db.findEmployeeByPhone(m.phone) : db.getEmployee(m.employeeId);
            LinearLayout c = card();
            String who = e == null ? m.phone : e.name;
            c.addView(text(who + "  ·  " + formatDateTime(m.receivedAt), 15, C_TEXT, true));
            TextView original = text("„" + m.body + "“", 14, C_TEXT, false); original.setPadding(0, dp(6), 0, dp(7)); c.addView(original);
            if (m.interpretation != null && !m.interpretation.trim().isEmpty()) c.addView(text("Vorschlag: " + m.interpretation, 13, C_AMBER, true));

            if ("UNKNOWN_SENDER".equals(m.status)) {
                Button assign = compactButton("Nummer zuordnen", C_BLUE_SOFT, C_BLUE); assign.setOnClickListener(v -> assignUnknownDialog(m)); c.addView(assign);
            } else {
                LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
                if (m.confidence > 0 && m.interpretation != null && !m.interpretation.equals("Nicht sicher erkannt")) {
                    Button accept = compactButton("Vorschlag übernehmen", C_GREEN_SOFT, C_GREEN);
                    accept.setOnClickListener(v -> { boolean ok = new SmsProcessor(this).applyReviewedInbound(m.id); toast(ok ? "Übernommen" : "Vorschlag konnte nicht angewendet werden"); renderActiveTab(); });
                    actions.addView(accept);
                }
                Button ignore = compactButton("Ignorieren", C_CARD, C_MUTED); ignore.setBackground(roundRect(C_CARD, C_BORDER, 10));
                ignore.setOnClickListener(v -> { new SmsProcessor(this).ignoreInbound(m.id); renderActiveTab(); });
                LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-2, -2); ilp.setMargins(dp(8), 0, 0, 0); ignore.setLayoutParams(ilp);
                actions.addView(ignore); c.addView(actions);
            }
            content.addView(c);
        }
    }

    private void renderSettings() {
        content.addView(text("Einstellungen", 22, C_TEXT, true));

        content.addView(section("Testmodus"));
        content.addView(infoCard("Im Testmodus werden ausschließlich automatische Krankmeldungs-SMS umgeleitet. Selbst geschriebene normale SMS bleiben unverändert."));
        EditText testNumber = field("Testnummer, z. B. 0176…", settings.getTestNumber());
        content.addView(testNumber);
        CheckBox testMode = new CheckBox(this); testMode.setText("Testmodus aktiv"); testMode.setChecked(settings.isTestMode()); content.addView(testMode);
        Button saveTest = primaryButton("Testmodus speichern");
        saveTest.setOnClickListener(v -> {
            String n = testNumber.getText().toString().trim();
            if (testMode.isChecked() && n.replaceAll("\\D", "").length() < 8) { toast("Für den Testmodus wird eine vollständige Testnummer benötigt"); return; }
            settings.setTestNumber(n); settings.setTestMode(testMode.isChecked());
            db.audit("TEST_MODE", null, testMode.isChecked() ? "an" : "aus", "settings"); toast("Testmodus gespeichert"); renderActiveTab();
        }); content.addView(saveTest);
        Button testSms = secondaryButton("Test-SMS an Testnummer senden");
        testSms.setOnClickListener(v -> {
            String n = testNumber.getText().toString().trim();
            if (n.replaceAll("\\D", "").length() < 8) { toast("Bitte zuerst eine Testnummer eingeben"); return; }
            boolean ok = new SmsSender(this).sendManual(n, "Kita Krankmeldung: Test-SMS erfolgreich ausgelöst.");
            toast(ok ? "Test-SMS angestoßen" : "Test-SMS konnte nicht gestartet werden");
        }); content.addView(testSms);

        content.addView(section("Automatischer Versand"));
        SharedPreferences p = getSharedPreferences(AlarmScheduler.PREFS, MODE_PRIVATE);
        EditText morning = field("Morgenmeldung", String.format(Locale.GERMANY, "%02d:%02d", p.getInt("morning_hour", 7), p.getInt("morning_minute", 45)));
        EditText noon = field("Rückfrage", String.format(Locale.GERMANY, "%02d:%02d", p.getInt("noon_hour", 12), p.getInt("noon_minute", 0)));
        content.addView(morning); content.addView(noon);
        CheckBox autoAddendum = new CheckBox(this); autoAddendum.setText("Nachträge nach der Morgenmeldung automatisch senden"); autoAddendum.setChecked(settings.isAutoAddendumEnabled()); content.addView(autoAddendum);
        Button saveTimes = primaryButton("Versandregeln speichern");
        saveTimes.setOnClickListener(v -> {
            int[] m = parseTime(morning.getText().toString(), 7, 45), n = parseTime(noon.getText().toString(), 12, 0);
            p.edit().putInt("morning_hour", m[0]).putInt("morning_minute", m[1]).putInt("noon_hour", n[0]).putInt("noon_minute", n[1]).apply();
            settings.setAutoAddendumEnabled(autoAddendum.isChecked()); AlarmScheduler.scheduleAll(this); toast("Versandregeln gespeichert");
        }); content.addView(saveTimes);
        content.addView(infoCard("Samstage, Sonntage und gesetzliche Feiertage in Hessen werden bei automatischen Morgenmeldungen und Rückfragen übersprungen. Rückfragen beziehen sich auf den nächsten Arbeitstag."));

        content.addView(section("Leitung per SMS"));
        content.addView(infoCard("Nur Nummern, die im Team als „Leitung“ markiert sind, dürfen Remote-Befehle ausführen. Die App fragt bei unvollständigen Befehlen per SMS nach."));
        content.addView(infoCard("Beispiele:\nSTATUS\nSTATUS MORGEN\nOFFENE RÜCKMELDUNGEN\nANNA KRANK BIS FREITAG\nANNA MORGEN DA\nNACHTRAG SENDEN\nTESTMODUS AN / AUS"));

        content.addView(section("SMS-System"));
        content.addView(infoCard(holdsSmsRole() ? "Kita Krankmeldung ist die Standard-SMS-App dieses Diensthandys." : "Die SMS-Rolle fehlt. Automatik und SMS-Posteingang funktionieren so nicht."));
        Button role = secondaryButton(holdsSmsRole() ? "SMS-Berechtigungen prüfen" : "Als SMS-App verwenden");
        role.setOnClickListener(v -> { if (holdsSmsRole()) requestSmsPermissions(); else requestSmsRole(); }); content.addView(role);

        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        if (!exact) {
            content.addView(coloredNotice("VERSANDZEITEN", "Android darf geplante Zeiten aktuell verzögern.", C_AMBER_SOFT, C_AMBER));
            Button exactBtn = secondaryButton("Genaue Alarme freigeben"); exactBtn.setOnClickListener(v -> requestExactAlarm()); content.addView(exactBtn);
        }

        content.addView(section("Sicherheit"));
        Spinner autoLock = new Spinner(this);
        String[] options = {"2 Minuten", "5 Minuten", "10 Minuten", "Nie"}; int[] values = {2,5,10,0};
        autoLock.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, options));
        int cur = pinSecurity.getAutoLockMinutes(), sel = 1; for (int i=0;i<values.length;i++) if (values[i]==cur) sel=i; autoLock.setSelection(sel); content.addView(autoLock);
        Button saveLock = secondaryButton("Sperrzeit speichern"); saveLock.setOnClickListener(v -> { pinSecurity.setAutoLockMinutes(values[autoLock.getSelectedItemPosition()]); SessionState.touch(); scheduleAutoLock(); toast("Sperrzeit gespeichert"); }); content.addView(saveLock);
        Button pin = secondaryButton("PIN ändern"); pin.setOnClickListener(v -> showChangePinDialog()); content.addView(pin);
        Button lock = secondaryButton("App jetzt sperren"); lock.setOnClickListener(v -> lockApp()); content.addView(lock);
        content.addView(infoCard("Der Entsperrstatus bleibt bei Bildschirmdrehung erhalten. Nach Prozess-/Geräteneustart oder Ablauf der Sperrzeit wird die PIN erneut benötigt."));

        content.addView(section("Datenschutz"));
        content.addView(infoCard("Krankmeldungsstatus, Teamdaten und Protokolle werden lokal auf dem Diensthandy gespeichert. Diagnosen sind für die Krankmeldungslogik weder erforderlich noch vorgesehen."));
    }

    // ---------------- Dialoge ----------------

    private void employeeDialog(AppDb.Employee existing) {
        LinearLayout l = dialogLayout();
        EditText name = field("Name", existing == null ? "" : existing.name);
        EditText phone = field("Mobilnummer", existing == null ? "" : existing.phone); phone.setInputType(InputType.TYPE_CLASS_PHONE);
        CheckBox leader = new CheckBox(this); leader.setText("Leitung – darf Remote-Steuerung nutzen"); leader.setChecked(existing != null && existing.leader);
        CheckBox active = new CheckBox(this); active.setText("Aktiv"); active.setChecked(existing == null || existing.active);
        l.addView(name); l.addView(phone); l.addView(leader); l.addView(active);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Mitarbeitende hinzufügen" : "Mitarbeitende bearbeiten")
                .setView(l)
                .setPositiveButton("Speichern", null)
                .setNegativeButton("Abbrechen", null);
        if (existing != null) builder.setNeutralButton("Löschen", null);
        AlertDialog d = builder.create();
        d.setOnShowListener(x -> {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                if (name.getText().toString().trim().isEmpty() || phone.getText().toString().replaceAll("\\D", "").length() < 8) {
                    toast("Name und vollständige Mobilnummer werden benötigt"); return;
                }
                try {
                    db.upsertEmployee(existing == null ? null : existing.id, name.getText().toString(), phone.getText().toString(), leader.isChecked(), active.isChecked());
                    d.dismiss(); renderActiveTab();
                } catch (Exception ex) { toast("Speichern fehlgeschlagen. Ist die Nummer bereits vergeben?"); }
            });
            if (existing != null) {
                d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v ->
                        new AlertDialog.Builder(this)
                                .setTitle(existing.name + " löschen?")
                                .setMessage("Teamzuordnung wird entfernt. Vorhandene Protokolle bleiben erhalten.")
                                .setPositiveButton("Löschen", (a,b) -> { db.deleteEmployee(existing.id); d.dismiss(); renderActiveTab(); })
                                .setNegativeButton("Abbrechen", null).show());
            }
        });
        d.show();
    }

    private void manualAbsenceDialog() {
        List<AppDb.Employee> employees = db.allEmployees(true);
        if (employees.isEmpty()) { toast("Bitte zuerst Mitarbeitende anlegen"); return; }
        LinearLayout l = dialogLayout();
        Spinner employee = new Spinner(this); List<String> names = new ArrayList<>(); for (AppDb.Employee e : employees) names.add(e.name); employee.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        Spinner start = new Spinner(this); String[] starts = {"Heute", "Nächster Arbeitstag"}; start.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, starts));
        EditText until = field("Enddatum optional (DD.MM.YYYY)", "");
        l.addView(employee); l.addView(start); l.addView(until);
        new AlertDialog.Builder(this).setTitle("Abwesenheit eintragen").setView(l).setPositiveButton("Eintragen", (d,w) -> {
            AppDb.Employee e = employees.get(employee.getSelectedItemPosition());
            LocalDate s = start.getSelectedItemPosition() == 0 ? LocalDate.now() : WorkCalendar.nextBusinessDay(LocalDate.now());
            LocalDate end = null;
            String u = until.getText().toString().trim();
            if (!u.isEmpty()) { end = parseGermanDate(u); if (end == null) { toast("Enddatum nicht erkannt"); return; } }
            if (start.getSelectedItemPosition() == 1 && end == null) end = s;
            if (end != null && end.isBefore(s)) { toast("Enddatum liegt vor dem Startdatum"); return; }
            db.markAbsent(e.id, s, end, "manual");
            if (s.equals(LocalDate.now()) && db.hasSent("morning_digest", null, LocalDate.now()) && settings.isAutoAddendumEnabled()) DailyActions.sendLateAddendum(this);
            renderActiveTab();
        }).setNegativeButton("Abbrechen", null).show();
    }

    private void correctionDialog(AppDb.AbsenceWithEmployee item) {
        String[] options = {"Heute doch anwesend", "Enddatum ändern", "Dauer wieder offen setzen"};
        new AlertDialog.Builder(this).setTitle(item.employee.name + " korrigieren").setItems(options, (d, which) -> {
            if (which == 0) {
                db.clearTodayAbsence(item.employee.id, LocalDate.now()); renderActiveTab();
            } else if (which == 1) {
                EditText date = field("DD.MM.YYYY", item.absence.endDate == null ? "" : germanDate(item.absence.endDate));
                new AlertDialog.Builder(this).setTitle("Neues Enddatum").setView(date).setPositiveButton("Speichern", (a,b) -> {
                    LocalDate end = parseGermanDate(date.getText().toString());
                    if (end == null || end.isBefore(item.absence.startDate)) { toast("Datum nicht erkannt oder ungültig"); return; }
                    db.setAbsenceEnd(item.absence.id, end, "manual-correction"); db.audit("ABSENCE_CORRECTED", item.employee.id, "Ende " + end, "manual"); renderActiveTab();
                }).setNegativeButton("Abbrechen", null).show();
            } else {
                db.setAbsenceEnd(item.absence.id, null, "manual-correction"); db.audit("ABSENCE_CORRECTED", item.employee.id, "Dauer offen", "manual"); renderActiveTab();
            }
        }).show();
    }

    private void assignUnknownDialog(AppDb.InboundMessage m) {
        List<AppDb.Employee> employees = db.allEmployees(true);
        if (employees.isEmpty()) { toast("Bitte zuerst Teammitglieder anlegen"); return; }
        List<String> names = new ArrayList<>(); for (AppDb.Employee e : employees) names.add(e.name + "  ·  " + e.phone);
        new AlertDialog.Builder(this).setTitle("Nummer " + m.phone + " zuordnen").setItems(names.toArray(new String[0]), (d, which) -> {
            AppDb.Employee e = employees.get(which);
            new AlertDialog.Builder(this).setTitle(e.name + " zuordnen?").setMessage("Die gespeicherte Mobilnummer von " + e.name + " wird auf " + m.phone + " geändert und die Nachricht anschließend erneut geprüft.")
                    .setPositiveButton("Zuordnen", (a,b) -> { boolean ok = new SmsProcessor(this).assignAndReprocess(m.id, e.id); toast(ok ? "Nummer zugeordnet" : "Zuordnung fehlgeschlagen"); renderActiveTab(); })
                    .setNegativeButton("Abbrechen", null).show();
        }).show();
    }

    // ---------------- PIN / Rolle ----------------

    private void showSmsRoleGate() {
        tabsRow.setVisibility(View.GONE); content.removeAllViews();
        content.addView(coloredNotice("SMS-EINRICHTUNG", "Kita Krankmeldung wird die Standard-SMS-App dieses Diensthandys. Dadurch kann eine einzige App normale SMS und die Krankmeldungsautomatik übernehmen.", C_BLUE_SOFT, C_BLUE));
        Button activate = primaryButton("Als SMS-App verwenden"); activate.setOnClickListener(v -> requestSmsRole()); content.addView(activate);
        content.addView(infoCard("Einmalig bestätigen. Danach erscheinen normale SMS im Reiter „SMS“ und Krankmeldungen werden im Hintergrund ausgewertet."));
    }

    private void showPinSetupDialog() {
        tabsRow.setVisibility(View.GONE); content.removeAllViews(); content.addView(infoCard("Lege beim ersten Start eine PIN für das Diensthandy fest."));
        LinearLayout l = dialogLayout(); EditText p1 = pinField("Neue PIN (4–8 Ziffern)"), p2 = pinField("PIN wiederholen"); l.addView(p1); l.addView(p2);
        AlertDialog d = new AlertDialog.Builder(this).setTitle("PIN festlegen").setView(l).setPositiveButton("Speichern", null).setCancelable(false).create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String a=p1.getText().toString(), b=p2.getText().toString(); if(!pinSecurity.isValidFormat(a)){toast("PIN muss aus 4–8 Ziffern bestehen");return;} if(!a.equals(b)){toast("PINs stimmen nicht überein");return;}
            pinSecurity.setPin(a); SessionState.unlock(); d.dismiss(); requestSmsPermissions(); renderActiveTab(); scheduleAutoLock();
        })); d.show();
    }

    private void showUnlockDialog() {
        tabsRow.setVisibility(View.GONE); content.removeAllViews(); content.addView(infoCard("Die SMS-Automatik läuft im Hintergrund weiter. Für die Oberfläche wird die PIN benötigt."));
        EditText pin = pinField("PIN");
        AlertDialog d = new AlertDialog.Builder(this).setTitle("Kita Krankmeldung entsperren").setView(pin).setPositiveButton("Entsperren", null).setCancelable(false).create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if(!pinSecurity.verify(pin.getText().toString())){pin.setText("");toast("PIN ist nicht korrekt");return;}
            SessionState.unlock(); d.dismiss(); requestSmsPermissions(); renderActiveTab(); scheduleAutoLock();
        })); d.show();
    }

    private void showChangePinDialog() {
        LinearLayout l=dialogLayout(); EditText old=pinField("Aktuelle PIN"), p1=pinField("Neue PIN (4–8 Ziffern)"), p2=pinField("Neue PIN wiederholen"); l.addView(old);l.addView(p1);l.addView(p2);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("PIN ändern").setView(l).setPositiveButton("Ändern",null).setNegativeButton("Abbrechen",null).create();
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(!pinSecurity.verify(old.getText().toString())){toast("Aktuelle PIN ist falsch");return;}if(!pinSecurity.isValidFormat(p1.getText().toString())){toast("Neue PIN muss 4–8 Ziffern haben");return;}if(!p1.getText().toString().equals(p2.getText().toString())){toast("Neue PINs stimmen nicht überein");return;}pinSecurity.setPin(p1.getText().toString());d.dismiss();toast("PIN geändert");})); d.show();
    }

    private void lockApp() { autoLockHandler.removeCallbacks(autoLockRunnable); SessionState.lock(); recreate(); }
    private void scheduleAutoLock() { autoLockHandler.removeCallbacks(autoLockRunnable); if(!SessionState.isUnlocked())return; int m=pinSecurity.getAutoLockMinutes(); if(m>0)autoLockHandler.postDelayed(autoLockRunnable,m*60_000L); }

    private boolean holdsSmsRole() {
        RoleManager rm=(RoleManager)getSystemService(RoleManager.class); return rm!=null&&rm.isRoleAvailable(RoleManager.ROLE_SMS)&&rm.isRoleHeld(RoleManager.ROLE_SMS);
    }
    private void requestSmsRole() {
        RoleManager rm=(RoleManager)getSystemService(RoleManager.class); if(rm==null||!rm.isRoleAvailable(RoleManager.ROLE_SMS)){toast("SMS-Rolle ist auf diesem Gerät nicht verfügbar");return;} if(rm.isRoleHeld(RoleManager.ROLE_SMS)){requestSmsPermissions();routeInitialScreen();return;} startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS),101);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==101){if(holdsSmsRole()){requestSmsPermissions();routeInitialScreen();}else showSmsRoleGate();}}

    private void requestSmsPermissions() {
        if (!holdsSmsRole()) return;
        List<String> req=new ArrayList<>();
        if(checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.SEND_SMS);
        if(checkSelfPermission(Manifest.permission.RECEIVE_SMS)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.RECEIVE_SMS);
        if(checkSelfPermission(Manifest.permission.READ_SMS)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.READ_SMS);
        if(checkSelfPermission(Manifest.permission.RECEIVE_MMS)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.RECEIVE_MMS);
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.POST_NOTIFICATIONS);
        if(!req.isEmpty())requestPermissions(req.toArray(new String[0]),102);
    }

    private void requestExactAlarm() {
        try { Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);i.setData(android.net.Uri.parse("package:"+getPackageName()));startActivity(i); }
        catch(Exception ex){toast("Bitte unter Apps > Spezieller Zugriff > Alarme & Erinnerungen freigeben");}
    }

    // ---------------- UI helpers ----------------

    private LinearLayout card() {
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(14),dp(12),dp(14),dp(12));c.setBackground(roundRect(C_CARD,C_BORDER,14));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(9));c.setLayoutParams(lp);return c;
    }
    private LinearLayout statCard(String value,String label,int bg,int color){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(10),dp(10),dp(10),dp(10));c.setBackground(roundRect(bg,bg,12));c.addView(text(value,24,color,true));c.addView(text(label,11,color,false));return c;}
    private LinearLayout coloredNotice(String title,String body,int bg,int color){LinearLayout c=card();c.setBackground(roundRect(bg,color,12));c.addView(text(title,13,color,true));TextView b=text(body,13,color,false);b.setPadding(0,dp(4),0,0);c.addView(b);return c;}
    private LinearLayout infoCard(String body){LinearLayout c=card();c.addView(text(body,13,C_MUTED,false));return c;}
    private LinearLayout emptyState(String title,String body){LinearLayout c=card();c.setGravity(Gravity.CENTER_HORIZONTAL);c.addView(text(title,16,C_TEXT,true));TextView b=text(body,13,C_MUTED,false);b.setGravity(Gravity.CENTER);b.setPadding(0,dp(4),0,0);c.addView(b);return c;}
    private TextView section(String s){TextView t=text(s,14,C_TEXT,true);t.setPadding(0,dp(14),0,dp(8));return t;}
    private TextView statusLine(String label,String value,int color){TextView t=text(label+":  "+value,14,color,false);t.setPadding(0,dp(4),0,dp(4));return t;}
    private TextView text(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button primaryButton(String label){Button b=compactButton(label,C_GREEN,Color.WHITE);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.setMargins(0,0,0,dp(8));b.setLayoutParams(lp);return b;}
    private Button secondaryButton(String label){Button b=compactButton(label,C_CARD,C_TEXT);b.setBackground(roundRect(C_CARD,C_BORDER,12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(46));lp.setMargins(0,0,0,dp(8));b.setLayoutParams(lp);return b;}
    private Button compactButton(String label,int bg,int fg){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(13);b.setTextColor(fg);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setMinHeight(0);b.setMinWidth(0);b.setPadding(dp(12),dp(7),dp(12),dp(7));b.setBackground(roundRect(bg,bg,10));return b;}
    private EditText field(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setText(value==null?"":value);e.setTextSize(15);e.setSingleLine(true);e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(roundRect(C_CARD,C_BORDER,10));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(8));e.setLayoutParams(lp);return e;}
    private EditText pinField(String hint){EditText e=field(hint,"");e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);return e;}
    private LinearLayout dialogLayout(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(18),dp(10),dp(18),0);return l;}
    private GradientDrawable roundRect(int fill,int stroke,float radiusDp){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp((int)radiusDp));g.setStroke(dp(1),stroke);return g;}

    private String joinNames(List<AppDb.AbsenceWithEmployee> list){List<String> n=new ArrayList<>();for(AppDb.AbsenceWithEmployee x:list)n.add(x.employee.name);return String.join(", ",n);}
    private String joinEmployeeNames(List<AppDb.Employee> list){List<String> n=new ArrayList<>();for(AppDb.Employee x:list)n.add(x.name);return String.join(", ",n);}
    private String friendlyKind(String k){if(k==null)return"SMS";switch(k){case"morning_digest":return"Morgenmeldung";case"late_addendum":return"Nachtrag";case"noon_reminder":return"Rückfrage";case"leader_info":return"Leitungsinfo";case"employee_confirmation":return"Bestätigung";case"remote_reply":return"Remote-Antwort";default:return"SMS";}}
    private String trimPreview(String s,int max){if(s==null)return"";String x=s.replaceAll("\\s+"," ").trim();return x.length()>max?x.substring(0,max-1)+"…":x;}
    private String formatDateTime(long ms){return DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT,Locale.GERMANY).format(new Date(ms));}
    private String dateLong(LocalDate d){return d.format(DateTimeFormatter.ofPattern("EEEE, dd.MM.yyyy",Locale.GERMANY));}
    private String germanDate(LocalDate d){return d.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));}
    private LocalDate parseGermanDate(String s){try{return LocalDate.parse(s.trim(),DateTimeFormatter.ofPattern("d.M.yyyy"));}catch(Exception e){return null;}}
    private int[] parseTime(String s,int h,int m){try{String[]p=s.trim().split(":");int hh=Integer.parseInt(p[0]),mm=Integer.parseInt(p[1]);if(hh>=0&&hh<=23&&mm>=0&&mm<=59)return new int[]{hh,mm};}catch(Exception ignored){}toast("Ungültige Uhrzeit");return new int[]{h,m};}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
