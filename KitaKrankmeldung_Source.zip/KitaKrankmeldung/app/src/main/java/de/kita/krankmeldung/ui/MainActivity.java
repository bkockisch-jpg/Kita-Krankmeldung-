package de.kita.krankmeldung.ui;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlarmManager;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;

import de.kita.krankmeldung.data.AppDb;
import de.kita.krankmeldung.schedule.AlarmScheduler;
import de.kita.krankmeldung.schedule.DailyActions;
import de.kita.krankmeldung.sms.SmsParser;
import de.kita.krankmeldung.security.PinSecurity;

import java.text.DateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout content;
    private AppDb db;
    private TextView title;
    private PinSecurity pinSecurity;
    private boolean unlocked = false;
    private final Handler autoLockHandler = new Handler(Looper.getMainLooper());
    private long lastInteractionAt = 0L;
    private final Runnable autoLockRunnable = () -> {
        if (unlocked) lockApp();
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new AppDb(this);
        pinSecurity = new PinSecurity(this);
        AlarmScheduler.scheduleAll(this);
        buildShell();
        lastInteractionAt = System.currentTimeMillis();
        showSecurityGate();
    }

    @Override protected void onResume() {
        super.onResume();
        if (content != null && unlocked) {
            int minutes = pinSecurity.getAutoLockMinutes();
            long timeoutMs = minutes <= 0 ? Long.MAX_VALUE : minutes * 60_000L;
            long inactiveMs = Math.max(0L, System.currentTimeMillis() - lastInteractionAt);
            if (minutes > 0 && inactiveMs >= timeoutMs) {
                lockApp();
            } else {
                showToday();
                scheduleAutoLock();
            }
        }
    }

    @Override protected void onPause() {
        super.onPause();
        autoLockHandler.removeCallbacks(autoLockRunnable);
    }

    @Override public boolean dispatchTouchEvent(MotionEvent ev) {
        if (unlocked && (ev.getAction() == MotionEvent.ACTION_DOWN || ev.getAction() == MotionEvent.ACTION_UP)) {
            registerInteraction();
        }
        return super.dispatchTouchEvent(ev);
    }

    private void showSecurityGate() {
        clear("Geschützt");
        content.addView(info("🔐 Der Leitungsbereich ist PIN-geschützt. Die SMS-Automatik läuft im Hintergrund weiter."));
        if (!pinSecurity.hasPin()) showPinSetupDialog();
        else showUnlockDialog();
    }

    private EditText pinField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setSingleLine(true);
        return e;
    }

    private void showPinSetupDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(10), dp(18), 0);
        EditText pin = pinField("Neue PIN (4–8 Ziffern)");
        EditText confirm = pinField("PIN wiederholen");
        l.addView(pin); l.addView(confirm);
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("PIN festlegen")
                .setMessage("Lege beim ersten Start eine PIN für den Leitungsbereich fest.")
                .setView(l)
                .setPositiveButton("PIN speichern", null)
                .setCancelable(false)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String p1 = pin.getText().toString();
            String p2 = confirm.getText().toString();
            if (!pinSecurity.isValidFormat(p1)) { toast("Die PIN muss aus 4 bis 8 Ziffern bestehen"); return; }
            if (!p1.equals(p2)) { toast("Die beiden PINs stimmen nicht überein"); return; }
            pinSecurity.setPin(p1);
            unlocked = true;
            registerInteraction();
            d.dismiss();
            showToday();
        }));
        d.show();
    }

    private void showUnlockDialog() {
        EditText pin = pinField("PIN");
        pin.setPadding(dp(18), dp(8), dp(18), dp(8));
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Leitungsbereich entsperren")
                .setView(pin)
                .setPositiveButton("Entsperren", null)
                .setCancelable(false)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (!pinSecurity.verify(pin.getText().toString())) { pin.setText(""); toast("PIN ist nicht korrekt"); return; }
            unlocked = true;
            registerInteraction();
            d.dismiss();
            showToday();
        }));
        d.show();
    }

    private void showChangePinDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(10), dp(18), 0);
        EditText oldPin = pinField("Aktuelle PIN");
        EditText newPin = pinField("Neue PIN (4–8 Ziffern)");
        EditText confirm = pinField("Neue PIN wiederholen");
        l.addView(oldPin); l.addView(newPin); l.addView(confirm);
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("PIN ändern")
                .setView(l)
                .setPositiveButton("Ändern", null)
                .setNegativeButton("Abbrechen", null)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String oldP = oldPin.getText().toString();
            String newP = newPin.getText().toString();
            String newP2 = confirm.getText().toString();
            if (!pinSecurity.verify(oldP)) { toast("Aktuelle PIN ist nicht korrekt"); return; }
            if (!pinSecurity.isValidFormat(newP)) { toast("Die neue PIN muss aus 4 bis 8 Ziffern bestehen"); return; }
            if (!newP.equals(newP2)) { toast("Die neuen PINs stimmen nicht überein"); return; }
            pinSecurity.setPin(newP);
            d.dismiss();
            toast("PIN wurde geändert");
        }));
        d.show();
    }

    private void lockApp() {
        autoLockHandler.removeCallbacks(autoLockRunnable);
        unlocked = false;
        // Activity neu aufbauen, damit eventuell offene Dialoge ebenfalls geschlossen werden.
        recreate();
    }

    private void registerInteraction() {
        lastInteractionAt = System.currentTimeMillis();
        scheduleAutoLock();
    }

    private void scheduleAutoLock() {
        autoLockHandler.removeCallbacks(autoLockRunnable);
        if (!unlocked) return;
        int minutes = pinSecurity.getAutoLockMinutes();
        if (minutes <= 0) return;
        autoLockHandler.postDelayed(autoLockRunnable, minutes * 60_000L);
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(10));
        root.setBackgroundColor(Color.rgb(247, 248, 250));

        title = new TextView(this);
        title.setTextSize(27);
        title.setTextColor(Color.rgb(28, 32, 38));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setText("Übersicht");
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Kita Krankmeldung · SMS-Zentrale");
        sub.setTextColor(Color.rgb(102, 109, 119));
        sub.setTextSize(13);
        sub.setPadding(0, dp(2), 0, dp(12));
        root.addView(sub);

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(0, 0, 0, dp(4));
        Button today = navButton("Übersicht");
        Button emp = navButton("Team");
        Button inbox = navButton("SMS");
        Button settings = navButton("Setup");
        nav.addView(today); nav.addView(emp); nav.addView(inbox); nav.addView(settings);
        root.addView(nav);
        today.setOnClickListener(v->showToday());
        emp.setOnClickListener(v->showEmployees());
        inbox.setOnClickListener(v->showInbox());
        settings.setOnClickListener(v->showSettings());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(8), 0, dp(30));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    private Button navButton(String text) {
        Button b=new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setTextColor(Color.rgb(45, 51, 59));
        b.setPadding(dp(2),0,dp(2),0);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setLayoutParams(new LinearLayout.LayoutParams(0,dp(44),1));
        return b;
    }
    private void clear(String screenTitle){ content.removeAllViews(); title.setText(screenTitle); }
    private TextView section(String text){ TextView t=new TextView(this); t.setText(text); t.setTextColor(Color.rgb(40,45,52)); t.setTextSize(18); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(0,dp(18),0,dp(8)); return t; }
    private TextView info(String text){ TextView t=new TextView(this); t.setText(text); t.setTextColor(Color.rgb(45,51,59)); t.setTextSize(15); t.setPadding(dp(12),dp(10),dp(12),dp(10)); return t; }
    private Button action(String text){
        Button b=new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(Color.rgb(42,48,56));
        GradientDrawable g=bg(Color.WHITE,14);
        g.setStroke(dp(1),Color.rgb(224,227,232));
        b.setBackground(g);
        b.setPadding(dp(12),dp(9),dp(12),dp(9));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(50));
        lp.setMargins(0,dp(4),0,dp(5));
        b.setLayoutParams(lp);
        return b;
    }

    private GradientDrawable bg(int fill, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView cardText(String text, int fill, int textColor) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setTextColor(textColor);
        t.setPadding(dp(14), dp(13), dp(14), dp(13));
        t.setBackground(bg(fill, 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(4), 0, dp(6));
        t.setLayoutParams(lp);
        return t;
    }

    private TextView statCard(String label, String value, int fill, int accent) {
        TextView t = new TextView(this);
        android.text.SpannableString s = new android.text.SpannableString(value + "\n" + label);
        s.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), 0, value.length(), 0);
        s.setSpan(new android.text.style.AbsoluteSizeSpan(26, true), 0, value.length(), 0);
        t.setText(s);
        t.setTextColor(accent);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(14), dp(12), dp(14), dp(12));
        t.setBackground(bg(fill, 16));
        t.setLayoutParams(new LinearLayout.LayoutParams(0, dp(82), 1));
        return t;
    }

    private TextView personCard(String name, String status, int accent, int softFill) {
        TextView t = new TextView(this);
        android.text.SpannableString s = new android.text.SpannableString(name + "\n" + status);
        s.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), 0, name.length(), 0);
        s.setSpan(new android.text.style.AbsoluteSizeSpan(17, true), 0, name.length(), 0);
        t.setText(s);
        t.setTextColor(Color.rgb(38,43,49));
        t.setTextSize(13);
        t.setPadding(dp(16), dp(13), dp(16), dp(13));
        GradientDrawable g = bg(softFill, 16);
        g.setStroke(dp(1), accent);
        t.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(4), 0, dp(6));
        t.setLayoutParams(lp);
        return t;
    }

    private void showToday() {
        clear("Übersicht");
        LocalDate today = LocalDate.now(), tomorrow = today.plusDays(1);
        DateTimeFormatter full = DateTimeFormatter.ofPattern("EEEE, dd.MM.yyyy", Locale.GERMANY);
        DateTimeFormatter shortDate = DateTimeFormatter.ofPattern("dd.MM.", Locale.GERMANY);

        TextView date = info(today.format(full));
        date.setTextSize(14);
        date.setTextColor(Color.rgb(105,111,120));
        date.setPadding(0,0,0,dp(6));
        content.addView(date);

        if (!holdsSmsRole()) {
            TextView warning = cardText("⚠️ SMS-Automatik noch nicht aktiviert\nDamit Krankmeldungen automatisch verarbeitet werden, diese App einmal als SMS-App freigeben.",
                    Color.rgb(255,247,225), Color.rgb(121,82,12));
            content.addView(warning);
            Button role=action("SMS-Automatik aktivieren");
            role.setOnClickListener(v->requestSmsRole());
            content.addView(role);
        }

        List<AppDb.AbsenceWithEmployee> abs = db.absencesOn(today);
        int tomorrowAway = 0, tomorrowBack = 0, tomorrowOpen = 0;
        for (AppDb.AbsenceWithEmployee a : abs) {
            if (a.absence.endDate == null) tomorrowOpen++;
            else if (a.absence.endDate.isAfter(today)) tomorrowAway++;
            else tomorrowBack++;
        }

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        TextView todayStat = statCard("heute abwesend", String.valueOf(abs.size()), Color.rgb(255,238,238), Color.rgb(176,46,46));
        TextView openStat = statCard("Rückmeldung offen", String.valueOf(tomorrowOpen), Color.rgb(255,247,225), Color.rgb(151,101,15));
        LinearLayout.LayoutParams left = (LinearLayout.LayoutParams) todayStat.getLayoutParams();
        left.setMargins(0,0,dp(5),0); todayStat.setLayoutParams(left);
        LinearLayout.LayoutParams right = (LinearLayout.LayoutParams) openStat.getLayoutParams();
        right.setMargins(dp(5),0,0,0); openStat.setLayoutParams(right);
        stats.addView(todayStat); stats.addView(openStat);
        content.addView(stats);

        content.addView(section("Heute"));
        if (abs.isEmpty()) {
            content.addView(cardText("✅ Heute ist aktuell niemand als abwesend eingetragen.", Color.rgb(235,248,239), Color.rgb(40,105,62)));
        }
        for (AppDb.AbsenceWithEmployee a:abs) {
            String status;
            int accent, soft;
            if (a.absence.endDate == null) {
                status="Rückmeldung für morgen noch offen";
                accent=Color.rgb(220,158,46); soft=Color.rgb(255,250,235);
            } else if (a.absence.endDate.isAfter(today)) {
                status="Weiter abwesend bis " + a.absence.endDate.format(shortDate);
                accent=Color.rgb(203,66,66); soft=Color.rgb(255,242,242);
            } else {
                status="Morgen wieder im Dienst";
                accent=Color.rgb(64,145,84); soft=Color.rgb(239,250,242);
            }
            TextView row=personCard(a.employee.name, status, accent, soft);
            row.setOnLongClickListener(v->{ confirmPresent(a.employee); return true;});
            content.addView(row);
        }

        content.addView(section("Morgen · Planung"));
        LinearLayout tomorrowStats = new LinearLayout(this);
        tomorrowStats.setOrientation(LinearLayout.HORIZONTAL);
        TextView away = statCard("abwesend", String.valueOf(tomorrowAway), Color.rgb(255,242,242), Color.rgb(176,46,46));
        TextView back = statCard("wieder da", String.valueOf(tomorrowBack), Color.rgb(239,250,242), Color.rgb(47,124,68));
        TextView open = statCard("offen", String.valueOf(tomorrowOpen), Color.rgb(255,248,230), Color.rgb(151,101,15));
        LinearLayout.LayoutParams p1=(LinearLayout.LayoutParams)away.getLayoutParams(); p1.setMargins(0,0,dp(4),0); away.setLayoutParams(p1);
        LinearLayout.LayoutParams p2=(LinearLayout.LayoutParams)back.getLayoutParams(); p2.setMargins(dp(4),0,dp(4),0); back.setLayoutParams(p2);
        LinearLayout.LayoutParams p3=(LinearLayout.LayoutParams)open.getLayoutParams(); p3.setMargins(dp(4),0,0,0); open.setLayoutParams(p3);
        tomorrowStats.addView(away); tomorrowStats.addView(back); tomorrowStats.addView(open);
        content.addView(tomorrowStats);

        SharedPreferences pref=getSharedPreferences(AlarmScheduler.PREFS,MODE_PRIVATE);
        String morning=String.format(Locale.GERMANY,"%02d:%02d",pref.getInt("morning_hour",7),pref.getInt("morning_minute",45));
        String noon=String.format(Locale.GERMANY,"%02d:%02d",pref.getInt("noon_hour",12),pref.getInt("noon_minute",0));
        content.addView(section("Automatik"));
        content.addView(cardText("📨 Team-SMS  " + morning + " Uhr\nHeute abwesend sind: …\n\n🕛 Rückfrage  " + noon + " Uhr\nNur an Personen mit offenem Status für morgen.",
                Color.WHITE, Color.rgb(54,60,68)));

        content.addView(section("Schnellaktionen"));
        Button add=action("+ Abwesenheit eintragen"); add.setOnClickListener(v->manualAbsenceDialog()); content.addView(add);
        Button digest=action("Team-SMS jetzt senden"); digest.setOnClickListener(v->{ boolean ok=DailyActions.sendMorningDigest(this,true); toast(ok?"Team-SMS wurde gesendet":"Keine Abwesenden – keine SMS gesendet"); }); content.addView(digest);
        Button addon=action("Nachtrag ans Team senden"); addon.setOnClickListener(v->{ boolean ok=DailyActions.sendLateAddendum(this); toast(ok?"Nachtrag wurde gesendet":"Keine neuen, noch nicht angekündigten Abwesenheiten"); }); content.addView(addon);
        Button noonBtn=action("Mittags-Rückfrage jetzt senden"); noonBtn.setOnClickListener(v->{ int n=DailyActions.sendNoonReminders(this,true); toast("Rückfrage an " + n + " Person(en) gesendet"); }); content.addView(noonBtn);

        TextView hint=info("💡 Lange auf einen Namen drücken, um eine heutige Abwesenheit manuell zu beenden.");
        hint.setTextSize(12); hint.setTextColor(Color.rgb(110,116,124)); content.addView(hint);
    }

    private void showEmployees() {
        clear("Team");
        List<AppDb.Employee> list=db.allEmployees(false);
        int active=0, leaders=0;
        for(AppDb.Employee e:list){ if(e.active) active++; if(e.active && e.leader) leaders++; }

        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
        TextView activeCard=statCard("aktiv",String.valueOf(active),Color.rgb(239,246,255),Color.rgb(45,93,154));
        TextView leaderCard=statCard("Leitung",String.valueOf(leaders),Color.rgb(242,239,253),Color.rgb(93,65,151));
        LinearLayout.LayoutParams a=(LinearLayout.LayoutParams)activeCard.getLayoutParams();a.setMargins(0,0,dp(5),0);activeCard.setLayoutParams(a);
        LinearLayout.LayoutParams b=(LinearLayout.LayoutParams)leaderCard.getLayoutParams();b.setMargins(dp(5),0,0,0);leaderCard.setLayoutParams(b);
        stats.addView(activeCard);stats.addView(leaderCard);content.addView(stats);

        Button add=action("+ Mitarbeitende hinzufügen"); add.setOnClickListener(v->employeeDialog(null)); content.addView(add);
        content.addView(section("Mitarbeitende"));
        if(list.isEmpty()) content.addView(cardText("Noch niemand angelegt. Für den Start reichen Name und Mobilnummer.",Color.WHITE,Color.rgb(68,74,82)));
        for(AppDb.Employee e:list){
            String state=e.active?"Aktiv":"Deaktiviert";
            String role=e.leader?" · Leitung":"";
            int accent=e.active?Color.rgb(76,142,93):Color.rgb(160,164,170);
            int soft=e.active?Color.WHITE:Color.rgb(244,245,247);
            TextView row=personCard(e.name,state+role+"\n"+e.phone,accent,soft);
            row.setOnClickListener(v->employeeDialog(e)); content.addView(row);
        }
    }

    private void showInbox() {
        clear("SMS-Eingang");
        content.addView(cardText("Hier siehst du eingegangene Nachrichten. Unklare Rückmeldungen werden nicht automatisch als Abwesenheit übernommen.",Color.rgb(239,246,255),Color.rgb(51,79,116)));
        List<AppDb.InboundMessage> messages=db.recentInbound(50);
        content.addView(section("Letzte Nachrichten · "+messages.size()));
        if(messages.isEmpty()) content.addView(cardText("Noch keine SMS erfasst.",Color.WHITE,Color.rgb(85,91,100)));
        for(AppDb.InboundMessage m:messages){
            AppDb.Employee e=db.findEmployeeByPhone(m.phone);
            String who=e==null?m.phone:e.name;
            String time=DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT,Locale.GERMANY).format(new Date(m.receivedAt));
            boolean review="NEEDS_REVIEW".equals(m.status)||"UNKNOWN_SENDER".equals(m.status);
            String label=review?"Bitte prüfen":"Verarbeitet";
            int accent=review?Color.rgb(220,158,46):Color.rgb(76,142,93);
            int soft=review?Color.rgb(255,250,235):Color.WHITE;
            content.addView(personCard(who,label+" · "+time+"\n“"+m.body+"”",accent,soft));
        }
    }

    private void showSettings() {
        clear("Einstellungen");
        SharedPreferences p=getSharedPreferences(AlarmScheduler.PREFS,MODE_PRIVATE);
        content.addView(section("Automatischer Versand"));
        EditText morning=new EditText(this); morning.setHint("Morgens, z. B. 07:45"); morning.setText(String.format(Locale.GERMANY,"%02d:%02d",p.getInt("morning_hour",7),p.getInt("morning_minute",45))); content.addView(morning);
        EditText noon=new EditText(this); noon.setHint("Mittags, z. B. 12:00"); noon.setText(String.format(Locale.GERMANY,"%02d:%02d",p.getInt("noon_hour",12),p.getInt("noon_minute",0))); content.addView(noon);
        Button save=action("Zeiten speichern"); save.setOnClickListener(v->{
            int[] m=parseTime(morning.getText().toString(),7,45), n=parseTime(noon.getText().toString(),12,0);
            p.edit().putInt("morning_hour",m[0]).putInt("morning_minute",m[1]).putInt("noon_hour",n[0]).putInt("noon_minute",n[1]).apply(); AlarmScheduler.scheduleAll(this); toast("Zeiten gespeichert");
        }); content.addView(save);

        content.addView(section("SMS-Zugriff"));
        content.addView(info(holdsSmsRole()?"✅ Diese App ist als SMS-App aktiviert.":"⚠️ Noch nicht als SMS-App aktiviert."));
        Button role=action("SMS-App/Rolle auswählen"); role.setOnClickListener(v->requestSmsRole()); content.addView(role);
        Button perms=action("SMS-Berechtigungen prüfen"); perms.setOnClickListener(v->requestSmsPermissions()); content.addView(perms);

        content.addView(section("Pünktlicher Versand"));
        AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
        boolean exact=android.os.Build.VERSION.SDK_INT<31 || am.canScheduleExactAlarms();
        content.addView(info(exact?"✅ Genaue Alarmzeiten sind freigegeben.":"⚠️ Android darf Versandzeiten aktuell leicht verzögern."));
        if(!exact){ Button exactBtn=action("Genaue Versandzeiten freigeben"); exactBtn.setOnClickListener(v->{ try{Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM); i.setData(android.net.Uri.parse("package:"+getPackageName())); startActivity(i);}catch(Exception ex){toast("Freigabe bitte unter Einstellungen > Apps > Spezieller Zugriff > Alarme & Erinnerungen aktivieren");} }); content.addView(exactBtn); }

        content.addView(section("Sicherheit"));
        content.addView(info("🔐 Der Leitungsbereich ist mit einer frei wählbaren PIN aus 4–8 Ziffern geschützt. Die PIN wird nicht im Klartext gespeichert."));

        TextView autoLockLabel = info("Automatisch sperren nach Inaktivität");
        content.addView(autoLockLabel);
        Spinner autoLock = new Spinner(this);
        String[] lockOptions = new String[]{"2 Minuten", "5 Minuten", "10 Minuten", "Nie"};
        int[] lockValues = new int[]{2, 5, 10, 0};
        autoLock.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, lockOptions));
        int currentLock = pinSecurity.getAutoLockMinutes();
        int selected = 1;
        for (int i = 0; i < lockValues.length; i++) if (lockValues[i] == currentLock) selected = i;
        autoLock.setSelection(selected);
        content.addView(autoLock);
        Button saveAutoLock = action("Sperrzeit speichern");
        saveAutoLock.setOnClickListener(v -> {
            int value = lockValues[autoLock.getSelectedItemPosition()];
            pinSecurity.setAutoLockMinutes(value);
            registerInteraction();
            toast(value == 0 ? "Automatische Sperre deaktiviert" : "Automatische Sperre: " + value + " Minuten");
        });
        content.addView(saveAutoLock);
        Button changePin=action("PIN ändern"); changePin.setOnClickListener(v->showChangePinDialog()); content.addView(changePin);
        Button lock=action("App jetzt sperren"); lock.setOnClickListener(v->lockApp()); content.addView(lock);

        content.addView(section("Datenschutz"));
        content.addView(info("Die App speichert Mitarbeiterstammdaten, SMS-Eingänge und Abwesenheiten ausschließlich lokal auf diesem Diensthandy. Krankheitsgründe oder Diagnosen werden nicht benötigt."));
    }

    private void employeeDialog(AppDb.Employee existing) {
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); int pad=dp(18); l.setPadding(pad,pad,pad,0);
        EditText name=new EditText(this); name.setHint("Name"); EditText phone=new EditText(this); phone.setHint("Mobilnummer");
        CheckBox leader=new CheckBox(this); leader.setText("Leitung – erhält direkte Rückmeldungen"); CheckBox active=new CheckBox(this); active.setText("Aktiv"); active.setChecked(true);
        if(existing!=null){name.setText(existing.name);phone.setText(existing.phone);leader.setChecked(existing.leader);active.setChecked(existing.active);}
        l.addView(name);l.addView(phone);l.addView(leader);l.addView(active);
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle(existing==null?"Mitarbeitende hinzufügen":"Mitarbeitende bearbeiten").setView(l)
                .setPositiveButton("Speichern",(d,w)->{ if(name.getText().toString().trim().isEmpty()||phone.getText().toString().trim().isEmpty()){toast("Name und Nummer werden benötigt");return;} try{db.upsertEmployee(existing==null?null:existing.id,name.getText().toString(),phone.getText().toString(),leader.isChecked(),active.isChecked());showEmployees();}catch(Exception ex){toast("Speichern fehlgeschlagen – Nummer eventuell doppelt");}})
                .setNegativeButton("Abbrechen",null);
        if(existing!=null)b.setNeutralButton("Löschen",(d,w)->{db.deleteEmployee(existing.id);showEmployees();}); b.show();
    }

    private void manualAbsenceDialog() {
        List<AppDb.Employee> employees=db.allEmployees(true); if(employees.isEmpty()){toast("Bitte zuerst Mitarbeitende anlegen");return;}
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(18),dp(12),dp(18),0);
        Spinner spinner=new Spinner(this); List<String> names=new ArrayList<>(); for(AppDb.Employee e:employees)names.add(e.name); spinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));
        EditText until=new EditText(this);until.setHint("Optional: abwesend bis DD.MM.YYYY"); l.addView(spinner);l.addView(until);
        new AlertDialog.Builder(this).setTitle("Abwesenheit eintragen").setView(l).setPositiveButton("Eintragen",(d,w)->{
            AppDb.Employee e=employees.get(spinner.getSelectedItemPosition()); LocalDate end=null; String s=until.getText().toString().trim();
            if(!s.isEmpty()){ try{end=LocalDate.parse(s,DateTimeFormatter.ofPattern("d.M.yyyy"));}catch(Exception ex){toast("Datum nicht erkannt – als offen eingetragen");} }
            db.markAbsent(e.id,LocalDate.now(),end,"manual"); showToday();
        }).setNegativeButton("Abbrechen",null).show();
    }

    private void confirmPresent(AppDb.Employee e){ new AlertDialog.Builder(this).setTitle(e.name+" wieder anwesend?").setMessage("Die heutige Abwesenheit wird beendet bzw. entfernt.").setPositiveButton("Ja",(d,w)->{db.clearTodayAbsence(e.id,LocalDate.now());showToday();}).setNegativeButton("Abbrechen",null).show(); }

    private boolean holdsSmsRole(){ RoleManager rm=(RoleManager)getSystemService(RoleManager.class); return rm!=null&&rm.isRoleAvailable(RoleManager.ROLE_SMS)&&rm.isRoleHeld(RoleManager.ROLE_SMS); }
    private void requestSmsRole(){
        RoleManager rm=(RoleManager)getSystemService(RoleManager.class); if(rm!=null&&rm.isRoleAvailable(RoleManager.ROLE_SMS)){ if(!rm.isRoleHeld(RoleManager.ROLE_SMS)) startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS),101); else requestSmsPermissions(); }
        else toast("SMS-Rolle ist auf diesem Gerät nicht verfügbar");
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==101){requestSmsPermissions();showToday();}}
    private void requestSmsPermissions(){
        List<String> req=new ArrayList<>(); if(checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.SEND_SMS); if(checkSelfPermission(Manifest.permission.RECEIVE_SMS)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.RECEIVE_SMS); if(checkSelfPermission(Manifest.permission.READ_SMS)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.READ_SMS);
        if(!req.isEmpty())requestPermissions(req.toArray(new String[0]),102);else toast("SMS-Berechtigungen sind vorhanden");
    }
    private int[] parseTime(String s,int h,int m){try{String[]p=s.trim().split(":");int hh=Integer.parseInt(p[0]),mm=Integer.parseInt(p[1]);if(hh>=0&&hh<=23&&mm>=0&&mm<=59)return new int[]{hh,mm};}catch(Exception ignored){}toast("Ungültige Uhrzeit – Standardwert bleibt");return new int[]{h,m};}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
