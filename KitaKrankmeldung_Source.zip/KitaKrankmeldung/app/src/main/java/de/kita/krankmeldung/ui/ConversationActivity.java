package de.kita.krankmeldung.ui;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.view.MotionEvent;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import de.kita.krankmeldung.data.AppDb;
import de.kita.krankmeldung.sms.SmsSender;
import de.kita.krankmeldung.sms.SmsStore;
import de.kita.krankmeldung.security.PinSecurity;
import de.kita.krankmeldung.security.SessionState;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ConversationActivity extends Activity {
    private static final int BG = Color.rgb(246,248,250);
    private static final int TEXT = Color.rgb(29,41,57);
    private static final int MUTED = Color.rgb(102,112,133);
    private static final int GREEN = Color.rgb(31,107,69);

    private String address;
    private LinearLayout messages;
    private ScrollView scroll;
    private EditText reply;
    private SmsStore store;
    private PinSecurity pinSecurity;
    private final Handler lockHandler = new Handler(Looper.getMainLooper());
    private final Runnable lockRunnable = () -> { SessionState.lock(); finish(); startActivity(new Intent(this, MainActivity.class)); };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        address = getIntent().getStringExtra("address");
        if (address == null) address = "";
        store = new SmsStore(this);
        pinSecurity = new PinSecurity(this);
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        if (!SessionState.isUnlocked()) { finish(); startActivity(new Intent(this, MainActivity.class)); return; }
        int minutes = pinSecurity.getAutoLockMinutes();
        if (minutes > 0 && SessionState.inactiveForMs() >= minutes * 60_000L) {
            SessionState.lock(); finish(); startActivity(new Intent(this, MainActivity.class)); return;
        }
        reload();
        scheduleLock();
    }

    @Override protected void onPause() { super.onPause(); lockHandler.removeCallbacks(lockRunnable); }

    @Override public boolean dispatchTouchEvent(MotionEvent ev) {
        if (SessionState.isUnlocked() && (ev.getAction()==MotionEvent.ACTION_DOWN || ev.getAction()==MotionEvent.ACTION_UP)) { SessionState.touch(); scheduleLock(); }
        return super.dispatchTouchEvent(ev);
    }

    private void scheduleLock() { lockHandler.removeCallbacks(lockRunnable); int m=pinSecurity.getAutoLockMinutes(); if(SessionState.isUnlocked() && m>0) lockHandler.postDelayed(lockRunnable,m*60_000L); }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(10));
        root.setBackgroundColor(BG);

        AppDb.Employee e = new AppDb(this).findEmployeeByPhone(address);
        TextView title = text(e == null ? address : e.name, 21, TEXT, true);
        root.addView(title);
        if (e != null) {
            TextView number = text(address, 12, MUTED, false);
            number.setPadding(0, dp(1), 0, dp(8));
            root.addView(number);
        }

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(0, dp(4), 0, dp(6));
        scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout sendRow = new LinearLayout(this);
        sendRow.setOrientation(LinearLayout.HORIZONTAL);
        sendRow.setGravity(Gravity.BOTTOM);
        reply = new EditText(this);
        reply.setHint("SMS schreiben …");
        reply.setMinLines(1);
        reply.setMaxLines(4);
        reply.setTextSize(15);
        reply.setPadding(dp(12), dp(10), dp(12), dp(10));
        reply.setBackground(round(Color.WHITE, Color.rgb(228,231,236), 14));
        Button send = new Button(this);
        send.setText("Senden");
        send.setAllCaps(false);
        send.setTextColor(Color.WHITE);
        send.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        send.setBackground(round(GREEN, GREEN, 12));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, -2, 1);
        rp.setMargins(0,0,dp(8),0);
        sendRow.addView(reply, rp);
        sendRow.addView(send, new LinearLayout.LayoutParams(dp(88), dp(48)));
        root.addView(sendRow);
        send.setOnClickListener(v -> sendReply());
        setContentView(root);
    }

    private void reload() {
        store.markConversationRead(address);
        List<SmsStore.SmsItem> list = store.conversation(address, 160);
        messages.removeAllViews();
        for (SmsStore.SmsItem m : list) {
            LinearLayout wrap = new LinearLayout(this);
            wrap.setOrientation(LinearLayout.VERTICAL);
            wrap.setGravity(m.incoming() ? Gravity.START : Gravity.END);

            TextView bubble = text(m.body, 15, TEXT, false);
            bubble.setPadding(dp(12), dp(9), dp(12), dp(9));
            bubble.setBackground(round(m.incoming() ? Color.WHITE : Color.rgb(229, 247, 237), m.incoming() ? Color.rgb(228,231,236) : Color.rgb(186,230,201), 14));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2);
            bp.setMargins(0, dp(4), 0, dp(2));
            wrap.addView(bubble, bp);

            String time = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT, Locale.GERMANY).format(new Date(m.date));
            TextView meta = text(time, 11, MUTED, false);
            wrap.addView(meta);
            messages.addView(wrap, new LinearLayout.LayoutParams(-1, -2));
        }
        scroll.post(() -> scroll.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private void sendReply() {
        String text = reply.getText().toString().trim();
        if (text.isEmpty()) return;
        boolean ok = new SmsSender(this).sendManual(address, text);
        if (ok) { reply.setText(""); reload(); }
        else Toast.makeText(this, "SMS konnte nicht gestartet werden", Toast.LENGTH_LONG).show();
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private GradientDrawable round(int fill, int stroke, int radius) { GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g; }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
