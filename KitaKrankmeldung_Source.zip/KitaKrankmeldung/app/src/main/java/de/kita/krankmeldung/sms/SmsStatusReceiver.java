package de.kita.krankmeldung.sms;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;

import de.kita.krankmeldung.data.AppDb;

public class SmsStatusReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        long id = intent.getLongExtra(SmsSender.EXTRA_ATTEMPT_ID, -1L);
        if (id < 0) return;
        AppDb db = new AppDb(context);
        AppDb.SendAttempt current = db.getSendAttempt(id);
        if (current == null) return;

        if (SmsSender.ACTION_SENT.equals(intent.getAction())) {
            int result = getResultCode();
            if (result == Activity.RESULT_OK) {
                if (!"FAILED".equals(current.status)) db.updateSendStatus(id, "SENT", null);
            } else {
                db.updateSendStatus(id, "FAILED", result);
            }
        } else if (SmsSender.ACTION_DELIVERED.equals(intent.getAction())) {
            int result = getResultCode();
            if (result == Activity.RESULT_OK) {
                AppDb.SendAttempt latest = db.getSendAttempt(id);
                if (latest != null && !"FAILED".equals(latest.status)) db.updateSendStatus(id, "DELIVERED", null);
            } else {
                // Zustellbericht fehlgeschlagen bedeutet nicht zwingend, dass die SMS nicht gesendet wurde.
                AppDb.SendAttempt latest = db.getSendAttempt(id);
                if (latest != null && "SENDING".equals(latest.status)) db.updateSendStatus(id, "SENT", result);
            }
        }
    }

    public static String describeError(Integer code) {
        if (code == null) return "Unbekannter Fehler";
        if (code == -1001) return "Testmodus aktiv, aber keine Testnummer hinterlegt";
        if (code == -1000) return "SMS konnte nicht an Android übergeben werden";
        switch (code) {
            case SmsManager.RESULT_ERROR_GENERIC_FAILURE: return "Allgemeiner SMS-Fehler";
            case SmsManager.RESULT_ERROR_NO_SERVICE: return "Kein Mobilfunkdienst";
            case SmsManager.RESULT_ERROR_NULL_PDU: return "Ungültige SMS-Daten";
            case SmsManager.RESULT_ERROR_RADIO_OFF: return "Mobilfunk ist ausgeschaltet";
            default: return "SMS-Fehler (Code " + code + ")";
        }
    }
}
