package de.kita.krankmeldung.sms;

import android.content.Context;

import de.kita.krankmeldung.data.AppDb;
import de.kita.krankmeldung.schedule.DailyActions;
import de.kita.krankmeldung.util.AppSettings;
import de.kita.krankmeldung.util.WorkCalendar;

import java.text.Normalizer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/** SMS-Fernsteuerung für explizit als Leitung markierte Telefonnummern. */
public class RemoteCommandProcessor {
    public static class Result {
        public final boolean handled;
        public final String status;
        public final String interpretation;
        public Result(boolean handled, String status, String interpretation) {
            this.handled = handled; this.status = status; this.interpretation = interpretation;
        }
        public static Result no() { return new Result(false, "", ""); }
    }

    private final Context context;
    private final AppDb db;
    private final SmsSender sender;
    private final AppSettings settings;
    private final SmsParser parser = new SmsParser();

    public RemoteCommandProcessor(Context context) {
        this.context = context.getApplicationContext();
        this.db = new AppDb(context);
        this.sender = new SmsSender(context);
        this.settings = new AppSettings(context);
    }

    public Result tryHandle(AppDb.Employee leader, String phone, String raw) {
        if (leader == null || !leader.leader || raw == null) return Result.no();
        String s = normalize(raw);
        if (s.trim().isEmpty()) return Result.no();

        AppDb.RemoteSession session = db.getRemoteSession(phone);
        if (session != null) {
            Result r = handleSession(session, raw);
            if (r.handled) return r;
        }

        LocalDate today = LocalDate.now();
        LocalDate next = WorkCalendar.nextBusinessDay(today);

        if (isStatusToday(s)) {
            reply(phone, statusText(today, "Heute"));
            return handled("REMOTE_STATUS", "Status heute abgefragt");
        }
        if (isStatusNext(s)) {
            reply(phone, statusText(next, "Nächster Arbeitstag " + shortDate(next)));
            return handled("REMOTE_STATUS", "Status nächster Arbeitstag abgefragt");
        }
        if (containsAny(s, "offene ruckmeldungen", "offene rueckmeldungen", "wer hat sich noch nicht", "wer muss noch antworten", "ruckmeldung offen", "rueckmeldung offen")) {
            List<AppDb.AbsenceWithEmployee> open = db.needingFollowup(today, next);
            String text = open.isEmpty() ? "Für " + shortDate(next) + " sind keine Rückmeldungen offen."
                    : "Offen für " + shortDate(next) + ": " + open.stream().map(x -> x.employee.name).collect(Collectors.joining(", ")) + ".";
            reply(phone, text);
            return handled("REMOTE_STATUS", "Offene Rückmeldungen abgefragt");
        }

        if (containsAny(s, "nachtrag senden", "nachtrag verschicken", "sende nachtrag")) {
            boolean sent = DailyActions.sendLateAddendum(context);
            reply(phone, sent ? "Nachtrag wurde angestoßen." : "Es gibt aktuell keinen neuen Nachtrag zu versenden.");
            db.audit("REMOTE_ADDENDUM", null, sent ? "gesendet" : "kein Nachtrag", leader.name);
            return handled("REMOTE_COMMAND", "Nachtrag per Leitung angefordert");
        }

        if (containsAny(s, "testmodus an", "test modus an", "testmodus ein")) {
            if (settings.getTestNumber().trim().isEmpty()) {
                db.saveRemoteSession(phone, leader.id, "ASK_TEST_NUMBER", null, "", System.currentTimeMillis() + 10 * 60_000L);
                reply(phone, "Testmodus noch nicht aktiviert. Bitte sende jetzt: TESTNUMMER 0176... (Abbrechen mit STOP)");
            } else {
                settings.setTestMode(true);
                reply(phone, "Testmodus ist aktiv. Automatische SMS gehen nur an die hinterlegte Testnummer.");
                db.audit("TEST_MODE", null, "an", leader.name);
            }
            return handled("REMOTE_COMMAND", "Testmodus einschalten");
        }
        if (containsAny(s, "testmodus aus", "test modus aus")) {
            settings.setTestMode(false);
            reply(phone, "Testmodus ist aus. Automatische SMS gehen wieder an die echten Empfänger.");
            db.audit("TEST_MODE", null, "aus", leader.name);
            return handled("REMOTE_COMMAND", "Testmodus ausschalten");
        }
        if (s.startsWith("testnummer ") || s.startsWith("test nummer ")) {
            String number = raw.replaceFirst("(?i)test\\s*nummer\\s*", "").trim();
            if (number.replaceAll("\\D", "").length() < 8) {
                reply(phone, "Die Testnummer sieht unvollständig aus. Bitte erneut senden, z. B. TESTNUMMER 0176...");
            } else {
                settings.setTestNumber(number);
                reply(phone, "Testnummer gespeichert: " + AppDb.normalizePhone(number));
                db.audit("TEST_NUMBER", null, AppDb.normalizePhone(number), leader.name);
            }
            return handled("REMOTE_COMMAND", "Testnummer ändern");
        }

        AppDb.Employee target = findMentionedEmployee(s);
        if (target != null) {
            if (containsAny(s, "heute da", "doch da", "doch anwesend", "heute anwesend")) {
                db.clearTodayAbsence(target.id, today);
                reply(phone, target.name + " wurde für heute als anwesend korrigiert.");
                db.audit("REMOTE_CORRECTION", target.id, "heute anwesend", leader.name);
                return handled("REMOTE_COMMAND", target.name + " heute anwesend");
            }
            if (containsAny(s, "morgen da", "morgen wieder da", "nachsten arbeitstag da", "nächsten arbeitstag da")) {
                boolean ok = db.setReturnDate(target.id, next);
                reply(phone, ok ? target.name + " ist ab dem nächsten Arbeitstag wieder als anwesend vorgemerkt."
                        : "Für " + target.name + " gibt es aktuell keine laufende Abwesenheit. Es wurde nichts geändert.");
                return handled("REMOTE_COMMAND", target.name + " Rückkehr gesetzt");
            }

            boolean sickWord = containsAny(s, "krank", "abwesend", "fallt aus", "fällt aus", "fallt", "fehlt");
            if (sickWord) {
                SmsParser.Result parsed = parser.parse(raw, today);
                if (parsed.type == SmsParser.Type.ABSENT && parsed.until != null) {
                    db.markAbsent(target.id, parsed.start == null ? today : parsed.start, parsed.until, "remote:" + leader.name);
                    reply(phone, target.name + " wurde eingetragen: " + parsed.summary + ".");
                    return handled("REMOTE_COMMAND", target.name + ": " + parsed.summary);
                }
                if (containsAny(s, "morgen krank", "morgen abwesend", "morgen fehlt")) {
                    db.markAbsent(target.id, next, next, "remote:" + leader.name);
                    reply(phone, target.name + " wurde für " + shortDate(next) + " als abwesend eingetragen.");
                    return handled("REMOTE_COMMAND", target.name + " nächster Arbeitstag abwesend");
                }
                if (containsAny(s, "heute krank", "krank heute", "heute abwesend", "abwesend heute", "heute fehlt")) {
                    db.markAbsent(target.id, today, today, "remote:" + leader.name);
                    reply(phone, target.name + " wurde für heute als abwesend eingetragen.");
                    return handled("REMOTE_COMMAND", target.name + " heute abwesend");
                }

                db.saveRemoteSession(phone, leader.id, "ASK_ABSENCE_PERIOD", target.id, "", System.currentTimeMillis() + 10 * 60_000L);
                reply(phone, "Für welchen Zeitraum soll " + target.name + " abwesend sein? Antworte z. B. HEUTE, MORGEN oder BIS 16.10. (Abbrechen mit STOP)");
                return handled("REMOTE_QUESTION", "Zeitraum für " + target.name + " angefragt");
            }
        }

        // Admin-typische Sprache erkannt, aber nicht sicher interpretierbar: nicht als eigene Krankmeldung missverstehen.
        if (containsAny(s, "trag ", "trage ", "setz ", "setze ", "status", "nachtrag", "testmodus", "wer ist", "wer fehlt")) {
            reply(phone, "Ich habe den Leitungsbefehl nicht sicher verstanden. Beispiele: STATUS, STATUS MORGEN, ANNA KRANK BIS FREITAG, ANNA MORGEN DA, NACHTRAG SENDEN.");
            return new Result(true, "REMOTE_NEEDS_REVIEW", "Leitungsbefehl nicht sicher verstanden");
        }
        return Result.no();
    }

    private Result handleSession(AppDb.RemoteSession session, String raw) {
        String s = normalize(raw);
        if (s.equals("stop") || s.equals("abbrechen")) {
            db.clearRemoteSession(session.phone);
            reply(session.phone, "Vorgang abgebrochen.");
            return handled("REMOTE_COMMAND", "Remote-Dialog abgebrochen");
        }

        if ("ASK_TEST_NUMBER".equals(session.action)) {
            String number = raw.replaceFirst("(?i)test\\s*nummer\\s*", "").trim();
            if (number.replaceAll("\\D", "").length() < 8) {
                reply(session.phone, "Bitte sende eine vollständige Mobilnummer oder STOP.");
            } else {
                settings.setTestNumber(number);
                settings.setTestMode(true);
                db.clearRemoteSession(session.phone);
                reply(session.phone, "Testnummer gespeichert und Testmodus aktiviert: " + AppDb.normalizePhone(number));
            }
            return handled("REMOTE_COMMAND", "Testnummer im Dialog gesetzt");
        }

        if ("ASK_ABSENCE_PERIOD".equals(session.action) && session.employeeId != null) {
            AppDb.Employee target = db.getEmployee(session.employeeId);
            if (target == null) { db.clearRemoteSession(session.phone); return handled("REMOTE_NEEDS_REVIEW", "Zielperson nicht mehr vorhanden"); }
            LocalDate today = LocalDate.now();
            LocalDate next = WorkCalendar.nextBusinessDay(today);
            LocalDate start = today;
            LocalDate end = null;
            if (s.equals("1") || containsAny(s, "heute", "nur heute")) end = today;
            else if (s.equals("2") || containsAny(s, "morgen", "nachsten arbeitstag", "nächsten arbeitstag")) { start = next; end = next; }
            else {
                LocalDate date = parser.extractDateOrWeekday(s, today);
                if (date != null) end = date;
            }
            if (end == null) {
                reply(session.phone, "Zeitraum noch nicht erkannt. Bitte HEUTE, MORGEN oder z. B. BIS 16.10. senden. STOP bricht ab.");
                return handled("REMOTE_QUESTION", "Zeitraum erneut angefragt");
            }
            db.markAbsent(target.id, start, end, "remote-dialog");
            db.clearRemoteSession(session.phone);
            reply(session.phone, target.name + " wurde als abwesend eingetragen: " + formatRange(start, end) + ".");
            return handled("REMOTE_COMMAND", target.name + " " + formatRange(start, end));
        }
        return Result.no();
    }

    private AppDb.Employee findMentionedEmployee(String normalizedMessage) {
        List<AppDb.Employee> matches = new ArrayList<>();
        String compact = normalizedMessage.replaceAll("[^a-z0-9]", "");
        for (AppDb.Employee e : db.allEmployees(true)) {
            String n = normalize(e.name).replaceAll("[^a-z0-9]", "");
            if (n.length() >= 3 && compact.contains(n)) matches.add(e);
        }
        return matches.size() == 1 ? matches.get(0) : null;
    }

    private boolean isStatusToday(String s) {
        return s.equals("status") || containsAny(s, "status heute", "wer ist heute krank", "wer ist heute abwesend", "wer fehlt heute", "heute abwesend");
    }
    private boolean isStatusNext(String s) {
        return containsAny(s, "status morgen", "status nachster arbeitstag", "status nächster arbeitstag", "wer ist morgen krank", "wer fehlt morgen", "morgen abwesend");
    }

    private String statusText(LocalDate date, String label) {
        List<AppDb.AbsenceWithEmployee> absent = db.absencesOn(date);
        StringBuilder out = new StringBuilder(label).append(": ");
        out.append(absent.isEmpty() ? "abwesend niemand" : "abwesend " + absent.stream().map(x -> x.employee.name).collect(Collectors.joining(", ")));
        if (date.isAfter(LocalDate.now())) {
            List<AppDb.Employee> present = db.presentOn(date);
            List<AppDb.AbsenceWithEmployee> open = db.needingFollowup(LocalDate.now(), date);
            if (!present.isEmpty()) out.append("; Rückkehr bestätigt ").append(present.stream().map(x -> x.name).collect(Collectors.joining(", ")));
            if (!open.isEmpty()) out.append("; offen ").append(open.stream().map(x -> x.employee.name).collect(Collectors.joining(", ")));
        } else {
            List<AppDb.AbsenceWithEmployee> openToday = db.unresolvedBefore(date);
            if (!openToday.isEmpty()) out.append("; Status ungeklärt ").append(openToday.stream().map(x -> x.employee.name).collect(Collectors.joining(", ")));
        }
        return out.append(".").toString();
    }

    private void reply(String phone, String text) { sender.sendAutomatic(phone, text, "remote_reply", null); }

    private Result handled(String status, String interpretation) { return new Result(true, status, interpretation); }

    private String normalize(String raw) {
        String s = raw.toLowerCase(Locale.GERMANY).replace('ß', 's');
        s = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return s.replaceAll("[^a-z0-9. +]", " ").replaceAll("\\s+", " ").trim();
    }

    private boolean containsAny(String s, String... needles) { for (String n : needles) if (s.contains(n)) return true; return false; }
    private String shortDate(LocalDate d) { return d.format(DateTimeFormatter.ofPattern("dd.MM.yyyy")); }
    private String formatRange(LocalDate start, LocalDate end) { return start.equals(end) ? "am " + shortDate(start) : "von " + shortDate(start) + " bis " + shortDate(end); }
}
