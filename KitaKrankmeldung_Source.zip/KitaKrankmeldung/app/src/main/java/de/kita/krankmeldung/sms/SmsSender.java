package de.kita.krankmeldung.sms;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.telephony.SubscriptionManager;

import de.kita.krankmeldung.data.AppDb;
import de.kita.krankmeldung.util.AppSettings;

import java.util.ArrayList;

public class SmsSender {
    public static final String ACTION_SENT = "de.kita.krankmeldung.SMS_SENT";
    public static final String ACTION_DELIVERED = "de.kita.krankmeldung.SMS_DELIVERED";
    public static final String EXTRA_ATTEMPT_ID = "attempt_id";

    private final Context context;
    private final AppDb db;
    private final AppSettings settings;

    public SmsSender(Context context) {
        this.context = context.getApplicationContext();
        this.db = new AppDb(context);
        this.settings = new AppSettings(context);
    }

    /** Normale, vom Nutzer selbst geschriebene SMS. Testmodus verändert diese nicht. */
    public boolean send(String phone, String text) { return sendManual(phone, text); }

    public boolean sendManual(String phone, String text) {
        String normalized = AppDb.normalizePhone(phone);
        return dispatch(normalized, normalized, text, "manual_sms", null, false, false, null);
    }

    /** Automatische SMS aus der Krankmeldungslogik. Diese wird im Testmodus sicher umgeleitet. */
    public boolean sendAutomatic(String phone, String text, String kind, Long employeeId) {
        String original = AppDb.normalizePhone(phone);
        if (original.trim().isEmpty() || text == null || text.trim().isEmpty()) return false;

        boolean test = settings.isTestMode();
        String actual = original;
        String outgoingText = text;
        if (test) {
            String testNumber = AppDb.normalizePhone(settings.getTestNumber());
            if (testNumber.trim().isEmpty()) {
                long id = db.createSendAttempt(original, original, text, kind, employeeId, true, true, null);
                db.updateSendStatus(id, "FAILED", -1001);
                return false;
            }
            actual = testNumber;
            outgoingText = "[TEST → " + original + "]\n" + text;
        }
        return dispatch(original, actual, outgoingText, kind, employeeId, true, test, null);
    }

    public boolean retry(long attemptId) {
        AppDb.SendAttempt old = db.getSendAttempt(attemptId);
        if (old == null) return false;
        db.updateSendStatus(old.id, "RETRIED", old.errorCode);
        if (old.automatic) {
            // Nutzt bewusst den aktuellen Testmodus. Dadurch kann ein Fehler nach geänderter Einstellung sauber erneut versucht werden.
            return sendAutomatic(old.originalRecipient, stripTestPrefix(old.body), old.kind, old.employeeId);
        }
        return dispatch(old.originalRecipient, old.originalRecipient, old.body, old.kind, old.employeeId, false, false, old.id);
    }

    private boolean dispatch(String originalRecipient, String actualRecipient, String text, String kind, Long employeeId, boolean automatic, boolean testRouted, Long retryOf) {
        if (actualRecipient == null || actualRecipient.trim().isEmpty() || text == null || text.trim().isEmpty()) return false;
        long attemptId = db.createSendAttempt(originalRecipient, actualRecipient, text, kind, employeeId, automatic, testRouted, retryOf);
        try {
            SmsManager sm;
            int subId = SubscriptionManager.getDefaultSmsSubscriptionId();
            if (subId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) sm = SmsManager.getSmsManagerForSubscriptionId(subId);
            else sm = SmsManager.getDefault();

            ArrayList<String> parts = sm.divideMessage(text);
            if (parts == null || parts.isEmpty()) parts = new ArrayList<>();
            if (parts.isEmpty()) parts.add(text);

            ArrayList<PendingIntent> sentIntents = new ArrayList<>();
            ArrayList<PendingIntent> deliveredIntents = new ArrayList<>();
            for (int i = 0; i < parts.size(); i++) {
                int requestBase = (int) ((attemptId * 31 + i) & 0x7fffffff);
                Intent sent = new Intent(context, SmsStatusReceiver.class).setAction(ACTION_SENT).putExtra(EXTRA_ATTEMPT_ID, attemptId);
                Intent delivered = new Intent(context, SmsStatusReceiver.class).setAction(ACTION_DELIVERED).putExtra(EXTRA_ATTEMPT_ID, attemptId);
                sentIntents.add(PendingIntent.getBroadcast(context, requestBase, sent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
                deliveredIntents.add(PendingIntent.getBroadcast(context, requestBase + 1, delivered, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            }

            db.updateSendStatus(attemptId, "SENDING", null);
            if (parts.size() > 1) sm.sendMultipartTextMessage(actualRecipient, null, parts, sentIntents, deliveredIntents);
            else sm.sendTextMessage(actualRecipient, null, text, sentIntents.get(0), deliveredIntents.get(0));

            // Als Standard-SMS-App führen wir den sichtbaren Verlauf selbst.
            new SmsStore(context).insertSent(actualRecipient, text, System.currentTimeMillis());
            return true;
        } catch (Exception ex) {
            db.updateSendStatus(attemptId, "FAILED", -1000);
            return false;
        }
    }

    private String stripTestPrefix(String body) {
        if (body == null) return "";
        if (!body.startsWith("[TEST → ")) return body;
        int nl = body.indexOf('\n');
        return nl >= 0 ? body.substring(nl + 1) : body;
    }
}
