package de.kita.krankmeldung.sms;

import android.content.Context;
import android.telephony.SmsManager;

import java.util.ArrayList;

public class SmsSender {
    private final Context context;
    public SmsSender(Context context) { this.context = context.getApplicationContext(); }

    public void send(String phone, String text) {
        if (phone == null || phone.isBlank() || text == null || text.isBlank()) return;
        SmsManager sm = SmsManager.getDefault();
        ArrayList<String> parts = sm.divideMessage(text);
        if (parts.size() > 1) sm.sendMultipartTextMessage(phone, null, parts, null, null);
        else sm.sendTextMessage(phone, null, text, null, null);
    }
}
