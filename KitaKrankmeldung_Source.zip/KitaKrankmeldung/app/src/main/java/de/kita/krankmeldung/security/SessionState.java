package de.kita.krankmeldung.security;

/**
 * Prozessweite, flüchtige Sitzung. Überlebt Konfigurationswechsel (z. B. Display drehen),
 * aber bewusst keinen Prozess-Neustart oder Geräte-Neustart.
 */
public final class SessionState {
    private static volatile boolean unlocked = false;
    private static volatile long lastInteractionAt = 0L;

    private SessionState() {}

    public static boolean isUnlocked() { return unlocked; }

    public static void unlock() {
        unlocked = true;
        touch();
    }

    public static void lock() {
        unlocked = false;
        lastInteractionAt = 0L;
    }

    public static void touch() {
        if (unlocked) lastInteractionAt = System.currentTimeMillis();
    }

    public static long inactiveForMs() {
        if (!unlocked || lastInteractionAt <= 0L) return Long.MAX_VALUE;
        return Math.max(0L, System.currentTimeMillis() - lastInteractionAt);
    }
}
