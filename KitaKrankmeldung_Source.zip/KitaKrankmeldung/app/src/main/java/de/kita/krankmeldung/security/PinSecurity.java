package de.kita.krankmeldung.security;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

public class PinSecurity {
    private static final String PREFS = "security_prefs";
    private static final String KEY_SALT = "pin_salt";
    private static final String KEY_HASH = "pin_hash";
    private static final String KEY_AUTO_LOCK_MINUTES = "auto_lock_minutes";

    private final SharedPreferences prefs;

    public PinSecurity(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean hasPin() {
        return prefs.contains(KEY_SALT) && prefs.contains(KEY_HASH);
    }

    public boolean isValidFormat(String pin) {
        return pin != null && pin.matches("\\d{4,8}");
    }

    public void setPin(String pin) {
        if (!isValidFormat(pin)) throw new IllegalArgumentException("PIN must contain 4 to 8 digits");
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        String saltB64 = Base64.encodeToString(salt, Base64.NO_WRAP);
        String hashB64 = Base64.encodeToString(hash(pin, salt), Base64.NO_WRAP);
        prefs.edit().putString(KEY_SALT, saltB64).putString(KEY_HASH, hashB64).apply();
    }

    public boolean verify(String pin) {
        if (!hasPin() || pin == null) return false;
        try {
            byte[] salt = Base64.decode(prefs.getString(KEY_SALT, ""), Base64.NO_WRAP);
            byte[] expected = Base64.decode(prefs.getString(KEY_HASH, ""), Base64.NO_WRAP);
            byte[] actual = hash(pin, salt);
            return MessageDigest.isEqual(expected, actual);
        } catch (Exception e) {
            return false;
        }
    }

    public boolean changePin(String oldPin, String newPin) {
        if (!verify(oldPin) || !isValidFormat(newPin)) return false;
        setPin(newPin);
        return true;
    }

    public int getAutoLockMinutes() {
        return prefs.getInt(KEY_AUTO_LOCK_MINUTES, 5);
    }

    public void setAutoLockMinutes(int minutes) {
        if (minutes != 0 && minutes != 2 && minutes != 5 && minutes != 10) {
            throw new IllegalArgumentException("Auto-lock must be 0, 2, 5 or 10 minutes");
        }
        prefs.edit().putInt(KEY_AUTO_LOCK_MINUTES, minutes).apply();
    }

    private byte[] hash(String pin, byte[] salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(salt);
            digest.update(pin.getBytes(StandardCharsets.UTF_8));
            return digest.digest();
        } catch (Exception e) {
            throw new IllegalStateException("PIN hashing unavailable", e);
        }
    }
}
