package de.kita.krankmeldung.sms;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class RespondViaMessageService extends Service {
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getData() != null) {
            String phone = intent.getData().getSchemeSpecificPart();
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (phone != null && text != null) new SmsSender(this).send(phone, text);
        }
        stopSelf(startId);
        return START_NOT_STICKY;
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
