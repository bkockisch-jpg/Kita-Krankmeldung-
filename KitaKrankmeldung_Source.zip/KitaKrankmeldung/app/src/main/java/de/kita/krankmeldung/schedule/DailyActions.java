package de.kita.krankmeldung.schedule;

import android.content.Context;

import de.kita.krankmeldung.data.AppDb;
import de.kita.krankmeldung.sms.SmsParser;
import de.kita.krankmeldung.sms.SmsSender;
import de.kita.krankmeldung.util.WorkCalendar;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DailyActions {
    public static boolean sendMorningDigest(Context context, boolean force) {
        AppDb db = new AppDb(context);
        SmsSender sender = new SmsSender(context);
        LocalDate today = LocalDate.now();
        if (!force && !WorkCalendar.isBusinessDay(today)) return false;
        if (!force && db.hasSent("morning_digest", null, today)) return false;

        List<AppDb.AbsenceWithEmployee> absences = db.absencesOn(today);
        List<AppDb.AbsenceWithEmployee> unresolved = db.unresolvedBefore(today);
        // Auch bei leerer Liste markieren wir den Morgenlauf. Kommt danach eine Krankmeldung,
        // wird sie korrekt als Nachtrag erkannt.
        db.logSent("morning_digest", null, today);

        if (!unresolved.isEmpty()) {
            String openNames = unresolved.stream().map(a -> a.employee.name).distinct().collect(Collectors.joining(", "));
            for (AppDb.Employee leader : db.leaders()) {
                sender.sendAutomatic(leader.phone, "Status für heute noch ungeklärt: " + openNames + ". Bitte prüfen.", "leader_unresolved", leader.id);
            }
        }
        if (absences.isEmpty()) return false;

        String names = absences.stream().map(a -> a.employee.name).collect(Collectors.joining(", "));
        String text = "Heute abwesend sind: " + names + ".";
        for (AppDb.Employee e : db.allEmployees(true)) {
            sender.sendAutomatic(e.phone, text, "morning_digest", e.id);
        }
        for (AppDb.AbsenceWithEmployee a : absences) db.logSent("announced_absence", a.employee.id, today);
        return true;
    }

    public static boolean sendLateAddendum(Context context) {
        AppDb db = new AppDb(context);
        SmsSender sender = new SmsSender(context);
        LocalDate today = LocalDate.now();
        if (!WorkCalendar.isBusinessDay(today)) return false;
        List<AppDb.AbsenceWithEmployee> late = new ArrayList<>();
        for (AppDb.AbsenceWithEmployee a : db.absencesOn(today)) {
            if (!db.hasSent("announced_absence", a.employee.id, today)) late.add(a);
        }
        if (late.isEmpty()) return false;
        String names = late.stream().map(a -> a.employee.name).collect(Collectors.joining(", "));
        String text = late.size()==1 ? "Zusätzlich heute abwesend: " + names + "." : "Zusätzlich heute abwesend sind: " + names + ".";
        for (AppDb.Employee e : db.allEmployees(true)) {
            sender.sendAutomatic(e.phone, text, "late_addendum", e.id);
        }
        for (AppDb.AbsenceWithEmployee a : late) db.logSent("announced_absence", a.employee.id, today);
        db.audit("ADDENDUM_SENT", null, names, "automatic");
        return true;
    }

    public static int sendNoonReminders(Context context, boolean force) {
        AppDb db = new AppDb(context);
        SmsSender sender = new SmsSender(context);
        LocalDate today = LocalDate.now();
        if (!force && !WorkCalendar.isBusinessDay(today)) return 0;
        LocalDate target = WorkCalendar.nextBusinessDay(today);
        int count=0;
        for (AppDb.AbsenceWithEmployee a : db.needingFollowup(today, target)) {
            if (!force && db.hasSent("noon_reminder", a.employee.id, today)) continue;
            String text = "Bitte gib uns kurz Rückmeldung für deinen nächsten Arbeitstag (" + SmsParser.formatGerman(target) + "). " +
                    "Du kannst ganz normal antworten, z. B. „Bin dann wieder da“ oder „Noch krank bis Freitag“.";
            sender.sendAutomatic(a.employee.phone, text, "noon_reminder", a.employee.id);
            db.logSent("noon_reminder", a.employee.id, today);
            count++;
        }
        return count;
    }
}
