package de.kita.krankmeldung.schedule;

import android.content.Context;

import de.kita.krankmeldung.data.AppDb;
import de.kita.krankmeldung.sms.SmsSender;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DailyActions {
    public static boolean sendMorningDigest(Context context, boolean force) {
        AppDb db = new AppDb(context);
        SmsSender sender = new SmsSender(context);
        LocalDate today = LocalDate.now();
        if (!force && db.hasSent("morning_digest", null, today)) return false;

        List<AppDb.AbsenceWithEmployee> absences = db.absencesOn(today);
        if (absences.isEmpty()) {
            db.logSent("morning_digest", null, today);
            return false;
        }
        String names = absences.stream().map(a -> a.employee.name).collect(Collectors.joining(", "));
        String text = "Heute abwesend sind: " + names + ".";
        for (AppDb.Employee e : db.allEmployees(true)) sender.send(e.phone, text);
        db.logSent("morning_digest", null, today);
        for (AppDb.AbsenceWithEmployee a : absences) db.logSent("announced_absence", a.employee.id, today);
        return true;
    }

    public static boolean sendLateAddendum(Context context) {
        AppDb db = new AppDb(context);
        SmsSender sender = new SmsSender(context);
        LocalDate today = LocalDate.now();
        List<AppDb.AbsenceWithEmployee> late = new ArrayList<>();
        for (AppDb.AbsenceWithEmployee a : db.absencesOn(today)) {
            if (!db.hasSent("announced_absence", a.employee.id, today)) late.add(a);
        }
        if (late.isEmpty()) return false;
        String names = late.stream().map(a -> a.employee.name).collect(Collectors.joining(", "));
        String text = late.size()==1 ? "Zusätzlich heute abwesend: " + names + "." : "Zusätzlich heute abwesend sind: " + names + ".";
        for (AppDb.Employee e : db.allEmployees(true)) sender.send(e.phone, text);
        for (AppDb.AbsenceWithEmployee a : late) db.logSent("announced_absence", a.employee.id, today);
        return true;
    }

    public static int sendNoonReminders(Context context, boolean force) {
        AppDb db = new AppDb(context);
        SmsSender sender = new SmsSender(context);
        LocalDate today = LocalDate.now();
        int count=0;
        for (AppDb.AbsenceWithEmployee a : db.needingNoonFollowup(today)) {
            if (!force && db.hasSent("noon_reminder", a.employee.id, today)) continue;
            sender.send(a.employee.phone,
                    "Bitte gib uns kurz Rückmeldung für morgen. Antworte mit MORGEN DA oder z. B. KRANK BIS 08.10.");
            db.logSent("noon_reminder", a.employee.id, today);
            count++;
        }
        return count;
    }
}
