package de.kita.krankmeldung.schedule;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (AlarmScheduler.ACTION_MORNING.equals(intent.getAction())) DailyActions.sendMorningDigest(context, false);
        else if (AlarmScheduler.ACTION_NOON.equals(intent.getAction())) DailyActions.sendNoonReminders(context, false);
        AlarmScheduler.scheduleAll(context);
    }
}
