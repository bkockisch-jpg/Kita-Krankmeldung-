package de.kita.krankmeldung.sms;

import android.content.Context;

import de.kita.krankmeldung.data.AppDb;
import de.kita.krankmeldung.schedule.DailyActions;
import de.kita.krankmeldung.util.AppSettings;
import de.kita.krankmeldung.util.WorkCalendar;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;

public class SmsProcessor {
    private final Context context;
    private final AppDb db;
    private final SmsSender sender;
    private final SmsParser parser = new SmsParser();
    private final AppSettings settings;

    public SmsProcessor(Context context) {
        this.context = context.getApplicationContext();
        this.db = new AppDb(context);
        this.sender = new SmsSender(context);
        this.settings = new AppSettings(context);
    }

    public void processIncoming(String phone, String body, long timestamp) {
        AppDb.Employee employee = db.findEmployeeByPhone(phone);
        String fp = sha256(AppDb.normalizePhone(phone) + "|" + timestamp + "|" + body);
        if (!db.rememberInbound(fp, employee == null ? null : employee.id, phone, body, timestamp)) return;

        if (employee == null) {
            LocalDate ref = Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).toLocalDate();
            SmsParser.Result unknownResult = parser.parse(body, ref);
            if (unknownResult.hasSuggestion()) {
                db.updateInbound(fp, "UNKNOWN_SENDER", "Mögliche Krankmeldung von unbekannter Nummer: " + unknownResult.summary, unknownResult.confidence);
            } else {
                db.updateInbound(fp, "NORMAL_SMS", "Normale SMS von nicht zugeordneter Nummer", 0);
            }
            return;
        }

        // Leitungs-SMS dürfen die App remote steuern. Nicht erkannte Leitungsbefehle fallen danach
        // ganz normal in die Krankmeldungslogik, damit sich auch Leitung selbst krankmelden kann.
        if (employee.leader) {
            RemoteCommandProcessor.Result remote = new RemoteCommandProcessor(context).tryHandle(employee, phone, body);
            if (remote.handled) {
                db.updateInbound(fp, remote.status, remote.interpretation, "REMOTE_NEEDS_REVIEW".equals(remote.status) ? 0.45 : 1.0);
                return;
            }
        }

        LocalDate reference = Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).toLocalDate();
        SmsParser.Result result = parser.parse(body, reference);
        if (result.canAutoApply()) {
            applyResult(employee, result, reference, false);
            db.updateInbound(fp, "AUTO_PROCESSED", result.summary, result.confidence);
            return;
        }

        if (result.hasSuggestion()) {
            String message = "Bitte prüfen: " + employee.name + " schrieb: \"" + compact(body) + "\". Vorschlag: " + result.summary + ".";
            notifyLeaders(message, employee.id);
            sender.sendAutomatic(employee.phone, "Deine Nachricht ist eingegangen und wird von der Leitung geprüft.", "employee_review_ack", employee.id);
            db.updateInbound(fp, "NEEDS_REVIEW", result.summary, result.confidence);
            return;
        }

        notifyLeaders("Bitte prüfen: Nachricht von " + employee.name + " konnte nicht sicher als Krankmeldung/Rückmeldung verstanden werden: \"" + compact(body) + "\".", employee.id);
        sender.sendAutomatic(employee.phone, "Deine Nachricht ist eingegangen und wird von der Leitung geprüft.", "employee_review_ack", employee.id);
        db.updateInbound(fp, "NEEDS_REVIEW", "Nicht sicher erkannt", 0.0);
    }

    public boolean applyReviewedInbound(long inboundId) {
        AppDb.InboundMessage m = db.getInbound(inboundId);
        if (m == null) return false;
        AppDb.Employee e = m.employeeId == null ? db.findEmployeeByPhone(m.phone) : db.getEmployee(m.employeeId);
        if (e == null) return false;
        LocalDate reference = Instant.ofEpochMilli(m.receivedAt).atZone(ZoneId.systemDefault()).toLocalDate();
        SmsParser.Result result = parser.parse(m.body, reference);
        if (result.type == SmsParser.Type.UNKNOWN) return false;
        applyResult(e, result, reference, true);
        db.updateInboundById(inboundId, "REVIEW_CONFIRMED");
        db.audit("REVIEW_CONFIRMED", e.id, result.summary, "manual");
        return true;
    }

    public boolean assignAndReprocess(long inboundId, long employeeId) {
        AppDb.InboundMessage m = db.getInbound(inboundId);
        AppDb.Employee e = db.getEmployee(employeeId);
        if (m == null || e == null) return false;
        try {
            db.updateEmployeePhone(employeeId, m.phone);
            db.assignInboundToEmployee(inboundId, employeeId);
        } catch (Exception ex) {
            return false;
        }
        LocalDate reference = Instant.ofEpochMilli(m.receivedAt).atZone(ZoneId.systemDefault()).toLocalDate();
        SmsParser.Result r = parser.parse(m.body, reference);
        if (r.canAutoApply()) {
            applyResult(e, r, reference, true);
            db.updateInboundById(inboundId, "REVIEW_CONFIRMED");
        } else {
            db.updateInboundById(inboundId, "NEEDS_REVIEW");
        }
        return true;
    }

    public void ignoreInbound(long inboundId) {
        db.updateInboundById(inboundId, "IGNORED");
        db.audit("REVIEW_IGNORED", null, "Inbound " + inboundId, "manual");
    }

    private void applyResult(AppDb.Employee employee, SmsParser.Result result, LocalDate reference, boolean reviewed) {
        LocalDate today = LocalDate.now();
        if (result.type == SmsParser.Type.ABSENT) {
            LocalDate start = result.start == null ? reference : result.start;
            db.markAbsent(employee.id, start, result.until, reviewed ? "review-confirmed" : "sms");

            String confirm;
            if (result.until != null) {
                confirm = "Deine Abwesenheit " + (start.equals(result.until) ? "am " + SmsParser.formatGerman(start)
                        : "von " + SmsParser.formatGerman(start) + " bis einschließlich " + SmsParser.formatGerman(result.until)) + " wurde erfasst.";
            } else if (start.equals(today)) {
                confirm = "Deine Abwesenheit für heute wurde erfasst. Wir fragen später nach deinem nächsten Arbeitstag, falls der Zeitraum offen bleibt.";
            } else {
                confirm = "Deine Abwesenheit ab " + SmsParser.formatGerman(start) + " wurde erfasst.";
            }
            sender.sendAutomatic(employee.phone, confirm, "employee_confirmation", employee.id);
            notifyLeaders("Rückmeldung " + employee.name + ": " + result.summary + ".", employee.id);

            if (start.equals(today) && db.hasSent("morning_digest", null, today)) {
                if (settings.isAutoAddendumEnabled()) DailyActions.sendLateAddendum(context);
                else notifyLeaders("Nachtrag offen: " + employee.name + " wurde nach der Morgenmeldung als abwesend erfasst.", employee.id);
            }
            return;
        }

        if (result.type == SmsParser.Type.RETURN) {
            LocalDate returnDate = result.start == null ? WorkCalendar.nextBusinessDay(reference) : result.start;
            boolean ok = db.setReturnDate(employee.id, returnDate);
            if (ok) {
                sender.sendAutomatic(employee.phone, "Danke. Deine Rückmeldung wurde erfasst: am " + SmsParser.formatGerman(returnDate) + " wieder im Dienst.", "employee_return_confirmation", employee.id);
                notifyLeaders("Rückmeldung " + employee.name + ": am " + SmsParser.formatGerman(returnDate) + " wieder im Dienst.", employee.id);
            } else {
                sender.sendAutomatic(employee.phone, "Deine Rückmeldung ist eingegangen. Es gibt aktuell keine laufende Abwesenheit; die Leitung prüft das.", "employee_review_ack", employee.id);
                notifyLeaders("Bitte prüfen: " + employee.name + " meldet Rückkehr, es gibt aber keine laufende Abwesenheit.", employee.id);
            }
        }
    }

    private void notifyLeaders(String text, Long excludeEmployeeId) {
        for (AppDb.Employee e : db.leaders()) {
            if (excludeEmployeeId != null && e.id == excludeEmployeeId) continue;
            sender.sendAutomatic(e.phone, text, "leader_info", e.id);
        }
    }

    private static String compact(String s) {
        if (s == null) return "";
        String x = s.replaceAll("\\s+", " ").trim();
        return x.length() > 160 ? x.substring(0, 157) + "..." : x;
    }

    private static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte v : b) sb.append(String.format("%02x", v));
            return sb.toString();
        } catch (Exception e) { return String.valueOf(input.hashCode()); }
    }
}
