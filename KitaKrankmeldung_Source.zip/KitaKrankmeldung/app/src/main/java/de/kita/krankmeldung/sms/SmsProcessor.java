package de.kita.krankmeldung.sms;

import android.content.Context;

import de.kita.krankmeldung.data.AppDb;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDate;

public class SmsProcessor {
    private final Context context;
    private final AppDb db;
    private final SmsSender sender;
    private final SmsParser parser = new SmsParser();

    public SmsProcessor(Context context) {
        this.context = context.getApplicationContext();
        this.db = new AppDb(context);
        this.sender = new SmsSender(context);
    }

    public void processIncoming(String phone, String body, long timestamp) {
        AppDb.Employee employee = db.findEmployeeByPhone(phone);
        String fp = sha256(AppDb.normalizePhone(phone) + "|" + timestamp + "|" + body);
        if (!db.rememberInbound(fp, employee == null ? null : employee.id, phone, body, timestamp)) return;

        if (employee == null) {
            // Normale SMS an das Diensthandy bleiben im lokalen Eingang sichtbar,
            // werden aber nicht automatisch an das Leitungsteam weitergeleitet.
            db.setInboundStatus(fp, "UNKNOWN_SENDER");
            return;
        }

        LocalDate today = LocalDate.now();
        SmsParser.Result result = parser.parse(body, today);
        switch (result.type) {
            case SICK:
                db.markAbsent(employee.id, today, null, "sms");
                sender.send(employee.phone, "Deine Abwesenheit für heute wurde erfasst. Bitte gib mittags Rückmeldung, ob du morgen wieder da bist oder bis wann du ausfällst.");
                notifyLeaders("Neue Abwesenheit: " + employee.name + " ist heute nicht im Dienst.");
                db.setInboundStatus(fp, "SICK_RECORDED");
                break;
            case SICK_UNTIL:
                db.markAbsent(employee.id, today, result.until, "sms");
                sender.send(employee.phone, "Deine Abwesenheit bis einschließlich " + SmsParser.formatGerman(result.until) + " wurde erfasst.");
                notifyLeaders("Rückmeldung " + employee.name + ": abwesend bis einschließlich " + SmsParser.formatGerman(result.until) + ".");
                db.setInboundStatus(fp, "UNTIL_RECORDED");
                break;
            case RETURN_TOMORROW:
                if (db.setReturnTomorrow(employee.id, today)) {
                    sender.send(employee.phone, "Danke. Deine Rückmeldung wurde erfasst: morgen wieder im Dienst.");
                    notifyLeaders("Rückmeldung " + employee.name + ": morgen wieder im Dienst.");
                    db.setInboundStatus(fp, "RETURN_RECORDED");
                } else {
                    sender.send(employee.phone, "Ich konnte keine laufende Abwesenheit zuordnen. Die Leitung prüft deine Nachricht.");
                    notifyLeaders("Bitte prüfen: " + employee.name + " meldet \"morgen wieder da\", es gibt aber keine laufende Abwesenheit.");
                    db.setInboundStatus(fp, "NEEDS_REVIEW");
                }
                break;
            case UNKNOWN:
            default:
                notifyLeaders("Unklare Rückmeldung von " + employee.name + ": \"" + compact(body) + "\". Bitte in der App prüfen.");
                sender.send(employee.phone, "Deine Nachricht ist eingegangen und wird von der Leitung geprüft. Für automatische Verarbeitung: KRANK, KRANK BIS 05.10. oder MORGEN DA.");
                db.setInboundStatus(fp, "NEEDS_REVIEW");
        }
    }

    private void notifyLeaders(String text) {
        for (AppDb.Employee e : db.leaders()) sender.send(e.phone, text);
    }

    private static String compact(String s) {
        if (s == null) return "";
        String x = s.replaceAll("\\s+", " ").trim();
        return x.length() > 120 ? x.substring(0, 117) + "..." : x;
    }

    private static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte v : b) sb.append(String.format("%02x", v));
            return sb.toString();
        } catch (Exception e) { return String.valueOf(input.hashCode()); }
    }
}
