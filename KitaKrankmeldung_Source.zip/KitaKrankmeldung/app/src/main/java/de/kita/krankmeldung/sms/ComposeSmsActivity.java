package de.kita.krankmeldung.sms;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class ComposeSmsActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(32,32,32,32);
        EditText phone = new EditText(this); phone.setHint("Telefonnummer");
        EditText body = new EditText(this); body.setHint("Nachricht"); body.setMinLines(4);
        Button send = new Button(this); send.setText("SMS senden");
        if (getIntent().getData()!=null) phone.setText(getIntent().getData().getSchemeSpecificPart());
        if (getIntent().getStringExtra("sms_body")!=null) body.setText(getIntent().getStringExtra("sms_body"));
        send.setOnClickListener(v -> { new SmsSender(this).send(phone.getText().toString(), body.getText().toString()); Toast.makeText(this,"SMS gesendet",Toast.LENGTH_SHORT).show(); finish(); });
        root.addView(phone); root.addView(body); root.addView(send); setContentView(root);
    }
}
