package de.kita.krankmeldung.sms;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ComposeSmsActivity extends Activity {
    private static final int BG = Color.rgb(246,248,250);
    private static final int TEXT = Color.rgb(29,41,57);
    private static final int MUTED = Color.rgb(102,112,133);
    private static final int GREEN = Color.rgb(31,107,69);

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(18));
        root.setBackgroundColor(BG);

        TextView title = text("Neue SMS", 24, TEXT, true);
        TextView subtitle = text("Normale SMS – unabhängig vom Krankmeldungs-Testmodus", 12, MUTED, false);
        subtitle.setPadding(0, dp(2), 0, dp(14));
        EditText phone = field("Telefonnummer"); phone.setInputType(InputType.TYPE_CLASS_PHONE);
        EditText body = field("Nachricht"); body.setSingleLine(false); body.setMinLines(6); body.setGravity(Gravity.TOP); body.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        Button send = new Button(this); send.setText("SMS senden"); send.setAllCaps(false); send.setTextColor(Color.WHITE); send.setTypeface(Typeface.DEFAULT, Typeface.BOLD); send.setBackground(round(GREEN, GREEN, 12));

        Intent in = getIntent();
        Uri data = in.getData();
        if (data != null && data.getSchemeSpecificPart() != null) {
            String p = data.getSchemeSpecificPart();
            int q = p.indexOf('?'); if (q >= 0) p = p.substring(0, q);
            phone.setText(p);
        }
        String prefill = in.getStringExtra("sms_body");
        if (prefill == null) prefill = in.getStringExtra(Intent.EXTRA_TEXT);
        if (prefill != null) body.setText(prefill);

        send.setOnClickListener(v -> {
            String p = phone.getText().toString().trim(); String t = body.getText().toString().trim();
            if (p.replaceAll("\\D", "").length() < 5 || t.isEmpty()) { Toast.makeText(this, "Nummer und Nachricht werden benötigt", Toast.LENGTH_LONG).show(); return; }
            boolean ok = new SmsSender(this).sendManual(p, t);
            Toast.makeText(this, ok ? "SMS-Versand gestartet" : "SMS konnte nicht gestartet werden", Toast.LENGTH_LONG).show();
            if (ok) finish();
        });

        root.addView(title); root.addView(subtitle); root.addView(phone); root.addView(body);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50)); lp.setMargins(0, dp(8), 0, 0); root.addView(send, lp);
        setContentView(root);
    }

    private EditText field(String hint) { EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(round(Color.WHITE,Color.rgb(228,231,236),12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(9));e.setLayoutParams(lp);return e; }
    private TextView text(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
