package de.kita.krankmeldung.sms;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Telephony;
import android.telephony.SmsMessage;

import de.kita.krankmeldung.data.AppDb;
import de.kita.krankmeldung.ui.MainActivity;

public class SmsReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "incoming_sms";

    @Override public void onReceive(Context context, Intent intent) {
        if (!Telephony.Sms.Intents.SMS_DELIVER_ACTION.equals(intent.getAction())) return;
        SmsMessage[] msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (msgs == null || msgs.length == 0) return;

        String phone = msgs[0].getOriginatingAddress();
        long ts = msgs[0].getTimestampMillis();
        StringBuilder body = new StringBuilder();
        for (SmsMessage m : msgs) if (m != null && m.getMessageBody() != null) body.append(m.getMessageBody());
        String number = phone == null ? "" : phone;
        String text = body.toString();

        // Als Standard-SMS-App sind wir dafür verantwortlich, die SMS im System-Provider abzulegen.
        new SmsStore(context).insertIncoming(number, text, ts);
        new SmsProcessor(context).processIncoming(number, text, ts);
        notifyNewSms(context, number);
    }

    private void notifyNewSms(Context context, String phone) {
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Neue SMS", NotificationManager.IMPORTANCE_DEFAULT));
            }
            AppDb.Employee employee = new AppDb(context).findEmployeeByPhone(phone);
            String who = employee == null ? phone : employee.name;
            Intent open = new Intent(context, MainActivity.class);
            open.putExtra("open_tab", "SMS");
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(context, 1001, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new android.app.Notification.Builder(context, CHANNEL)
                    : new android.app.Notification.Builder(context);
            b.setSmallIcon(android.R.drawable.stat_notify_chat)
                    .setContentTitle("Neue SMS")
                    .setContentText(who == null || who.trim().isEmpty() ? "Neue Nachricht" : "Von " + who)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .setVisibility(android.app.Notification.VISIBILITY_PRIVATE);
            nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), b.build());
        } catch (Exception ignored) {}
    }
}
