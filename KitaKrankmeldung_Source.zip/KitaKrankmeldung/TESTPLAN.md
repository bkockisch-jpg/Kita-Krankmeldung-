# V0.3.0 – kurzer Funktionstest

## 1. Navigation & PIN
- App entsperren.
- Zwischen **SMS** und **Krankmeldungen** wechseln.
- Gerät drehen: ausgewählter Reiter bleibt bestehen, keine neue PIN-Abfrage.
- Auto-Lock testen.

## 2. Testmodus
- Testnummer hinterlegen.
- Testmodus aktivieren.
- Prüfen, dass Banner `TESTMODUS AKTIV` sichtbar ist.

## 3. Sprache
Mit einem hinterlegten Mitarbeiterhandy nacheinander testen:
- `Bin heute leider krank und schaffe es nicht.`
- `Bin noch krank bis 14.10.`
- `Morgen sollte es wieder gehen, bin dann ganz normal da.`
- `Vielleicht bin ich morgen wieder da.` → muss unter **Prüfen** landen.

## 4. Nachtrag
- Morgenmeldung manuell anstoßen.
- Danach weitere Krankmeldung senden.
- Prüfen, dass der Nachtrag automatisch angestoßen wird.

## 5. Fehler
- Für einen Test kurz Mobilfunk deaktivieren und eine automatische SMS anstoßen.
- Nach Rückkehr in die App muss der Fehler unter **Versandprobleme** sichtbar sein.
- `Erneut senden` testen.

## 6. Remote-Leitung
Von einer als Leitung markierten Nummer:
- `STATUS`
- `OFFENE RÜCKMELDUNGEN`
- `Anna krank` → App muss nach Zeitraum fragen.
- Antwort `HEUTE`
- `ANNA MORGEN DA`

## 7. Suche
- Im SMS-Reiter nach Name suchen.
- Nach Nummer suchen.
- Nach einem Wort aus einer Nachricht suchen.
