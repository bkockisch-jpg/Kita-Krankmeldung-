# Kita Krankmeldung – Android V0.3.0

Interne SMS-Zentrale für ein Kita-Diensthandy. Die App ist bewusst als Android-Standard-SMS-App ausgelegt, damit **eine einzige App** normale SMS und die Krankmeldungsautomatik übernehmen kann.

## Hauptnavigation
Oben gibt es genau zwei Hauptreiter:

- **SMS** – normale SMS-Unterhaltungen, schnelle Suche, neue SMS, Antworten
- **Krankmeldungen** – Übersicht, Team, Prüffälle, Testmodus und Einstellungen

Der aktive Reiter wird mit einem Unterstrich markiert. Der Zustand bleibt bei einer Bildschirmdrehung erhalten.

## SMS-Client
- Android `ROLE_SMS` / Standard-SMS-App
- eingehende SMS werden in Androids SMS-Provider gespeichert
- Unterhaltungsübersicht mit Ungelesen-Hinweis
- Unterhaltung öffnen und antworten
- neue SMS schreiben
- schnelle Suche nach Name, Telefonnummer und Nachrichtentext
- lokale/europäische Schreibweisen derselben deutschen Mobilnummer werden zusammengeführt
- neue SMS werden auch bei gesperrter Oberfläche verarbeitet
- SMS-Versand wird mit `SENDING`, `SENT`, `DELIVERED` bzw. `FAILED` protokolliert
- fehlgeschlagene Krankmeldungs-SMS werden im Dashboard sichtbar und können erneut versendet werden
- MMS ist in V0.3.0 noch nicht als Unterhaltung implementiert

## Krankmeldungslogik
Die Zuordnung erfolgt über die im Team hinterlegte Mobilnummer. Es gibt bewusst **keine Diagnose- oder Krankheitsgrund-Pflicht**.

### Natürliches Sprachverständnis
Der Parser versteht nicht nur feste Befehle, sondern viele umgangssprachliche Formulierungen, zum Beispiel:

- `KRANK`
- `Bin heute leider krank und schaffe es nicht.`
- `Kind krank, ich komme heute nicht.`
- `Arzt hat mich erstmal bis einschließlich Mittwoch rausgenommen.`
- `Bin noch krank bis 14.10.`
- `Morgen sollte es wieder gehen, bin dann ganz normal da.`
- `Mir geht's noch nicht besser, ich bleibe morgen auch zuhause.`

Die Verarbeitung nutzt Sicherheitsstufen:

- hohe Sicherheit → automatisch übernehmen
- mittlere Sicherheit → Vorschlag unter **Prüfen**, keine automatische Statusänderung
- nicht verstanden → unter **Prüfen** anzeigen

Formulierungen mit Unsicherheit wie `vielleicht`, `wahrscheinlich` oder `eventuell` werden bewusst nicht automatisch als sichere Rückkehr gewertet.

## Morgenmeldung, Nachtrag und Rückfrage
- Standard-Morgenmeldung: 07:45 Uhr
- Team-SMS: `Heute abwesend sind: Anna, Benni, Conny.`
- Krankmeldung nach dem Morgenlauf → automatischer Nachtrag, sofern aktiviert
- Standard-Rückfrage: 12:00 Uhr
- Rückfragen nur bei Personen, deren Status für den nächsten Arbeitstag offen ist
- bekannte mehrtägige Abwesenheiten werden ohne unnötige Zwischenfragen berücksichtigt

## Wochenenden und Feiertage
Automatische Morgenmeldungen und Rückfragen werden samstags, sonntags und an gesetzlichen Feiertagen in Hessen übersprungen. Der nächste relevante Arbeitstag wird automatisch berechnet. Enthalten sind insbesondere Neujahr, Karfreitag, Ostermontag, Tag der Arbeit, Christi Himmelfahrt, Pfingstmontag, Fronleichnam, Tag der Deutschen Einheit sowie 1. und 2. Weihnachtsfeiertag.

## Testmodus
Der Testmodus ist ein zentrales Sicherheitsmerkmal:

- Testnummer frei hinterlegbar
- automatische Krankmeldungs-SMS werden ausschließlich auf die Testnummer umgeleitet
- jede umgeleitete SMS trägt einen sichtbaren `[TEST → Originalempfänger]`-Hinweis
- normale, manuell im SMS-Reiter geschriebene SMS werden **nicht** umgeleitet
- Dashboard zeigt dauerhaft einen auffälligen Testmodus-Hinweis

## Fehlgeschlagene SMS
Jeder automatische Versand wird einzeln protokolliert. Bei Fehlern zeigt das Dashboard:

- ursprünglichen Empfänger
- Art der SMS (Morgenmeldung, Rückfrage, Nachtrag usw.)
- verständliche Fehlerbeschreibung
- Nachrichtenvorschau
- **Erneut senden**

## Manuelle Korrekturen
Die Leitung kann unter Krankmeldungen:

- Abwesenheit für heute oder den nächsten Arbeitstag eintragen
- Enddatum ändern
- Dauer wieder auf offen setzen
- eine Person für heute als doch anwesend korrigieren
- Nachtrag, Morgenmeldung oder Rückfragen manuell anstoßen

Korrekturen werden zusätzlich im lokalen Audit-Log vermerkt.

## Remote-Steuerung für Leitung
Nur Teammitglieder mit aktivierter **Leitungsrolle** dürfen Befehle von ihrer hinterlegten Nummer senden.

Beispiele:

- `STATUS`
- `STATUS MORGEN`
- `OFFENE RÜCKMELDUNGEN`
- `ANNA KRANK BIS FREITAG`
- `ANNA MORGEN DA`
- `NACHTRAG SENDEN`
- `TESTMODUS AN`
- `TESTMODUS AUS`
- `TESTNUMMER 0176...`

Ist ein Befehl unvollständig, fragt die App per SMS nach. Beispiel: `Anna krank` → `Für welchen Zeitraum? HEUTE, MORGEN oder BIS 16.10.`. Remote-Dialoge laufen nach zehn Minuten aus und können mit `STOP` beendet werden.

## Unbekannte Nummern
Normale SMS von unbekannten Nummern bleiben normale SMS. Nur wenn der Text wie eine mögliche Krankmeldung aussieht, erscheint er zusätzlich unter **Prüfen** und kann einem Teammitglied zugeordnet werden.

## Sicherheit
- PIN 4–8 Ziffern
- PIN nicht im Klartext gespeichert
- Auto-Lock: 2 / 5 / 10 Minuten oder Nie, Standard 5 Minuten
- manueller Button `App jetzt sperren`
- Bildschirmdrehung sperrt die App nicht mehr neu
- Prozess- oder Geräteneustart sperrt die Oberfläche wieder
- Hintergrund-SMS-Automatik läuft unabhängig von der gesperrten Oberfläche

## Android-SMS-Rolle
Für Android 10+ wird `RoleManager.ROLE_SMS` verwendet. Die App deklariert die für die SMS-Rolle erwarteten Komponenten:

- `SMS_DELIVER`-Receiver
- `WAP_PUSH_DELIVER`-Receiver
- `SENDTO`-Activity für `sms`, `smsto`, `mms`, `mmsto`
- `RESPOND_VIA_MESSAGE`-Service

Berechtigungen: `RECEIVE_SMS`, `SEND_SMS`, `READ_SMS`, `RECEIVE_MMS`, `POST_NOTIFICATIONS`, `RECEIVE_BOOT_COMPLETED`, `SCHEDULE_EXACT_ALARM`.

## Version
- `versionCode 8`
- `versionName 0.3.0`
