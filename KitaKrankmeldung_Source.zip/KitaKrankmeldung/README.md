# Kita Krankmeldung – Android V0.2

Interne SMS-Zentrale für ein Diensthandy.

## Enthalten
- Mitarbeiter-Stammdaten (Name, Mobilnummer, Leitung ja/nein)
- Eingehende Krankmeldungen per SMS
- Befehle: `KRANK`, `KRANK BIS 05.10.`, `MORGEN DA`, `VERLÄNGERT BIS 08.10.`
- einfache Erkennung natürlicher Formulierungen wie „bin heute krank“ oder „morgen wieder da“
- automatische Bestätigung an Mitarbeitende
- sofortige Rückmeldung an alle als Leitung markierten Nummern
- tägliche Team-SMS: `Heute abwesend sind: Anna, Benni, Conny.`
- Mittags-Rückfrage nur an Personen, deren Status für morgen offen ist
- bekannte längere Ausfälle werden nicht täglich erneut gefragt
- separater Nachtrag für Abwesenheiten, die nach der morgendlichen Team-SMS gemeldet wurden
- lokaler SMS-Eingang, damit normale SMS an das Diensthandy sichtbar bleiben
- lokale Speicherung in SQLite, kein Server/Cloud nötig
- PIN-Schutz für den Leitungsbereich
- frei änderbare PIN (4–8 Ziffern) über Einstellungen → Sicherheit
- PIN wird mit Salt + SHA-256 gespeichert, nicht im Klartext
- Schaltfläche „App jetzt sperren“ für sofortiges Verriegeln
- automatische Sperre nach Inaktivität: 2, 5 oder 10 Minuten bzw. „Nie“
- Standard für die automatische Sperre: 5 Minuten

## Standardzeiten
- Team-SMS: 07:45 Uhr
- Mittags-Rückfrage: 12:00 Uhr
- beide Zeiten sind in der App änderbar
- optional kann Androids Freigabe für genaue Alarme aktiviert werden, damit der Versand möglichst pünktlich erfolgt

## PIN-Schutz
Beim ersten Start muss eine eigene PIN mit 4–8 Ziffern festgelegt und bestätigt werden. Danach ist der Leitungsbereich beim App-Start gesperrt. Unter **Einstellungen → Sicherheit → PIN ändern** kann die PIN jederzeit geändert werden; dafür werden die aktuelle PIN, die neue PIN und eine Wiederholung der neuen PIN benötigt. Die SMS-Automatik läuft auch bei gesperrter Oberfläche im Hintergrund weiter. Unter **Einstellungen → Sicherheit** lässt sich außerdem festlegen, ob die App nach **2, 5 oder 10 Minuten Inaktivität** automatisch sperrt oder ob die automatische Sperre deaktiviert ist. Standard sind **5 Minuten**. Berührungen in der App setzen den Inaktivitäts-Timer zurück.

## Installation / SMS-Rolle
Die App ist für Android 10+ (API 29+) vorgesehen. Nach der Installation in der App auf **„SMS-Automatik aktivieren“** tippen und die Systemabfrage bestätigen. Android verlangt für zuverlässigen automatischen SMS-Empfang/-Versand die entsprechende SMS-Rolle/Berechtigungen.

**Wichtig:** Wenn die App als Standard-SMS-App gewählt wird, verarbeitet sie die SMS des Diensthandys. Normale eingehende SMS werden deshalb zusätzlich im Bereich **Eingang** lokal angezeigt.

## Datenschutzidee
Die V1 fragt keinen Krankheitsgrund und keine Diagnose ab. Gespeichert werden nur Stammdaten, SMS-Inhalt und Abwesenheitszeitraum auf dem Gerät.

## Testablauf
1. Zwei Test-Mitarbeitende anlegen, davon eine Person als „Leitung“ markieren.
2. Vom anderen Handy `KRANK` an das Diensthandy senden.
3. Prüfen, ob die Person unter „Heute“ erscheint und die Leitung eine direkte SMS bekommt.
4. „Mittags-Rückfrage jetzt senden“ antippen.
5. Vom Testhandy `MORGEN DA` oder `KRANK BIS 08.10.` antworten.
6. `Team-SMS jetzt senden` testen.
7. Danach eine weitere Person krankmelden und `Nachtrag ans Team senden` testen.

## Noch nicht Teil von V1
- verschlüsselte Export-/Backup-Funktion
- AU/eAU-Dokumente
- Dienstplan- oder Famly-Anbindung
- Mehrgeräte-Synchronisation


## Neu in 0.2.0
- einstellbare automatische PIN-Sperre nach 2, 5 oder 10 Minuten Inaktivität
- Option „Nie“ zum Deaktivieren der automatischen Sperre
- Standardwert 5 Minuten
- jede Interaktion setzt den Timer zurück
- beim Sperren wird die Oberfläche neu aufgebaut, sodass auch offene Dialoge geschlossen werden


## Dashboard V0.2
- neue Leitungsübersicht mit Karten für „heute abwesend“ und „Rückmeldung offen“
- eigene Planungsübersicht für morgen: abwesend / wieder da / offen
- Abwesenheitskarten mit klarer Statusdarstellung
- SMS-Automatik und eingestellte Versandzeiten direkt im Dashboard sichtbar
- Teamseite mit Anzahl aktiver Mitarbeitender und Leitungsmitglieder
- SMS-Eingang mit sichtbarer Kennzeichnung „Verarbeitet“ / „Bitte prüfen“
- PIN und automatische Sperre bleiben unverändert aktiv

## APK-Build
Im Projekt liegt unter `.github/workflows/build-apk.yml` ein GitHub-Actions-Workflow. Er installiert Java 17, Android SDK 35 und Gradle 8.9, baut `:app:assembleDebug` und stellt `app-debug.apk` als Workflow-Artefakt bereit.
