# Kita Krankmeldung – Android V0.2.1

Interne SMS-Zentrale für ein Diensthandy.

## Enthalten
- Mitarbeiter-Stammdaten (Name, Mobilnummer, Leitung ja/nein)
- Eingehende Krankmeldungen per SMS
- Befehle: `KRANK`, `KRANK BIS 05.10.`, `MORGEN DA`, `VERLÄNGERT BIS 08.10.`
- einfache Erkennung natürlicher Formulierungen wie „bin heute krank“ oder „morgen wieder da“
- automatische Bestätigung an Mitarbeitende
- sofortige Rückmeldung an alle als Leitung markierten Nummern
- tägliche Team-SMS: `Heute abwesend sind: Anna, Benni, Conny.`
- Mittags-Rückfrage nur an Personen, deren Status für morgen offen ist
- bekannte längere Ausfälle werden nicht täglich erneut gefragt
- separater Nachtrag für Abwesenheiten, die nach der morgendlichen Team-SMS gemeldet wurden
- lokaler Eingang nur für SMS, die die App ab Installation als Broadcast empfängt
- lokale Speicherung in SQLite, kein Server/Cloud nötig
- PIN-Schutz für den Leitungsbereich
- frei änderbare PIN (4–8 Ziffern) über Einstellungen → Sicherheit
- PIN wird mit Salt + SHA-256 gespeichert, nicht im Klartext
- Schaltfläche „App jetzt sperren“ für sofortiges Verriegeln
- automatische Sperre nach Inaktivität: 2, 5 oder 10 Minuten bzw. „Nie“
- Standard für die automatische Sperre: 5 Minuten

## Standardzeiten
- Team-SMS: 07:45 Uhr
- Mittags-Rückfrage: 12:00 Uhr
- beide Zeiten sind in der App änderbar
- optional kann Androids Freigabe für genaue Alarme aktiviert werden, damit der Versand möglichst pünktlich erfolgt

## PIN-Schutz
Beim ersten Start muss eine eigene PIN mit 4–8 Ziffern festgelegt und bestätigt werden. Danach ist der Leitungsbereich beim App-Start gesperrt. Unter **Einstellungen → Sicherheit → PIN ändern** kann die PIN jederzeit geändert werden; dafür werden die aktuelle PIN, die neue PIN und eine Wiederholung der neuen PIN benötigt. Die SMS-Automatik läuft auch bei gesperrter Oberfläche im Hintergrund weiter. Unter **Einstellungen → Sicherheit** lässt sich außerdem festlegen, ob die App nach **2, 5 oder 10 Minuten Inaktivität** automatisch sperrt oder ob die automatische Sperre deaktiviert ist. Standard sind **5 Minuten**. Berührungen in der App setzen den Inaktivitäts-Timer zurück.

## Installation / SMS-Berechtigungen
Die App ist für Android 10+ (API 29+) vorgesehen. **Sie muss nicht und soll nicht als Standard-SMS-App verwendet werden.** Samsung/Google Messages bleibt unverändert die normale SMS-App des Diensthandys.

Für die Automatik fordert die App nur zwei Berechtigungen an:
- `RECEIVE_SMS` – um neue eingehende Krankmeldungen als System-Broadcast zu erkennen
- `SEND_SMS` – um Bestätigungen, Leitungsinfos und Sammel-SMS zu verschicken

`READ_SMS`, MMS-Zugriff und die Android-SMS-Rolle sind in V0.2.1 entfernt. Die App liest keinen bestehenden SMS-Verlauf und schreibt nicht in die SMS-Datenbank.

Bei manuell installierten APKs kann Samsung die SMS-Freigabe zunächst als eingeschränkte Einstellung blockieren. In diesem Fall in **App-Info → ⋮ → Eingeschränkte Einstellungen zulassen** aktivieren und danach die SMS-Berechtigungen erneut erteilen.

## Datenschutzidee
Die V1 fragt keinen Krankheitsgrund und keine Diagnose ab. Gespeichert werden nur Stammdaten, SMS-Inhalt und Abwesenheitszeitraum auf dem Gerät.

## Testablauf
1. Zwei Test-Mitarbeitende anlegen, davon eine Person als „Leitung“ markieren.
2. Vom anderen Handy `KRANK` an das Diensthandy senden.
3. Prüfen, ob die Person unter „Heute“ erscheint und die Leitung eine direkte SMS bekommt.
4. „Mittags-Rückfrage jetzt senden“ antippen.
5. Vom Testhandy `MORGEN DA` oder `KRANK BIS 08.10.` antworten.
6. `Team-SMS jetzt senden` testen.
7. Danach eine weitere Person krankmelden und `Nachtrag ans Team senden` testen.

## Noch nicht Teil von V1
- verschlüsselte Export-/Backup-Funktion
- AU/eAU-Dokumente
- Dienstplan- oder Famly-Anbindung
- Mehrgeräte-Synchronisation


## Neu in 0.2.0
- einstellbare automatische PIN-Sperre nach 2, 5 oder 10 Minuten Inaktivität
- Option „Nie“ zum Deaktivieren der automatischen Sperre
- Standardwert 5 Minuten
- jede Interaktion setzt den Timer zurück
- beim Sperren wird die Oberfläche neu aufgebaut, sodass auch offene Dialoge geschlossen werden


## Dashboard V0.2
- neue Leitungsübersicht mit Karten für „heute abwesend“ und „Rückmeldung offen“
- eigene Planungsübersicht für morgen: abwesend / wieder da / offen
- Abwesenheitskarten mit klarer Statusdarstellung
- SMS-Automatik und eingestellte Versandzeiten direkt im Dashboard sichtbar
- Teamseite mit Anzahl aktiver Mitarbeitender und Leitungsmitglieder
- SMS-Eingang mit sichtbarer Kennzeichnung „Verarbeitet“ / „Bitte prüfen“
- PIN und automatische Sperre bleiben unverändert aktiv

## APK-Build
Im Projekt liegt unter `.github/workflows/build-apk.yml` ein GitHub-Actions-Workflow. Er installiert Java 17, Android SDK 35 und Gradle 8.9, baut `:app:assembleDebug` und stellt `app-debug.apk` als Workflow-Artefakt bereit.

## Neu in 0.2.1
- keine Anforderung mehr, Kita Krankmeldung als Standard-SMS-App festzulegen
- Samsung/Google Messages bleibt Standard-SMS-App
- entfernt: `READ_SMS`, `RECEIVE_MMS`, `SMS_DELIVER`, SMS-Compose-/Respond-Komponenten
- Empfang nur noch über `SMS_RECEIVED` mit `RECEIVE_SMS`
- Versand weiterhin über `SEND_SMS` / `SmsManager`
- neues Berechtigungs-UI mit Hinweis auf Samsungs „Eingeschränkte Einstellungen“
- VersionCode 5 / VersionName 0.2.1
